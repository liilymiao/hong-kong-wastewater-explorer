#!/usr/bin/env python3
"""Audit frozen local COVID-19 Express CSV files; never download or fit a model.

Run: python audit_data.py
Optional: python audit_data.py --data-dir /path/to/evidence/data

Raw CSVs, PDFs, source retrieval metadata, and correction instructions remain
unchanged. audit.json is refreshed with computed local-file checks. Observation
dates, publication dates, archive dates, and retrieval dates stay separate.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
from collections import Counter
from datetime import datetime, timedelta, timezone
from decimal import Decimal, InvalidOperation
from pathlib import Path

MISSING = {"", "/"}
DATE_FIELDS = {"From", "To"}
CLINIC_ALIAS = {"COVID19_GOPC": "sentinel_public_clinic_rate",
                "COVID19_FMC": "sentinel_public_clinic_rate"}


def utc_now():
    return datetime.now(timezone.utc).isoformat()


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def decimal_or_none(value):
    try:
        number = Decimal(value)
        return number if number.is_finite() else None
    except (InvalidOperation, TypeError):
        return None


def week_key(row):
    return f"{row.get('Year', '?')}-W{row.get('Week', '?').zfill(2)}"


def read_csv(path):
    rows, blanks, malformed = [], [], []
    with path.open(encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        fields = reader.fieldnames or []
        record_count = 0
        for record_count, row in enumerate(reader, start=1):
            # Only completely empty CSV records are excluded; missing cells in
            # otherwise populated rows are retained and audited below.
            values = [v for v in row.values() if isinstance(v, str)]
            all_blank = all(not v.strip() for v in values)
            if all_blank and None not in row:
                blanks.append({"record_index_excluding_header": record_count,
                               "physical_line_end": reader.line_num})
                continue
            if None in row or any(v is None for v in row.values()):
                malformed.append({"record_index_excluding_header": record_count,
                                  "physical_line_end": reader.line_num})
            rows.append(row)
    return fields, rows, record_count, blanks, malformed


def audit_csv(path):
    fields, rows, physical_records, blanks, malformed = read_csv(path)
    result = {
        "file": path.name, "bytes": path.stat().st_size,
        "sha256": sha256(path), "columns": fields, "column_count": len(fields),
        "csv_records_excluding_header": physical_records,
        "nonblank_week_rows": len(rows), "all_blank_records": blanks,
        "malformed_records": malformed,
        "all_blank_record_policy": "Exclude from row statistics only; do not change raw file.",
        "first_row": rows[0] if rows else None,
        "last_row": rows[-1] if rows else None,
    }
    keys = Counter(week_key(r) for r in rows)
    start_keys = Counter(r.get("From") for r in rows)
    result["duplicate_year_week"] = {k: n for k, n in keys.items() if n > 1}
    result["duplicate_from_date"] = {k: n for k, n in start_keys.items() if n > 1}
    parsed, date_errors, boundary_errors = [], [], []
    for row in rows:
        try:
            start = datetime.strptime(row["From"], "%d/%m/%Y").date()
            end = datetime.strptime(row["To"], "%d/%m/%Y").date()
        except (ValueError, TypeError, KeyError) as error:
            date_errors.append({"week": week_key(row), "error": str(error)})
            continue
        parsed.append((row, start, end))
        if start.weekday() != 6 or end.weekday() != 5 or (end-start).days != 6:
            boundary_errors.append({
                "week": week_key(row), "raw_from": row["From"], "raw_to": row["To"],
                "from_weekday": start.strftime("%A"), "to_weekday": end.strftime("%A"),
                "inclusive_days": (end-start).days+1,
                "derived_end_if_seven_day_week": (start+timedelta(days=6)).isoformat(),
                "raw_file_changed": False,
            })
    step_errors = []
    for previous, current in zip(parsed, parsed[1:]):
        step = (current[1]-previous[1]).days
        if step != 7:
            step_errors.append({"previous_week": week_key(previous[0]),
                                "current_week": week_key(current[0]), "days": step})
    result["dates"] = {
        "input_format": "DD/MM/YYYY", "anchor": "From",
        "earliest_from": min((x[1] for x in parsed), default=None).isoformat() if parsed else None,
        "latest_from": max((x[1] for x in parsed), default=None).isoformat() if parsed else None,
        "latest_raw_to": max((x[2] for x in parsed), default=None).isoformat() if parsed else None,
        "from_sunday_count": sum(x[1].weekday() == 6 for x in parsed),
        "to_saturday_count": sum(x[2].weekday() == 5 for x in parsed),
        "parse_errors": date_errors, "boundary_errors": boundary_errors,
        "non_seven_day_from_steps": step_errors,
        "official_week_labels_retained": True,
        "iso_week_recalculated": False,
    }
    field_stats = {}
    for field in fields:
        if field in DATE_FIELDS:
            continue
        missing_rows, missing_tokens, invalid_tokens, numeric = [], Counter(), [], []
        for row in rows:
            token = row.get(field)
            clean = token.strip() if isinstance(token, str) else token
            if clean in MISSING:
                missing_tokens[clean] += 1
                missing_rows.append({"week": week_key(row), "from": row.get("From"),
                                     "to": row.get("To"), "raw_value": token})
            else:
                value = decimal_or_none(clean)
                if value is None:
                    invalid_tokens.append({"week": week_key(row), "raw_value": token})
                else:
                    numeric.append(value)
        field_stats[field] = {
            "numeric_count": len(numeric), "missing_count": len(missing_rows),
            "missing_tokens": dict(missing_tokens), "missing_rows": missing_rows,
            "invalid_tokens": invalid_tokens,
            "numeric_min": str(min(numeric)) if numeric else None,
            "numeric_max": str(max(numeric)) if numeric else None,
            "zero_count": sum(x == 0 for x in numeric),
        }
    result["field_statistics"] = field_stats
    result["any_imputation_performed"] = False
    return result, rows


def canonical(row):
    return {CLINIC_ALIAS.get(k, k): v for k, v in row.items()}


def compare(archive_name, archived, current):
    before = {week_key(row): canonical(row) for row in archived}
    after = {week_key(row): canonical(row) for row in current}
    changes = []
    for week in sorted(before.keys() & after.keys()):
        for field in sorted(before[week].keys() & after[week].keys()):
            a, b = before[week][field], after[week][field]
            if a == b:
                continue
            if a in MISSING and b in MISSING:
                kind = "missing_marker_changed"
            else:
                da, db = decimal_or_none(a), decimal_or_none(b)
                if da is not None and db is not None:
                    kind = "numeric_format_only" if da == db else "numeric_value_changed"
                else:
                    kind = "text_or_availability_changed"
            changes.append({"week": week, "field": field,
                            "archive_value": a, "current_value": b, "change_type": kind})
    return {
        "archive_file": archive_name, "current_file": "covidx_data.csv",
        "common_week_count": len(before.keys() & after.keys()),
        "added_weeks_in_current": sorted(after.keys()-before.keys()),
        "removed_weeks_from_current": sorted(before.keys()-after.keys()),
        "changed_cell_count": len(changes), "changes": changes,
        "clinic_alias_for_comparison_only": CLINIC_ALIAS,
        "interpretation": "Numeric differences can include precision changes and revisions; raw columns and values remain preserved.",
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data-dir", type=Path, default=Path(__file__).resolve().parent)
    args = parser.parse_args()
    directory = args.data_dir.resolve()
    output = directory/"audit.json"
    report = json.loads(output.read_text(encoding='utf-8')) if output.exists() else {"sources": []}
    sources = report.get("sources", [])
    source_checks = []
    for source in sources:
        file = directory/source["file"]
        actual = sha256(file) if file.exists() else None
        source_checks.append({"file": source["file"], "exists": file.exists(),
                              "recorded_sha256": source.get("sha256"),
                              "actual_sha256": actual,
                              "sha256_matches_retrieval_record": actual == source.get("sha256")})
    current, rows = audit_csv(directory/"covidx_data.csv")
    archive_audits, archive_comparisons = [], []
    for file in sorted(directory.glob("covidx_archive_*.csv")):
        item, archived = audit_csv(file)
        archive_audits.append(item)
        archive_comparisons.append(compare(file.name, archived, rows))
    inventory = json.loads((directory/"archive_versions.json").read_text(encoding='utf-8'))
    timestamps = inventory.get("timestamps", [])
    overrides_path = directory/"date_overrides.csv"
    overrides = []
    if overrides_path.exists():
        with overrides_path.open(encoding="utf-8", newline="") as handle:
            overrides = list(csv.DictReader(handle))
    override_checks = []
    for override in overrides:
        matches = [r for r in rows if r["Year"] == override["Year"]
                   and r["Week"] == override["Week"] and r["From"] == override["From"]]
        override_checks.append({
            "Year": override["Year"], "Week": override["Week"],
            "matching_raw_rows": len(matches),
            "raw_value_matches_precondition": len(matches) == 1 and matches[0].get(override["field"]) == override["original_value"],
            "corrected_value": override["corrected_value"],
            "applied_to_raw": False,
        })
    report.update({
        "audit_scope": "Data availability and provenance audit only; no predictive modelling, model fitting, validation, or forecasting has been run.",
        "as_of_hong_kong": "2026-10-23", "audit_run_utc": utc_now(),
        "status": "complete_local_snapshot_audit", "models_run": False,
        "source_integrity_checks": source_checks,
        "current_csv": current, "archive_csv_samples": archive_audits,
        "archive_comparisons_to_current": archive_comparisons,
        "date_override_checks": override_checks,
        "historical_archive": {
            "timezone": "GMT+8", "reported_version_count": inventory.get("version-count"),
            "listed_timestamp_count": len(timestamps),
            "first_listed_timestamp_hkt": min(timestamps) if timestamps else None,
            "last_listed_timestamp_hkt": max(timestamps) if timestamps else None,
            "retrieved_csv_sample_count": len(archive_audits),
            "all_listed_versions_downloaded_or_validated": False,
            "prior_file_before_query_start": inventory.get("latest-file-before-start-date"),
            "latest_csv_update_is_in_frozen_inventory": False,
            "release_date_in_csv": False, "report_published_date_in_archive_inventory": False,
            "archive_datetime_is_publisher_release_datetime": False,
            "feasibility": "Official archived CSVs can be retrieved and used for conservative archive-as-of validation from the first available archive; all intermediate versions and historical publication dates still need separate verification.",
        },
        "units_and_schema": {
            "Sewage_viralload": {
                "official_name": "Per capita viral load (7-day geometric mean) of SARS-CoV-2 virus from sewage surveillance",
                "unit_as_printed_in_week42_report": "copy/L",
                "dictionary_contains_unit": False,
                "normalization_formula_available_in_this_csv_or_dictionary": False,
                "do_not_infer": ["copies/person/day", "PMMoV normalization", "divide again by population"],
            },
            "SARSCoV2_proportion": {"raw_unit": "proportion (0-1)", "display_percent_multiplier": 100,
                "do_not_use_SARSCoV2_newcount_as_numerator": True},
            "clinic_rates": {"unit": "COVID-19 cases per 1,000 consultations",
                "dictionary_and_2023_archive_column": "COVID19_GOPC",
                "current_and_2026_archive_column": "COVID19_FMC",
                "proposed_internal_alias": "sentinel_public_clinic_rate",
                "identical_sentinel_population_or_method_over_time_established": False},
        },
        "verified_report_dates": [
            {"file": "covid_flux_week42_22_10_2026_eng.pdf", "report_published_date": "2026-10-22",
             "publication_time_of_day": None, "report_as_of_date": "2026-10-21",
             "reporting_period_from": "2026-10-11", "reporting_period_to": "2026-10-17", "evidence_page": 1},
            {"file": "covid_flux_week6_12_2_2026_eng.pdf", "report_published_date": "2026-02-12",
             "publication_time_of_day": None, "report_as_of_date": "2026-02-11",
             "reporting_period_from": "2026-02-01", "reporting_period_to": "2026-02-07", "evidence_page": 1},
        ],
        "clinical_series_crosscheck": {
            "2026_W42_csv_SARSCoV2_newcount": "13",
            "2026_W42_report_page2_newly_recorded_nucleic_acid_detections": 13,
            "2026_W42_report_page3_PHLSB_positives": 16,
            "2026_W42_report_page3_PHLSB_specimens": 9188,
            "interpretation": "Counts on pages 2 and 3 are distinct surveillance series; do not reconstruct the positivity denominator using the CSV newcount column, or replace CSV values with another series.",
        },
        "not_available_in_main_csv": ["site or district identifiers", "catchment polygons", "individual sewage samples",
            "raw qPCR measurements", "PMMoV normalization data", "clinical positivity denominator",
            "per-row release datetime", "historical revision flags"],
    })
    output.write_text(json.dumps(report, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
    print(json.dumps({"audit_json": str(output), "rows": current["nonblank_week_rows"],
                      "columns": current["column_count"], "all_blank_records": len(current["all_blank_records"]),
                      "date_boundary_errors": len(current["dates"]["boundary_errors"]),
                      "source_integrity_all_match": all(x["sha256_matches_retrieval_record"] for x in source_checks),
                      "models_run": False}, ensure_ascii=False))


if __name__ == "__main__":
    main()
