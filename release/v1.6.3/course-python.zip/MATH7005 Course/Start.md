# Course start and recovery

Install Python 3.12 dependencies as described in README.md. Then run `python launch.py --port 8501` from this directory and open `http://127.0.0.1:8501`. The launcher uses the active Python environment and the explicit course entry.

The supplied outputs are ready for local viewing. `saved_results/` contains the unchanged numerical reference. To reproduce, use `python scripts/reproduce_course.py --help` and its isolated-run options, or copy this package to a new directory and execute `python -m src.pipeline --config config.yaml --stage all`.

Run applicable tests after outputs exist:

```bash
python -m pytest -q -k "not test_frozen_source_bytes_match_independent_catalogue"
python scripts/check_report_links.py
```

If dependencies are missing, install requirements.lock.txt before going offline. If the port is occupied, select another --port. If input, code, configuration and output receipts differ, preserve the failed copy and rebuild in a new directory. Do not hand-edit receipt hashes. The pipeline only reads packaged data and writes the configured local outputs.

For the demonstration sequence and personal preparation, use Course.md. Current execution results are in STATUS.md. Retain the frozen scientific configuration 1.1 and its validation choices; changes intended to improve already-viewed test results belong in a separately labelled experiment.
