"""Recompute delivered forecast results without importing production algorithms.

Usage from the project root:
  .venv/bin/python scripts/check_numeric_independent.py

Reads original source bytes and existing CSVs. Writes only
work/local_review/numeric_review.json and numeric_review.md. No pipeline runs.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path

import numpy as np
import pandas as pd
import yaml


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def source_entries(value):
    if isinstance(value, dict):
        if 'sha256' in value and 'local_file' in value:
            yield value
        for child in value.values():
            yield from source_entries(child)
    elif isinstance(value, list):
        for child in value:
            yield from source_entries(child)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--baseline', type=Path, help='First-version directory; defaults to bundled docs/首版基线')
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[1]
    old = args.baseline.resolve() if args.baseline else root / 'docs/首版基线'
    if not (old / 'outputs/predictions.csv').is_file():
        parser.error('Bundled baseline is missing; supply --baseline with the first-version directory.')
    config = yaml.safe_load((root / 'config.yaml').read_text(encoding='utf-8'))
    files = ['predictions.csv', 'metrics.csv', 'raw_metrics.csv', 'paired_errors.csv',
             'raw_paired_errors.csv', 'bootstrap_sensitivity.csv', 'raw_bootstrap_sensitivity.csv',
             'stage_metrics.csv', 'raw_stage_metrics.csv']
    digests = {f: sha256(root / 'outputs' / f) for f in files}
    frames = {f: pd.read_csv(root / 'outputs' / f, float_precision='round_trip') for f in files}
    p = frames['predictions.csv']
    sc = p[p.status.eq('ok')].copy()
    future = p[p.status.eq('awaiting_observation')].copy()
    old_file = old / 'outputs/predictions.csv'
    oldp = pd.read_csv(old_file, float_precision='round_trip')
    oldsc = oldp[oldp.status.eq('ok')]
    checks, maxdiff = {}, {}

    def check(name, condition):
        checks[name] = bool(condition)
        if not condition:
            raise AssertionError(name)

    def compare(name, left, right, tol=1e-10):
        left, right = np.asarray(left, dtype=float), np.asarray(right, dtype=float)
        check(name + '_shape', left.shape == right.shape)
        check(name + '_missing', np.array_equal(np.isnan(left), np.isnan(right)))
        maxdiff[name] = float(np.nanmax(np.abs(left - right))) if np.isfinite(left).any() else 0.0
        check(name + '_values', np.allclose(left, right, rtol=tol, atol=tol, equal_nan=True))

    sources = []
    catalogue = json.loads((root / 'data/source_catalog.json').read_text(encoding='utf-8'))
    for entry in source_entries(catalogue):
        content = (root / 'data' / entry['local_file']).read_bytes()
        actual = hashlib.sha256(content).hexdigest()
        check('source_' + entry['local_file'], actual == entry['sha256'] and len(content) == entry['bytes'])
        sources.append({'file': entry['local_file'], 'sha256': actual, 'bytes': len(content)})

    check('540_scored', len(sc) == len(oldsc) == 540)
    keys = ['split', 'anchor_year', 'anchor_week', 'target_year', 'target_week', 'horizon', 'model_id']
    check('unique_keys', not p.duplicated(keys).any())
    a, b = sc.set_index(keys).sort_index(), oldsc.set_index(keys).sort_index()
    check('same_540_keys', a.index.equals(b.index))
    for column in ['raw_prediction', 'prediction', 'observed', 'abs_error_pp', 'squared_error_pp2',
                   'raw_abs_error_pp', 'raw_squared_error_pp2', 'lambda']:
        compare('old_vs_new_' + column, a[column], b[column])
    for column in ['train_anchor_keys', 'n_train', 'source_version', 'evaluation_vintage']:
        check('old_vs_new_' + column, a[column].equals(b[column]))
    compare('clip_definition', p.prediction, p.raw_prediction.clip(0, 1), tol=1e-13)
    check('clipped_flag', np.array_equal(p.was_clipped.to_numpy(), (p.raw_prediction != p.prediction).to_numpy()))
    check('6_unscored', len(future) == 6)
    check('unscored_empty_targets_errors', future[['observed', 'abs_error_pp', 'squared_error_pp2',
                                                  'raw_abs_error_pp', 'raw_squared_error_pp2']].isna().all().all())
    check('future_one_issue', future.issue_at.nunique() == 1)
    check('future_mode', future.backtest_mode.eq('frozen_snapshot_projection').all())
    check('future_horizons_targets', future.groupby('horizon').target_week.first().to_dict() == {1: 43, 2: 44})
    group_keys = ['split', 'anchor_from', 'target_from', 'horizon']
    check('same_origin_issue', p.groupby(group_keys)['issue_at'].nunique().eq(1).all())
    check('same_origin_truth', sc.groupby(group_keys)['observed'].nunique().eq(1).all())
    check('same_origin_three_models', p.groupby(group_keys)['model_id'].nunique().eq(3).all())

    # Rebuild source features independently. Sunday From + 11 days 23:59 is the
    # prespecified nominal issue time, including the verified W6 end-date repair.
    raw = pd.read_csv(root / 'data/covidx_data.csv', na_values=['/', '-'],
                      float_precision='round_trip').dropna(how='all').reset_index(drop=True)
    raw[['Year', 'Week']] = raw[['Year', 'Week']].astype(int)
    check('raw_dimensions', raw.shape == (194, 13))
    check('sewage_missing', raw.loc[raw.Sewage_viralload.isna(), ['Year', 'Week']].values.tolist()
          == [[2024, 17], [2024, 18]])
    starts = pd.to_datetime(raw.From, format='%d/%m/%Y')
    available = (starts + pd.Timedelta(days=11, hours=23, minutes=59)).dt.tz_localize('Asia/Hong_Kong')
    weekkeys = [f'{r.Year}W{r.Week}' for r in raw.itertuples()]
    keyindex = {key: i for i, key in enumerate(weekkeys)}
    clinical, water = raw.SARSCoV2_proportion.to_numpy(), raw.Sewage_viralload.to_numpy()
    x = np.full((len(raw), 6), np.nan)
    for t in range(2, len(raw)):
        x[t] = np.r_[clinical[t - np.arange(3)], np.log1p(water[t - np.arange(3)])]
    complete = np.isfinite(x).all(axis=1)
    refit_diffs, state_diffs = [], []
    for row in sc.itertuples():
        t, h = keyindex[f'{row.anchor_year}W{row.anchor_week}'], row.horizon
        ids = np.flatnonzero(complete & (np.arange(len(raw)) + h <= t))
        check(f'training_{row.split}_{t}_{h}_{row.model_id}',
              row.train_anchor_keys == '|'.join(weekkeys[i] for i in ids) and row.n_train == len(ids))
        check(f'maturity_{t}_{h}', np.all(ids + h <= t) and
              (available.iloc[ids + h] <= pd.Timestamp(row.issue_at)).all())
        if row.model_id == 'persistence':
            expected = clinical[t]
        else:
            columns = 3 if row.model_id == 'clinical_ridge' else 6
            train = x[ids, :columns]
            mean, scale = train.mean(axis=0), train.std(axis=0)
            scale[scale == 0] = 1
            z, y = (train - mean) / scale, clinical[ids + h]
            lam = float(sc.loc[row.Index, 'lambda'])
            # Independent augmented least squares, avoiding production solve.
            coef = np.linalg.lstsq(np.vstack([z, np.sqrt(len(y) * lam) * np.eye(columns)]),
                                  np.r_[y - y.mean(), np.zeros(columns)], rcond=None)[0]
            expected = float(((x[t, :columns] - mean) / scale) @ coef + y.mean())
            state = json.loads(row.model_state)
            state_diffs.extend(np.abs(np.asarray(state['mean']) - mean).tolist())
            state_diffs.extend(np.abs(np.asarray(state['scale']) - scale).tolist())
        refit_diffs.append(abs(expected - row.raw_prediction))
    maxdiff['independent_augmented_lstsq_prediction'] = max(refit_diffs)
    check('independent_ridge_refits', max(refit_diffs) < 1e-10)
    maxdiff['training_standardization'] = max(state_diffs)
    check('independent_training_standardization', max(state_diffs) < 1e-12)

    interval_details, aggregate_details = [], []
    for prefix, column, mode in [('', 'prediction', 'clipped'), ('raw_', 'raw_prediction', 'raw')]:
        metrics, paired = frames[prefix + 'metrics.csv'], frames[prefix + 'paired_errors.csv']
        intervals, stages = frames[prefix + 'bootstrap_sensitivity.csv'], frames[prefix + 'stage_metrics.csv']
        check(mode + '_metrics_rows', len(metrics) == 12)
        check(mode + '_interval_rows', len(intervals) == 12)
        check(mode + '_no_future_metrics', set(metrics.split) == {'validation', 'test'})
        check(mode + '_score_mode', metrics.score_mode.eq(mode).all())
        all_abs = 100 * np.abs(sc.observed.to_numpy() - sc[column].to_numpy())
        compare(mode + '_pointwise_abs_error', all_abs, sc['raw_abs_error_pp' if prefix else 'abs_error_pp'])
        compare(mode + '_pointwise_squared_error', all_abs ** 2,
                sc['raw_squared_error_pp2' if prefix else 'squared_error_pp2'])
        for (split, h), group in sc.groupby(['split', 'horizon']):
            models = {m: g.sort_values('anchor_from').reset_index(drop=True) for m, g in group.groupby('model_id')}
            n = 50 if split == 'validation' else 40
            check(f'{mode}_{split}_h{h}_n', all(len(g) == n for g in models.values()))
            errors = {m: 100 * (g.observed.to_numpy() - g[column].to_numpy()) for m, g in models.items()}
            ae = {m: abs(error) for m, error in errors.items()}
            delta = ae['clinical_ridge'] - ae['combined_ridge']
            dates = pd.to_datetime(models['clinical_ridge'].anchor_from).to_list()
            labels = models['clinical_ridge'].stage_label.to_numpy()
            m = metrics[(metrics.split == split) & (metrics.horizon == h)].set_index('model_id')
            pe = paired[(paired.split == split) & (paired.horizon == h)].sort_values('anchor_from')
            check(f'{mode}_{split}_h{h}_paired_id', m.paired_set_id.nunique() == 1 and
                  pe.paired_set_id.nunique() == 1 and m.paired_set_id.iloc[0] == pe.paired_set_id.iloc[0])
            for model, error in errors.items():
                compare(f'{mode}_{split}_h{h}_{model}_metrics', [abs(error).mean(), np.sqrt(np.mean(error ** 2))],
                        [m.loc[model, 'mae_pp'], m.loc[model, 'rmse_pp']])
            compare(f'{mode}_{split}_h{h}_gain', [delta.mean(), 100 * delta.mean() / ae['clinical_ridge'].mean()],
                    [m.loc['combined_ridge', 'delta_mae_pp'], m.loc['combined_ridge', 'relative_gain_pct']])
            compare(f'{mode}_{split}_h{h}_paired', np.column_stack([ae['clinical_ridge'], ae['combined_ridge'], delta]),
                    pe[['clinical_abs_error_pp', 'combined_abs_error_pp', 'delta_error_pp']])
            for label in set(labels):
                ix = labels == label
                stage = stages[(stages.split == split) & (stages.horizon == h) & (stages.stage_label == label)].iloc[0]
                compare(f'{mode}_{split}_h{h}_stage_{label}',
                        [ix.sum(), ae['clinical_ridge'][ix].mean(), ae['combined_ridge'][ix].mean(), delta[ix].mean()],
                        [stage.n_origins, stage.clinical_mae_pp, stage.combined_mae_pp, stage.delta_mae_pp])
            for block_size in (2, 4, 8):
                blocks, covered = [], set()
                for j in range(n - block_size + 1):
                    if all(dates[j + k] - dates[j] == pd.Timedelta(weeks=k) for k in range(block_size)):
                        blocks.append(delta[j:j + block_size])
                        covered.update(range(j, j + block_size))
                check(f'{mode}_{split}_h{h}_b{block_size}_coverage', len(covered) == n)
                rng = np.random.default_rng(config['evaluation']['seed'])
                draws = rng.integers(0, len(blocks), size=(config['evaluation']['bootstrap_repeats'], math.ceil(n / block_size)))
                means = np.array([np.concatenate([blocks[int(i)] for i in draw])[:n].mean() for draw in draws])
                level = config['evaluation']['bootstrap_confidence_level']
                lo, hi = np.quantile(means, [(1 - level) / 2, (1 + level) / 2])
                line = intervals[(intervals.split == split) & (intervals.horizon == h) & (intervals.block_weeks == block_size)].iloc[0]
                compare(f'{mode}_{split}_h{h}_b{block_size}_interval', [delta.mean(), lo, hi, len(blocks), n, n, 0],
                        [line.delta_mae_pp, line.low, line.high, line.n_blocks, line.n_origins, line.n_covered, line.n_uncovered])
                if block_size == 4:
                    compare(f'{mode}_{split}_h{h}_primary_ci', [lo, hi],
                            [m.loc['combined_ridge', 'delta_ci_low_pp'], m.loc['combined_ridge', 'delta_ci_high_pp']])
                interval_details.append({'score_mode': mode, 'split': split, 'horizon': int(h),
                    'block_weeks': block_size, 'n_blocks': len(blocks), 'n_origins': n,
                    'independent_low': float(lo), 'independent_high': float(hi),
                    'max_abs_difference_pp': max(abs(lo - line.low), abs(hi - line.high))})
            aggregate_details.append({'score_mode': mode, 'split': split, 'horizon': int(h),
                'clinical_mae_pp': float(ae['clinical_ridge'].mean()), 'combined_mae_pp': float(ae['combined_ridge'].mean()),
                'delta_mae_pp': float(delta.mean()), 'relative_gain_pct': float(100 * delta.mean() / ae['clinical_ridge'].mean()),
                'combined_n_clipped': int(models['combined_ridge'].was_clipped.sum())})
    check('raw_clipped_same_sets', frames['metrics.csv'].paired_set_id.tolist() == frames['raw_metrics.csv'].paired_set_id.tolist())
    check('source_files_unchanged_during_review', all(sha256(root / 'outputs' / f) == digest for f, digest in digests.items()))
    reviewed = ['src/backtest.py', 'src/features.py', 'src/data.py',
                'tests/test_forecast_review.py', 'tests/test_acceptance.py']
    summary = {'reviewed_at_utc': datetime.now(timezone.utc).isoformat(),
        'scope': 'Independent read-only numerical review; no production algorithm or pipeline called',
        'script': str(Path(__file__).resolve()), 'script_sha256': sha256(__file__),
        'new_root': str(root), 'old_root': str(old), 'baseline_prediction_sha256': sha256(old_file),
        'scored_predictions': len(sc), 'unscored_predictions': len(future), 'interval_count': len(interval_details),
        'all_checks_passed': all(checks.values()), 'check_count': len(checks),
        'maximum_absolute_differences': maxdiff, 'source_hashes': sources, 'input_csv_sha256': digests,
        'aggregate_recalculations': aggregate_details, 'interval_recalculations': interval_details,
        'code_review_scope': reviewed, 'code_review_source_sha256': {f: sha256(root / f) for f in reviewed},
        'code_review_findings': [],
        'additional_readonly_review': {
            'scope': 'validate_pattern_frozen and pipeline preflight placement',
            'conclusion': 'Existing frozen pattern decisions are checked before write_run_state and prepare; initial freeze and post-warmup perturbations remain supported.',
            'recovery_boundary': 'If a freeze file is absent, all/validate may rebuild from the fixed development window. test/export require stage receipts. This is the accepted recovery behavior, not a blocking defect.',
            'source_sha256': {f: sha256(root / f) for f in ['src/pattern_pipeline.py', 'src/pipeline.py']}},
        'limits': ['Numerical assertion count is not a pytest test count.',
                   'UI, browser appearance, stage-artifact protection and clustering/LOF are outside this review.']}
    out = root / 'work/local_review'
    out.mkdir(parents=True, exist_ok=True)
    (out / 'numeric_review.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    historical_max = max(maxdiff['old_vs_new_prediction'], maxdiff['old_vs_new_raw_prediction'])
    interval_max = max(row['max_abs_difference_pp'] for row in interval_details)
    note = f'''# 本机独立数值复核

检查时刻（UTC）：{summary['reviewed_at_utc']}。已读取包内 CSV，未运行全管线。输入哈希及逐组重算记录见 numeric_review.json。

540 条已评分预测与旧首版同键，raw_prediction 与 prediction 最大绝对差 {historical_max:.17g}。从原始 CSV 独立重建训练行和标准化，使用增广最小二乘重算 360 条 Ridge 预测，最大绝对差 {maxdiff['independent_augmented_lstsq_prediction']:.17g}。

raw/clipped 逐点误差、各 12 行汇总、各 180 行配对误差、各 8 行阶段结果通过独立复算。24 组区间的最大差为 {interval_max:.17g} 个百分点。9 份原始来源哈希及尺寸匹配，6 条未评分记录共享运行时刻且观测/误差为空。

共 {len(checks)} 项数值断言通过；该数字不代表 pytest 测试数量。复现命令：

```bash
.venv/bin/python scripts/check_numeric_independent.py
```

已审核 data/features/backtest 及相关测试，当前冻结结果范围内未发现重要遗漏。另只读检查模式冻结验证及 preflight 调用：已有冻结决定在运行状态和分析文件写入前核对；初次冻结与开发期之后的未来扰动路径保留。冻结文件缺失时，all/validate 可按固定开发期重建，test/export 仍需阶段回执；这是已接受的恢复语义边界。界面、完整产物保护和聚类/LOF 算法由其他流程验证。完整历史 as-of 回测继续属于未实现范围。
'''
    (out / 'numeric_review.md').write_text(note, encoding='utf-8')
    print(json.dumps({'all_checks_passed': True, 'assertions': len(checks), 'scored': len(sc),
                      'unscored': len(future), 'intervals': len(interval_details),
                      'max_old_vs_new_prediction': historical_max, 'max_interval_error_pp': interval_max,
                      'report': str(out / 'numeric_review.json')}, ensure_ascii=False))


if __name__ == '__main__':
    main()
