"""Build a portable course PDF using the bundled open-source font.

pip install -r requirements-report.txt
python scripts/build_report_pdf.py
python scripts/build_report_pdf.py --input 检验报告.md --output 检验报告.pdf --no-plot
"""
from pathlib import Path
import argparse
import csv
from datetime import date
import os
import re
from html import escape
import yaml
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, KeepTogether, PageBreak
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib import colors
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfbase.cidfonts import UnicodeCIDFont
from reportlab.graphics.shapes import Drawing, String, Line
from reportlab.graphics.charts.lineplots import LinePlot

ROOT = Path(__file__).resolve().parents[1]
W, H = 595.276, 841.89
TEXT_W = W - 92
FONT = None
STYLES = {}


def setup_font(custom=None):
    global FONT, STYLES
    paths = [Path(custom)] if custom else []
    if os.environ.get('WBE_REPORT_FONT'):
        paths.append(Path(os.environ['WBE_REPORT_FONT']))
    paths += [ROOT / 'assets/fonts/NotoSansSC-Regular.ttf', Path('/System/Library/Fonts/Supplemental/Arial Unicode.ttf')]
    if custom and not Path(custom).is_file():
        raise FileNotFoundError('Requested PDF font does not exist: ' + custom)
    found = next((path for path in paths if path.is_file()), None)
    if found:
        pdfmetrics.registerFont(TTFont('ReportCJK', str(found))); FONT = 'ReportCJK'
        pdfmetrics.registerFontFamily(FONT, normal=FONT, bold=FONT, italic=FONT, boldItalic=FONT)
    else:
        pdfmetrics.registerFont(UnicodeCIDFont('STSong-Light')); FONT = 'STSong-Light'
    STYLES = {
        'title': ParagraphStyle('title', fontName=FONT, fontSize=21, leading=31, textColor=colors.HexColor('#142c43'), spaceAfter=13),
        'sub': ParagraphStyle('sub', fontName=FONT, fontSize=10, leading=16, textColor=colors.HexColor('#506477'), spaceAfter=17),
        'h2': ParagraphStyle('h2', fontName=FONT, fontSize=13, leading=21, spaceBefore=15, spaceAfter=8, keepWithNext=True, textColor=colors.HexColor('#142c43')),
        'h3': ParagraphStyle('h3', fontName=FONT, fontSize=11, leading=18, spaceBefore=10, spaceAfter=6, keepWithNext=True),
        'body': ParagraphStyle('body', fontName=FONT, fontSize=9.5, leading=16.5, spaceAfter=9, allowWidows=0, allowOrphans=0, wordWrap=None, textColor=colors.HexColor('#203243')),
        'cell': ParagraphStyle('cell', fontName=FONT, fontSize=8.5, leading=13, wordWrap=None),
        'caption': ParagraphStyle('caption', fontName=FONT, fontSize=8.5, leading=14, textColor=colors.HexColor('#4a5b6b'), spaceAfter=10),
        'link': ParagraphStyle('link', fontName=FONT, fontSize=8.5, leading=13, textColor=colors.HexColor('#196a72'), spaceAfter=0),
        'code': ParagraphStyle('code', fontName=FONT, fontSize=8, leading=13, spaceAfter=3, wordWrap=None, backColor=colors.HexColor('#f1f5f6')),
    }


def p(text, style='body'):
    text = escape(str(text).replace('ᵀ', '^T').replace('ȳ', 'y_mean').replace('‖', '||').replace('10⁻¹²', '1e-12'))
    text = re.sub(r'\*\*(.*?)\*\*', r'<b>\1</b>', text)
    text = re.sub(r'`([^`]+)`', r'\1', text)
    return Paragraph(text, STYLES[style])


def table(rows):
    n = len(rows[0]); header = rows[0]
    if n == 6 and header[0] in ('评分方式', 'Prediction values'):
        weights = [1.35, .5, 1.8 if header[2] in ('模型','Model') else .8, .8, 1.2, 1.2]
    elif n == 3 and header[0] == 'Course skill':
        weights = [.7, 1.4, 1.6]
    elif n == 8:
        weights = [.8,.4,.7,.5,.8,.8,.8,.65]
    elif n == 6:
        weights = [.6, .95, .7, 1.35, 1.35, 1.25]
    elif n == 5:
        weights = [1, 1.15, 1.1, 1.4, 1.5]
    elif n == 4:
        weights = [1.15, 1.5, 1.2, 1.2]
    else:
        weights = [1] * n
    widths = [TEXT_W * w / sum(weights) for w in weights]
    t = Table([[p(c, 'cell') for c in row] for row in rows], colWidths=widths, repeatRows=1, hAlign='LEFT')
    t.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#e5edef')),
        ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.HexColor('#f5f8f9')]),
        ('GRID', (0, 0), (-1, -1), .4, colors.HexColor('#d9e1e5')),
        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'), ('LEFTPADDING', (0, 0), (-1, -1), 6),
        ('RIGHTPADDING', (0, 0), (-1, -1), 6), ('TOPPADDING', (0, 0), (-1, -1), 6),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 6),
    ]))
    return t


def plot(out, horizon):
    with (out / 'predictions.csv').open(encoding='utf-8-sig') as handle:
        rows = list(csv.DictReader(handle))
    selected = [row for row in rows if row['split'] == 'test' and int(row['horizon']) == horizon]
    grouped = {model: sorted([row for row in selected if row['model_id'] == model], key=lambda row: row['target_from'])
               for model in ('clinical_ridge', 'combined_ridge')}
    base = grouped['clinical_ridge']
    if not base: raise ValueError('No test observations for PDF chart')
    start = date.fromisoformat(base[0]['target_from'][:10])
    xvals = [(date.fromisoformat(row['target_from'][:10]) - start).days for row in base]
    drawing = Drawing(TEXT_W, 265)
    chart = LinePlot(); chart.x = 38; chart.y = 38; chart.width = TEXT_W - 55; chart.height = 159
    datasets = [[float(row['observed']) * 100 for row in base]] + [[float(row['prediction']) * 100 for row in grouped[model]] for model in grouped]
    # Separate line segments at missing calendar weeks, preserving actual time distances.
    palette = ['#142c43', '#bf7b39', '#1b8077']; segments = []; segment_colors = []
    for values, color in zip(datasets, palette):
        part = []
        for index, (x, y) in enumerate(zip(xvals, values)):
            if index and x - xvals[index - 1] != 7:
                if part: segments.append(part); segment_colors.append(color)
                part = []
            part.append((x, y))
        if part: segments.append(part); segment_colors.append(color)
    chart.data = segments
    chart.xValueAxis.valueMin = 0; chart.xValueAxis.valueMax = max(xvals[-1], 7)
    indices = sorted(set(round(i * (len(base) - 1) / 5) for i in range(6)))
    ticks = [xvals[i] for i in indices]; labels = {xvals[i]: base[i]['target_from'][5:10] for i in indices}
    chart.xValueAxis.valueSteps = ticks; chart.xValueAxis.labelTextFormat = lambda x: labels.get(int(x), '')
    chart.yValueAxis.valueMin = 0; chart.yValueAxis.valueMax = max(.1, max(max(values) for values in datasets) * 1.12)
    chart.yValueAxis.labelTextFormat = '%.1f'; chart.yValueAxis.visibleGrid = True
    chart.yValueAxis.gridStrokeColor = colors.HexColor('#e2e8ed')
    for axis in (chart.xValueAxis, chart.yValueAxis):
        axis.labels.fontName = FONT; axis.labels.fontSize = 8; axis.strokeColor = colors.HexColor('#8c9ba6')
    for index, color in enumerate(segment_colors):
        chart.lines[index].strokeColor = colors.HexColor(color); chart.lines[index].strokeWidth = 1.5
    drawing.add(chart); drawing.add(String(0, 244, f'h{horizon} test predictions and observations', fontName=FONT, fontSize=11))
    drawing.add(String(1, 196, '%', fontName=FONT, fontSize=9))
    for index, name in enumerate(('Observed', 'Clinical Ridge', 'Clinical + wastewater')):
        x = 74 + index * 137
        drawing.add(Line(x, 225, x + 14, 225, strokeColor=colors.HexColor(palette[index]), strokeWidth=2))
        drawing.add(String(x + 18, 221, name, fontName=FONT, fontSize=8))
    year_label = base[0]['target_from'][:4] if base[0]['target_from'][:4] == base[-1]['target_from'][:4] else base[0]['target_from'][:4] + '-' + base[-1]['target_from'][:4]
    drawing.add(String(185, 8, f'Target week starts ({year_label})', fontName=FONT, fontSize=9))
    return drawing, len(base)


def footer(canvas, doc):
    canvas.saveState(); canvas.setFont(FONT, 8); canvas.setFillColor(colors.HexColor('#657582'))
    canvas.drawString(46, 25, 'Hong Kong wastewater surveillance: frozen retrospective analysis')
    canvas.drawRightString(W - 46, 25, str(doc.page)); canvas.restoreState()


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config', default=str(ROOT / 'config.yaml'))
    parser.add_argument('--input'); parser.add_argument('--output'); parser.add_argument('--font')
    parser.add_argument('--no-plot', action='store_true')
    args = parser.parse_args(argv)
    config_path = Path(args.config).resolve(); root = config_path.parent
    config = yaml.safe_load(config_path.read_text(encoding='utf-8')); out = root / config['output']['directory']
    source = Path(args.input).resolve() if args.input else out / '项目报告.md'
    output = Path(args.output).resolve() if args.output else out / '项目报告.pdf'
    setup_font(args.font)
    lines = source.read_text(encoding='utf-8').splitlines(); story = []; i = 0; inserted = False; code = False
    title = next((line[2:] for line in lines if line.startswith('# ')), source.stem)
    while i < len(lines):
        line = lines[i].strip(); i += 1
        if line.startswith('```'):
            code = not code; continue
        if not line: continue
        if line == '<!-- pagebreak -->':
            story.append(PageBreak()); continue
        if code:
            story.append(p(line, 'code')); continue
        if line.startswith('# '): story.append(p(line[2:], 'title')); continue
        if i <= 4 and not line.startswith('#'):
            story.append(p(line, 'sub')); continue
        if line.startswith('### '): story.append(p(line[4:], 'h3')); continue
        if line.startswith('## '):
            if line in ('## 数据及时间', '## 2. Data, target and time') and not args.no_plot and not inserted:
                chart, count = plot(out, config['forecast']['primary_horizon'])
                story.append(KeepTogether([chart, p(f'Figure 1. {count} paired test origins. Predictions limited to 0-100%; horizontal axis gives the target week.', 'caption')]))
                inserted = True
            story.append(p(line[3:], 'h2')); continue
        if line.startswith('|'):
            rows = [[cell.strip() for cell in line.strip('|').split('|')]]
            while i < len(lines) and lines[i].startswith('|'):
                item = lines[i]; i += 1
                if re.fullmatch(r'[| :\-]+', item): continue
                rows.append([cell.strip() for cell in item.strip('|').split('|')])
            story.extend([table(rows), Spacer(1, 9)]); continue
        if line.startswith('- ['):
            links = [line]
            while i < len(lines) and lines[i].startswith('- ['):
                links.append(lines[i]); i += 1
            cells = []
            for link in links:
                match = re.match(r'- \[(.*?)\]\((.*?)\)', link)
                if match:
                    label, url = match.groups()
                    cells.append(Paragraph(f'<link href="{escape(url)}" color="#196a72">{escape(label)}</link>', STYLES['link']))
            if len(cells) % 2: cells.append('')
            link_table = Table([cells[n:n+2] for n in range(0, len(cells), 2)], colWidths=[TEXT_W / 2] * 2, hAlign='LEFT')
            link_table.setStyle(TableStyle([('VALIGN', (0, 0), (-1, -1), 'TOP'), ('LEFTPADDING', (0, 0), (-1, -1), 0),
                                           ('TOPPADDING', (0, 0), (-1, -1), 2), ('BOTTOMPADDING', (0, 0), (-1, -1), 2)]))
            story.append(link_table)
            continue
        story.append(p(line))
    output.parent.mkdir(parents=True, exist_ok=True)
    doc = SimpleDocTemplate(str(output), pagesize=(W, H), leftMargin=46, rightMargin=46, topMargin=42, bottomMargin=45,
                            title=title, author='Hong Kong wastewater project')
    doc.build(story, onFirstPage=footer, onLaterPages=footer)
    print(output)


if __name__ == '__main__': main()
