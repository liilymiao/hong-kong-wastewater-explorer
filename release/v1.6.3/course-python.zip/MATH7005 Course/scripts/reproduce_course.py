"""Rebuild in a new directory and compare every frozen CSV by stable row keys.

Usage: python scripts/reproduce_course.py --work-dir /path/to/new-run
Uses installed dependencies and bundled inputs; does not retrieve external data.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import time

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
PREDICTION_KEY = ['split', 'anchor_from', 'target_from', 'horizon', 'model_id']
KEYS = {
    'predictions.csv': PREDICTION_KEY,
    'validation_predictions.csv': PREDICTION_KEY,
    'validation_candidates.csv': PREDICTION_KEY + ['lambda'],
    'shared_lambda_predictions.csv': PREDICTION_KEY,
    'coverage.csv': ['split', 'horizon', 'system'],
    'delay_sensitivity.csv': ['anchor_year', 'anchor_week', 'horizon', 'delay_days'],
    'origins.csv': ['split', 'anchor_year', 'anchor_week', 'horizon'],
    'validation_scores.csv': ['model_id', 'horizon', 'lambda'],
    'patterns.csv': ['week_key'],
    'pattern_centers.csv': ['query_week_key', 'cluster_id'],
    'pattern_neighbors.csv': ['query_week_key', 'lof_k', 'neighbor_rank'],
    'pattern_selection.csv': ['cluster_k'],
    'pattern_sensitivity.csv': ['week_key', 'lof_k'],
    'pattern_sensitivity_summary.csv': ['period', 'lof_k'],
}
for prefix in ['', 'raw_', 'shared_lambda_']:
    KEYS[prefix + 'metrics.csv'] = ['split', 'horizon', 'score_mode', 'model_id']
    KEYS[prefix + 'paired_errors.csv'] = ['split', 'horizon', 'score_mode', 'anchor_from', 'target_from']
    KEYS[prefix + 'bootstrap_sensitivity.csv'] = ['split', 'horizon', 'score_mode', 'block_weeks']
    KEYS[prefix + 'stage_metrics.csv'] = ['split', 'horizon', 'score_mode', 'stage_label']


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def compare_results(reference, generated, *, rtol=1e-10, atol=1e-12):
    """Identifiers/text exact; numeric cells exact or within declared tolerance.

    Only the actual generation timestamp of unscored future projections may
    differ. Historical issue times, labels, model states and all other text
    fields remain exact. Each numerical difference is counted and bounded.
    """
    checks = []
    for path in sorted(Path(reference).glob('*.csv')):
        a = pd.read_csv(path)
        b = pd.read_csv(Path(generated) / path.name)
        if list(a) != list(b) or a.shape != b.shape:
            raise AssertionError(f'{path.name}: columns or dimensions differ')
        key = KEYS[path.name]
        if a.duplicated(key).any() or b.duplicated(key).any():
            raise AssertionError(f'{path.name}: duplicate stable row key')
        # Missing lambda for persistence is an explicit null component of a key.
        a = a.sort_values(key, na_position='last').reset_index(drop=True)
        b = b.sort_values(key, na_position='last').reset_index(drop=True)
        pd.testing.assert_frame_equal(a[key], b[key], check_exact=True)
        numeric = list(a.select_dtypes(include='number').columns)
        numeric_changes = []
        metadata_changes = []
        for column in a:
            if column in numeric:
                av, bv = a[column].to_numpy(), b[column].to_numpy()
                same = (av == bv) | (np.isnan(av) & np.isnan(bv))
                if not np.allclose(av, bv, rtol=rtol, atol=atol, equal_nan=True):
                    raise AssertionError(f'{path.name}/{column}: numeric values differ beyond tolerance')
                if not same.all():
                    finite = np.isfinite(av) & np.isfinite(bv)
                    numeric_changes.append({'column': column, 'changed_cells': int((~same).sum()),
                        'max_abs_difference': float(np.max(np.abs(av[finite] - bv[finite])))})
            else:
                same = a[column].fillna('<MISSING>').eq(b[column].fillna('<MISSING>'))
                if not same.all():
                    allowed = (column == 'issue_at' and 'split' in a and
                               a.loc[~same, 'split'].eq('future').all())
                    if not allowed:
                        raise AssertionError(f'{path.name}/{column}: nonnumeric values differ')
                    metadata_changes.append({'column': column, 'changed_rows': int((~same).sum()),
                        'reason': 'Unscored future projections record this run actual generation time.'})
        checks.append({'file': path.name, 'key': key, 'rows': len(a), 'numeric_columns': len(numeric),
            'numeric_cells': len(a) * len(numeric), 'numeric_changes': numeric_changes,
            'metadata_changes': metadata_changes, 'passed': True})
    if set(p.name for p in Path(reference).glob('*.csv')) != set(KEYS):
        raise AssertionError('Reference CSV inventory differs from the reviewed 26-file contract')
    return {'status': 'passed', 'files': len(checks), 'rows': sum(c['rows'] for c in checks),
        'numeric_cells': sum(c['numeric_cells'] for c in checks), 'rtol': rtol, 'atol': atol,
        'numeric_changed_cells': sum(d['changed_cells'] for c in checks for d in c['numeric_changes']),
        'checks': checks}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--work-dir', required=True, type=Path,
                        help='New directory for copied source, generated outputs, logs and comparison')
    args = parser.parse_args(argv)
    work = args.work_dir.expanduser().resolve()
    if work.exists():
        parser.error('work-dir already exists; choose a new directory to preserve previous evidence')
    if work == ROOT or ROOT in work.parents:
        parser.error('Choose a work-dir outside the source package')
    shutil.copytree(ROOT, work, ignore=shutil.ignore_patterns(
        '.venv', 'venv', '__pycache__', '.pytest_cache', '.git', 'outputs', '*.zip', '.DS_Store'))
    started = datetime.now(timezone.utc).isoformat()
    cmd = [sys.executable, '-m', 'src.pipeline', '--config', 'config.yaml', '--stage', 'all']
    tick = time.perf_counter()
    with (work / 'reproduction.log').open('w', encoding='utf-8') as log:
        result = subprocess.run(cmd, cwd=work, stdout=log, stderr=subprocess.STDOUT)
    report = {'started_utc': started, 'python': sys.version, 'command': cmd,
        'returncode': result.returncode, 'elapsed_seconds': round(time.perf_counter() - tick, 3),
        'config_sha256': digest(ROOT / 'config.yaml'),
        'source_sha256': digest(ROOT / 'data/covidx_data.csv')}
    if result.returncode == 0:
        try:
            report['comparison'] = compare_results(ROOT / 'saved_results', work / 'outputs')
            report['status'] = 'passed'
        except (AssertionError, OSError, ValueError) as exc:
            report['status'] = 'failed'; report['error'] = str(exc)
    else:
        report['status'] = 'failed'; report['error'] = 'Pipeline failed; see reproduction.log'
    (work / 'reproduction.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'status': report['status'], 'report': str(work / 'reproduction.json')}, ensure_ascii=False))
    return 0 if report['status'] == 'passed' else 1


if __name__ == '__main__':
    raise SystemExit(main())
