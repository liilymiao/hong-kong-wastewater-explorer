"""Check generated report sources and packaged local links without network access."""
import argparse
from html.parser import HTMLParser
import json
from pathlib import Path
import re
from urllib.parse import unquote, urlsplit


OFFICIAL_SOURCES = {
    "https://www.chp.gov.hk/files/pdf/covidx_spec_en.pdf",
    "https://www.chp.gov.hk/files/pdf/covid_flux_week42_22_10_2026_eng.pdf",
    "https://www.chp.gov.hk/files/pdf/covid_flux_week6_12_2_2026_eng.pdf",
}


class ReportLinks(HTMLParser):
    def __init__(self):
        super().__init__()
        self.links = []

    def handle_starttag(self, tag, attrs):
        if tag == "a":
            href = dict(attrs).get("href")
            if href:
                self.links.append(href)


def check_reports(root, report_directory="outputs"):
    root = Path(root).resolve()
    directory = root / report_directory
    checked, errors = {}, []
    for suffix in ("md", "html"):
        report = directory / f"项目报告.{suffix}"
        if not report.is_file():
            errors.append(f"Missing generated report: {report.relative_to(root)}")
            continue
        body = report.read_text(encoding="utf-8")
        if suffix == "html":
            parser = ReportLinks()
            parser.feed(body)
            links = parser.links
        else:
            links = re.findall(r"\[[^\]]+\]\(([^)]+)\)", body)
        checked[report.name] = links
        for expected in sorted(OFFICIAL_SOURCES | {"../Course.md"}):
            if expected not in links:
                errors.append(f"{report.name}: missing source {expected}")
        for href in links:
            parts = urlsplit(href)
            if parts.scheme in ("https", "http"):
                continue
            if parts.scheme or parts.netloc:
                errors.append(f"{report.name}: unsupported link {href}")
                continue
            if not parts.path:
                continue
            target = (report.parent / unquote(parts.path)).resolve()
            if not target.is_relative_to(root):
                errors.append(f"{report.name}: local target outside package {href}")
            elif not target.is_file():
                errors.append(f"{report.name}: missing packaged target {href}")
            elif target.suffix.lower() == ".pdf":
                errors.append(f"{report.name}: supporting PDF must use official source URL {href}")
        if "原件保留在内部证据档案" not in body and "Original course documents remain in the internal evidence archive" not in body:
            errors.append(f"{report.name}: missing course-source scope")
    if len(checked) == 2 and set(checked["项目报告.md"]) != set(checked["项目报告.html"]):
        errors.append("Markdown and HTML source links differ")
    return {"status": "failed" if errors else "passed",
            "reports": checked, "errors": errors,
            "network_checked": False,
            "scope": "Packaged relative targets, official-source URL identity, and course-source scope"}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--report-directory", default="outputs")
    args = parser.parse_args(argv)
    result = check_reports(args.root, args.report_directory)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 1 if result["errors"] else 0


if __name__ == "__main__":
    raise SystemExit(main())
