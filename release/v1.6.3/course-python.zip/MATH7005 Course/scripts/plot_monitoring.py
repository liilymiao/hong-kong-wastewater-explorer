"""Render only observed monitoring data; no fitted or forecast values.

Usage: python scripts/plot_monitoring.py [--font /path/to/cjk-font.otf]
Requires pandas and matplotlib. Run from any directory.
"""
from pathlib import Path
import argparse
import hashlib
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from matplotlib import font_manager
from matplotlib.ticker import LogLocator, LogFormatterMathtext
import pandas as pd


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--font", type=Path)
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[1]
    source = root / "data/covidx_data.csv"
    raw = pd.read_csv(source, dtype=str, keep_default_na=False)
    df = raw.loc[raw.apply(lambda row: any(str(v).strip() for v in row), axis=1)].copy()
    df["date"] = pd.to_datetime(df["From"], format="%d/%m/%Y")
    df = df.sort_values("date")
    df["p"] = pd.to_numeric(df["SARSCoV2_proportion"], errors="coerce") * 100
    df["w"] = pd.to_numeric(df["Sewage_viralload"], errors="coerce")
    if args.font:
        font_manager.fontManager.addfont(str(args.font))
        font_name = font_manager.FontProperties(fname=args.font).get_name()
    else:
        available = {f.name for f in font_manager.fontManager.ttflist}
        font_name = next((s for s in ("Noto Sans CJK SC", "Microsoft YaHei", "PingFang SC", "Arial Unicode MS") if s in available), None)
        if not font_name:
            raise SystemExit("A CJK font is required. Supply --font with a local font path.")
    plt.rcParams.update({"font.family": font_name, "font.size": 10,
                         "axes.unicode_minus": False, "svg.fonttype": "path"})
    fig, axes = plt.subplots(2, 1, sharex=True, figsize=(7.3, 4.9),
                             gridspec_kw={"hspace": 0.34})
    fig.subplots_adjust(left=0.13, right=0.98, top=0.88, bottom=0.15)
    fig.suptitle("香港已公布的污水与临床监测序列", x=0.13, ha="left", y=0.98, fontsize=13)
    axes[0].plot(df["date"], df["w"], color="#166D91", lw=1.7)
    axes[0].set_yscale("log")
    axes[0].yaxis.set_major_locator(LogLocator(base=10, numticks=5))
    axes[0].yaxis.set_major_formatter(LogFormatterMathtext())
    axes[0].set_ylabel("污水指标（copy/L）")
    axes[0].set_title("官方人均病毒载量指标 · 七日几何平均 · 对数坐标", loc="left", fontsize=10, pad=8)
    axes[1].plot(df["date"], df["p"], color="#B16833", lw=1.7)
    axes[1].set_ylim(bottom=0)
    axes[1].set_ylabel("临床阳性比例（%）")
    axes[1].set_title("PHLSB 呼吸道标本", loc="left", fontsize=10, pad=8)
    axes[1].xaxis.set_major_locator(mdates.MonthLocator(bymonth=[1,7]))
    axes[1].xaxis.set_major_formatter(mdates.DateFormatter("%Y-%m"))
    for ax in axes:
        ax.spines[["top", "right"]].set_visible(False)
        ax.spines[["left", "bottom"]].set_color("#C5CBD1")
        ax.grid(axis="y", color="#E6E9ED", linewidth=.6)
        ax.set_axisbelow(True)
        ax.tick_params(labelsize=9, length=3, color="#8C959D")
        ax.margins(x=.01)
    fig.text(.13, .045, "来源：香港卫生署 COVID-19 Express；冻结日 2026-10-23。污水缺测保留为空缺。", fontsize=8.2, color="#444444")
    output = root / "figures"
    output.mkdir(exist_ok=True)
    metadata = {"Description": "Observed data only. Source SHA256: " + hashlib.sha256(source.read_bytes()).hexdigest()}
    fig.savefig(output / "monitoring.png", dpi=220, metadata=metadata)
    fig.savefig(output / "monitoring.svg", metadata=metadata)
    plt.close(fig)
    print(f"Rendered observed data: {len(df)} weeks; sewage {df['w'].notna().sum()} values.")


if __name__ == "__main__":
    main()
