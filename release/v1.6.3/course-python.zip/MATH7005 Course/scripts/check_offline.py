"""Verify the analysis and AppTest backend with Python network calls blocked.

Run after installing dependencies: python scripts/check_offline.py
This does not claim that a real browser was switched to offline mode.
"""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import json
import os
import subprocess
import sys
import tempfile
import yaml

ROOT = Path(__file__).resolve().parents[1]
GUARD = '''import json, os, sys
from pathlib import Path
blocked = {"socket.connect", "socket.sendto", "socket.getaddrinfo", "socket.gethostbyname", "socket.gethostbyaddr"}
def reject_network(event, args):
    if event in blocked:
        with Path(os.environ["WBE_NETWORK_AUDIT_LOG"]).open("a", encoding="utf-8") as handle:
            handle.write(json.dumps({"event": event, "pid": os.getpid()}) + "\\n")
        raise RuntimeError("Offline verification blocked a Python network operation: " + event)
sys.addaudithook(reject_network)
'''


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config', default=str(ROOT / 'config.yaml'))
    args = parser.parse_args(argv)
    config_path = Path(args.config).resolve(); root = config_path.parent
    config = yaml.safe_load(config_path.read_text(encoding='utf-8'))
    out = root / config['output']['directory']; out.mkdir(parents=True, exist_ok=True)
    commands = [
        ('pipeline', [sys.executable, '-m', 'src.pipeline', '--config', str(config_path), '--stage', 'all']),
        ('app_backend', [sys.executable, '-m', 'pytest', 'tests/test_app.py', 'tests/test_app_review.py',
                         'tests/test_course_demo.py', 'tests/test_i18n.py', '-q', '-p', 'no:cacheprovider']),
    ]
    runs = []
    with tempfile.TemporaryDirectory(prefix='wbe-offline-') as directory:
        temporary = Path(directory)
        (temporary / 'sitecustomize.py').write_text(GUARD, encoding='utf-8')
        audit_path = temporary / 'network_attempts.jsonl'; audit_path.write_text('')
        env = dict(os.environ)
        env['PYTHONPATH'] = os.pathsep.join([str(temporary), str(root), env.get('PYTHONPATH', '')])
        env['WBE_NETWORK_AUDIT_LOG'] = str(audit_path)
        env['PYTHONDONTWRITEBYTECODE'] = '1'
        env['STREAMLIT_BROWSER_GATHER_USAGE_STATS'] = 'false'
        for name, command in commands:
            completed = subprocess.run(command, cwd=root, env=env, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
            (out / f'offline_{name}.log').write_text(completed.stdout, encoding='utf-8')
            runs.append({'component': name, 'command': command, 'returncode': completed.returncode,
                         'log_file': f'offline_{name}.log'})
            print(f'{name}: exit {completed.returncode}', flush=True)
            if completed.returncode:
                break
        attempts = [json.loads(line) for line in audit_path.read_text().splitlines() if line]
    passed = all(run['returncode'] == 0 for run in runs) and len(runs) == len(commands) and not attempts
    record = {'checked_at_utc': datetime.now(timezone.utc).isoformat(), 'passed': passed,
              'scope': 'Complete analysis plus Streamlit AppTest backend; installed dependencies; all Python child processes inherit the network audit hook.',
              'browser_offline_mode_verified': False, 'network_attempts': len(attempts),
              'blocked_operations': attempts, 'runs': runs}
    (out / 'offline_check.json').write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(record, ensure_ascii=False))
    return 0 if passed else 1


if __name__ == '__main__':
    raise SystemExit(main())
