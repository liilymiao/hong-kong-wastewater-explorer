Hong Kong Wastewater Explorer 1.5.3 — local Python course candidate
Scientific configuration 1.1; frozen input snapshot 2026-10-23.

Create a Python 3.12 virtual environment and install requirements.lock.txt.
Run python launch.py --port 8501 from this extracted folder.
The supplied sealed outputs allow immediate local use after installation.

For an independent rebuild and all 26 CSV comparisons:
    python scripts/reproduce_course.py --work-dir ../course-reproduction
The destination must be new. See README.md for platform commands.

The English report is in outputs/项目报告.pdf, .html and .md.
Course.md contains the ten-minute walkthrough and closed-book questions.
STATUS.md records this run; AI使用声明.md records AI assistance and pending
student review. No GitHub publication or Moodle submission was performed.

The public JavaScript website, video, copied course documents and private
source PDF/HTML archives are excluded. The generated report contains its
third-party Plotly renderer; all custom course source is Python. Source
links, use terms and hashes remain in the package.
