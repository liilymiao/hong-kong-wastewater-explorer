# 分析与工程实施规范

1.1 审查版，2026-10-24；数据冻结日仍为 2026-10-23。研究问题和背景见 Project.md。本文件记录已实现的冻结版本分析契约，同时保留历史档案与可选模型的后续设计。所有结果由实际运行生成；实际验收范围见 STATUS.md。

## 1 数据入口与观测单位

主输入为 data/covidx_data.csv，SHA256 为 1f348e7210d4e0dee1b8f1b8d722ee09086a3a87d2ecc7557e13c585d98e4e1c。冻结表含 194 个有效周、13 列，另有两条全空尾行。原始日期格式 DD/MM/YYYY，官方周从周日开始，保留 Year 与 Week，不用 ISO 周号重新覆盖。

分析单位为全港某一监测周。主目标 p_t = SARSCoV2_proportion，原值为比例；w_t = Sewage_viralload，保留官方定义与单位。数据表未包含采样点、行政区、原始 Ct、原始 PMMoV、逐周 PHLSB 标本分母或流量。

解析流程：保留文件字节 → 排除全空行 → 按显式缺失标记解析 → 解析 From → 检查周连续性与唯一键 → 按 data/date_overrides.csv 应用已验证的日期修正 → 生成派生表。保留 To_raw、To_corrected、correction_applied、correction_source_url、source_version、retrieved_utc。

2026W6 的 To 修正只在 Year、Week、From 与原错误值均匹配时生效；如最新文件已修正，应记录该规则无需应用。未知错误进入质量报告并处理受影响记录，不可套用一条规则覆盖所有日期异常。跨档案回测中修正日期只用于恢复日历标签，不能引入后续修订的数值。

SARSCoV2_newcount 与 proportion 的监测分母不同，禁止相除推算样本量。COVID19_GOPC 与 COVID19_FMC 可映射到内部 sentinel_public_clinic_rate，同时保留原字段与时期；该字段不进入首版主模型。

## 2 时间定义

`issue_at`：本次模拟预测或实际预测的运行时刻。

`anchor_week`：issue_at 时最新可用的完整监测周，索引为 t。

`target_week`：预测的目标监测周，索引为 t+h。

`feature_available_at`：输入数值在相应版本中的可获得时刻。

`label_available_at`：训练目标值在相应版本中的可获得时刻。

`archive_captured_at`：政府档案捕获时间，按文档解释为 GMT+8；与周报发布日期、HTTP Last-Modified 分列。

`evaluation_vintage`：用于最终评分的统一冻结目标版本。历史版本回测保留当时预测记录，之后与此评价版本对齐。

首版 primary horizon=2，secondary horizon=1。W42 数据覆盖 2026-10-11 至 17，报告于 10 月 22 日发布；h1 目标为 W43（10 月 18 至 24），h2 目标为 W44（10 月 25 至 31）。

对于冻结版本回测，名义 issue_at 采用经纠错周结束日期后五天、香港时间 23:59。此规则是回顾性时间假设；另做 +6、+7 天敏感性检查。界面显示“冻结版本回顾性回测”，不能称为已重建真实发布时刻。

完整历史归档回测尚未实施。后续设计以实际 archive_captured_at 作为运行时刻；从该版本选择最新完整周。若发布延迟使固定 h2 目标已经开始，应标出这一事实，并另外根据目标周开始日期大于 issue_at 的规则选择下一完整未来周。相同 h 和相同运行时刻的模型才进入配对比较。

动态未来周可能对应 h=3 或更远。固定 h2 预测始终对应原来的 t+2 目标，禁止更改其日期标签。动态时距若未训练对应模型，界面显示该目标预测不可用；新增时距需单独实现、验证与报告。

## 3 预先固定的数据划分

首 100 周（2023W5 至 2024W52）作为开发 warm-up。主验证使用 2025W1 至 W50 的 50 个 origin，h2 目标为 2025W3 至 W52。主最终测试使用 2026W1 至 W40 的 40 个 origin，h2 目标为 2026W3 至 W42。h1 的主对照使用相同 origin；额外 origin 的结果单独列出。

最终测试前固定输入、调参候选、超参数选择规则、缺测策略、随机种子和评价指标。第一个测试 issue_at 必须晚于全部验证开发证据的最晚可获得时刻，包括标签和特征；运行时检查，不依赖年度标签作推测。冻结文件保存配置、源版本、实际开发行及其哈希，测试前验证其完整性。

每个 origin t 采用 expanding-window 重训。可训练锚点 s 必须满足：

$$s+h \le t$$

同时要求特征和训练标签都实际可用。历史版本模式用 available_at 判断；冻结模式用公开周索引与名义运行日规则。不得先在完整数据上创建全部训练标签，再仅按特征日期截断而遗漏标签可用性。

每个 origin 至少有 52 条合格训练行，否则跳过并记录原因。40 与 50 是预定 origin 数量；最终输出还应报告合格数量与任何排除原因，不硬编码指标样本数。

历史档案目录共列出 149 个版本，目前只验证首尾两版可下载。后续按源 URL 与 time 参数调用官方接口，缓存不可变原件并记录校验值。没有覆盖的时段保持缺口，不根据最新文件伪造旧版本。

## 4 特征与公平比较

默认滞后包含当前和此前两周：

$$x^{C}_t = [p_t,p_{t-1},p_{t-2}]$$

$$x^{CW}_t = [p_t,p_{t-1},p_{t-2},\log(1+w_t),\log(1+w_{t-1}),\log(1+w_{t-2})]$$

log1p 是数值变换，不改变原始数据定义。w=0 仍可变换；负值视为输入异常。2024W17/W18 缺测不变为零。首版用 complete-case：当任一主要特征缺失，该训练行从两组比较模型共同移除。预测缺少联合特征的 origin 不进入配对主评价；可另展示仅临床的可用性结果。

为隔离污水特征的信息贡献，两组模型使用相同训练锚点和测试 origin。各自的标准化参数仅在当前共同训练样本的相应特征上拟合。标准差为零的列按约定置为 1 并记录，不能产生除零。

连续变化和过去三周均值可作为后续特征扩展，先在验证期比较。不得查看 2026 测试收益后追加“最佳”滞后。

## 5 三个预测系统

### 5.1 持续性

预测值为 p_t。对任一 h 使用同一最近观测，输出与其他模型一致的记录字段。

### 5.2 临床与联合岭回归

标准化后的特征矩阵为 X，目标为 y；先以训练均值中心化 y。优化均方损失与 L2 惩罚：

$$J(\beta)=\frac{1}{n}\lVert y_c-X\beta\rVert_2^2+\lambda\lVert\beta\rVert_2^2$$

$$\hat\beta=(X^\mathsf{T}X+n\lambda I)^{-1}X^\mathsf{T}y_c$$

实现使用 numpy.linalg.solve，不显式求逆。截距通过训练目标均值恢复且不惩罚。保留 loss、训练行数、特征均值和尺度、lambda、系数及数据截止信息。均方损失中的 n 与正规方程中的 nλ 必须一致。

候选 lambda=[0.0001,0.001,0.01,0.1,1,10]。按 (model_id, horizon) 分别选择，即临床与联合、h1 与 h2 各自选择验证 MAE 最小的 lambda；相差不超过 0.000001 个百分点时视为并列，选择更大 lambda。两组使用相同验证 origin、候选与预算。共用 lambda 的敏感性比较在同一 horizon 内，以两模型验证 MAE 的均值选择同一个 lambda，并同样先冻结后测试。

验证期保存全部候选参数的逐起点预测。最终所选参数在 2025 年的回放标为开发/验证结果，因为选参使用了完整验证期；该展示不称为当时可部署的历史预测。2026 年测试回放使用在测试前固定的参数。若需对更早时间严格重建参数可用性，另行采用仅使用当时过去资料的嵌套选参。

模型内部 y 为比例。将原始预测 clip 到 [0,1] 后用于主要评分，并保留 raw_prediction、prediction、was_clipped。原始预测评分和越界频率作为辅助输出。raw_metrics.csv、raw_paired_errors.csv、raw_bootstrap_sensitivity.csv 和 raw_stage_metrics.csv 用同一配对集合、相同配置，以 raw_prediction 独立重算全部指标。切换评分视角不重新选参或训练；原始视角不能沿用裁剪视角的区间或阶段结论。

### 5.3 可选小型 MLP

当前未实现；属于主体完成后的可选扩展。单隐层 4 或 8 个单元，tanh 隐层、线性输出；目标训练集标准化后拟合，逆变换并采用同样的 [0,1] 输出规则。NumPy 实现前向传播、反向传播和参数更新，有限差分检查梯度。网络规模、正则化、轮次与学习率用 2025 验证固定；随机种子及训练预算配对。完整结果保留，即使未优于岭回归。

## 6 聚类与异常任务

共同状态特征默认 [p_t, p_t-p_(t-2), log1p(w_t), log1p(w_t)-log1p(w_(t-2))]，全部只依赖已知周。采用训练参考期标准化。

首版回放的参考窗口固定为查询锚点 t 之前最多 104 个日历周，即 [t-104,t-1]；排除状态特征缺失的行，至少保留 52 行才拟合。查询周 t 不进入参考集、标准化或模型拟合。每个 origin 记录实际参考起止、合格行数和排除数。已冻结的模式参数在测试期保持固定，参考集按上述规则向前滚动。

K-means 候选 k=[2,3,4]，默认 20 次初始化、最多 300 次迭代、seed=42。在首 100 周完整状态上计算 silhouette，将开发状态的锚点按顺序分成五块，每次省略一块、重拟合标准化与聚类，再对全部开发状态分组，以平均 ARI 衡量连续状态向量删块稳定性。剩余向量的滞后输入保留，因此这不构成独立时间验证。选择分数为 silhouette 与平均 ARI 的等权平均，差距不超过 1e-12 时选较小 k。

最终中心排序后重新分配，保证 labels_ 与 predict(X) 一致，并同步计算 inertia。converged_ 表示最终分配是否与形成最终均值的分区一致；effective_k_ 记录实际占用簇数。不同参考点不足 k 时明确拒绝拟合。簇名称描述中心，附中心数值及成员；查询实际变化另列，相同数字簇号跨窗口不代表固定类别。冻结开发状态的 selection_states_sha256 在回放运行前再次核对。

LOF 主邻居数固定为 10，5 与 15 用于参数敏感性比较。实现训练参考集的 k-distance、reachability distance、local reachability density 和 LOF。确定距离并列处理规则：首版固定 k 个近邻并按稳定索引打破并列，写入方法说明。reference 中排除自身，距离为零时用明确小量稳定分母并统计重复点。

新周以 novelty 方式评分：参考邻居与参考密度来自过去数据，查询点不重新参与 reference 的拟合。前瞻回放不得用未来观测重算过去分数。探索页面允许显示全时段描述性分组，但必须与回放模式分开。

参数敏感性比较排名稳定性和原始数据解释。rank_as_of 按 lof_k 分组，只在截至查询周已有的有效分数中降序排名，并列使用最小名次；n_scored_as_of 为对应累计查询数。rank_all 与 rank_period 保留为全期和阶段事后排名，分别附 rank_all_cutoff_week、rank_period_cutoff_week。所有分数仍使用各查询自己的过去参考窗，排名属于描述性比较，不是统一校准的异常概率。若添加筛选阈值，需在开发期固定并记录定义。无真实异常标签时不计算真实事件的 precision、recall 或 AUROC。合成数据只用于距离、梯度、异常响应等技术测试，不能进入主数据、主图或临床结论。

LOF 高分不自动删除。峰值与异常组合仍属于需要保留的真实监测现象，只有有来源的输入错误才能通过日志修复。

## 7 评价公式与统计汇总

比例尺度的每周绝对误差乘 100，得到百分点。主要指标：

$$\mathrm{MAE}_{pp}=100\,\frac{1}{m}\sum_{i=1}^{m}|p_i-\hat p_i|$$

$$\Delta\mathrm{MAE}_{pp}=\mathrm{MAE}_{C,pp}-\mathrm{MAE}_{CW,pp}$$

$$\mathrm{RelativeGain}=100\,\Delta\mathrm{MAE}_{pp}/\mathrm{MAE}_{C,pp}$$

ΔMAE 正值表示联合模型误差更低。分母为零时 relative gain 为缺失并说明原因。辅助 RMSE 同样以百分点报告。主结论不使用 MAPE。

所有系统的配对主表使用共同 origin、target、horizon 和 evaluation_vintage 的交集。保存各自可运行覆盖率，避免只展示共同集合而隐去联合模型缺测造成的覆盖变化。

对逐周配对误差差值 d_i=|p_i-pred_C|-|p_i-pred_CW| 做 moving-block bootstrap，block=4 周，重复 2000 次，seed=42；block=2 与 8 作为敏感性。只在连续周段内构造完整时间块，不能把缺口两边当成相邻周。从候选块均匀有放回抽样，拼接至原样本数并截取前 m 项；报告均值差的 2.5% 与 97.5% 分位经验区间、候选块数与测试周数。若无完整块，或任何参与点估计的评价周不被有效块覆盖，则该区间不可用，并记录原因、块数及覆盖情况。不能仅从较长连续段抽样而静默丢掉孤立短段。

当前阶段标签在开发设计中固定为 p_t−p_(t−2) 的符号：大于零为上升、小于零为下降、等于零为持平。它只使用起点已经知道的临床值，与按簇中心命名的联合状态分开；不能依据未来整段峰值回填成当时已知阶段。

## 8 当前工程结构、运行与产物检查

`src/data.py`：load_snapshot、apply_date_overrides、load_vintages、validate_week_index。

`src/features.py`：build_features、eligible_training_rows、make_origin_manifest。

`src/models.py`：Persistence、RidgeRegressor、Standardizer，MLP 可另建模块。

`src/patterns.py`：KMeans、LOFNovelty。

`src/backtest.py`：rolling_validate、freeze_config、rolling_test、paired_evaluate。

`src/outputs.py`：来源与结果导出、模型说明。

`app.py`：读取派生数据和结果，提供概览、回放、比较、状态与异常四个页面。

`tests/`：日期及单位、标签可用性、未来扰动、数值算法、配对评价的必要测试。

`outputs/`：实际运行结果与日志。未运行时不放虚构示例结果。

建议 Python 3.12，依赖按 requirements.lock.txt 安装；环境建立见 README。核心使用 numpy、pandas、plotly、streamlit、pyyaml、pytest，scikit-learn 仅用于开发期对照。src/configuration.py 验证受支持配置，src/artifacts.py 管理阶段记录及产物一致性；实际 Python 与依赖版本由运行记录保留。

当前命令：

```bash
python -m src.pipeline --config config.yaml --stage all
python scripts/check_report_links.py
python -m pytest --junitxml=outputs/test_results.xml -q -k "not test_frozen_source_bytes_match_independent_catalogue"
python launch.py --port 8501
```

课程源码包须完成 all 后再启动；完整应用包带有与当前源码匹配的密封产物，可直接启动。上述公开包测试仅排除依赖内部 PDF/HTML 原件的来源档案测试，其余来源校验仍保留。报告生成器属于代码回执范围，改动后在独立副本重建全链条。

也可依次运行 audit、validate、test、export。test 在写入前核对验证阶段记录，export 在写入前核对测试阶段记录，且不重写建模输入。导出成功后形成 artifact_manifest.json，应用对配置、源、代码、产物和运行状态作一致性检查。失败或混杂产物不可作为完整结果展示；原始数据审计也可单独执行 `python data/audit_data.py`。哈希说明同次分析的一致性，算法有效性仍由数值与时间测试检验。

## 9 输出表结构

predictions.csv 必需字段：

```text
run_id,backtest_mode,source_version,evaluation_vintage,issue_at,
anchor_year,anchor_week,anchor_from,anchor_to,
target_year,target_week,target_from,target_to,horizon,
model_id,feature_set,n_train,lambda,raw_prediction,prediction,
observed,abs_error_pp,squared_error_pp2,was_clipped,status
```

无实际目标时 observed 与误差留空，status=awaiting_observation。

metrics.csv 必需字段：

```text
run_id,backtest_mode,horizon,model_id,paired_set_id,n_origins,
mae_pp,rmse_pp,delta_mae_pp,relative_gain_pct,
delta_ci_low_pp,delta_ci_high_pp,n_clipped,coverage
```

非联合模型的增量列留空。paired_set_id 由有序 origin/target/horizon/version 键计算，配对集合不同的结果不能直接相减。

patterns.csv 保留 source_version、issue_at、week_key、cluster_id、cluster_label、cluster_k、lof_score、lof_k、reference_start、reference_end、n_reference、source_row_key，另有 kmeans_converged、kmeans_effective_k、kmeans_n_iter、kmeans_inertia。

pattern_sensitivity.csv 记录 query_from、每个 lof_k 的分数、rank_as_of、n_scored_as_of、rank_all、rank_period 及两项截止周；汇总表另记 ranking_cutoff_week。中心和近邻表保留成员周、距离、密度与原始观测。config.json、runtime.json 及日志记录运行设置；stage_validate.json、stage_test.json 和 artifact_manifest.json 关联生成阶段及其文件。

## 10 历史档案的后续实施

根据 data/archive_versions.json 和官方 API 文档请求版本；保留原始 payload、捕获时刻、校验值、有效周范围和列名。逐版本解析 GOPC/FMC，核对数据连续性；优先覆盖验证与测试起点。

真实 as-of 结果可使用档案捕获时刻为运行时刻，标签与输入都从该版本读取。报告发布日若只有日期没有时间，另存精度标记，不能构造未经核实的精确时间。只有两个已核实发布日期的样本不足以建立全时期日历。

最终已知目标可用当前冻结版本统一评分；此外可补首报目标评分，明确两种评价版本。任何当前表对旧表的替换必须作为修订敏感性分析单列，不得悄然覆盖历史输入。

## 11 扩展顺序

冻结版本的三个核心任务和本地应用已有实现；后续先巩固复现与个人解释，再实现足够覆盖的历史档案回测。流感为后续跨病原体扩展，需要另行整理周报中的污水指标并保留 PMMoV 归一化口径。采样点级地图、化学暴露和污水 ARG 不属于首版数据范围。

近期方法论文讨论可选 Zeng 等人的 2023 AAAI 论文 Are Transformers Effective for Time Series Forecasting。讨论线性直接预测与分解思想的适用条件，联系小样本基线和任务时距。文献计数证据见 sources/course_optional_paper_openalex.json；本题无需据此增加大型 Transformer。


## 12 课程提交候选 1.5.3（2026-11-11）

科学配置与上述公式保持 1.1。本轮英文报告在 outputs/项目报告.md 中由 src/outputs.py 生成，包含实际函数与测试映射、原始和限定输出、2/4/8 周块区间及事后分段。课程入口、十分钟操作流程与闭卷自检见 Course.md；本轮实际执行与逐行差异见 STATUS.md。Ridge 使用均方损失，因此正规方程中的惩罚项为 nλ；不采用残差平方和版本的 λ 解释。
