"""Offline proposal player for the monitoring overview."""
from pathlib import Path

import streamlit as st

GITHUB_PROFILE_URL = "https://github.com/liilymiao"


SUBTITLE_LANGUAGES = (
    ("en", "English"),
    ("zh-CN", "简体中文"),
    ("zh-TW", "繁體中文"),
    ("yue", "粵語（繁體口語）"),
    ("ja", "日本語"),
    ("ko", "한국어"),
    ("es", "Español"),
    ("fr", "Français"),
)


def proposal_files(root: Path) -> tuple[Path, dict[str, Path]]:
    media = Path(root) / "assets" / "proposal"
    video = media / "overview.mp4"
    tracks = {label: media / "subtitles" / f"{code}.vtt" for code, label in SUBTITLE_LANGUAGES}
    return video, tracks


def render_home_video(root: Path, language: str = "en") -> None:
    video, tracks = proposal_files(root)
    if not video.is_file() or any(not path.is_file() for path in tracks.values()):
        st.info("项目视频文件尚未安装。" if language == "zh" else "The project video is not installed.")
        return
    with st.container():
        st.subheader("项目介绍" if language == "zh" else "Project introduction")
        st.video(video, subtitles=tracks, autoplay=False, loop=False, width=960)
        creator = f"[liilymiao]({GITHUB_PROFILE_URL})"
        st.caption(f"创作者：{creator}" if language == "zh" else f"Created by {creator}")

