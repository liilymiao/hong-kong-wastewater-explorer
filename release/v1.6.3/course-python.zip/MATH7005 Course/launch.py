"""Start the local dashboard: python launch.py [--port 8502]."""
import argparse
import importlib.util
from pathlib import Path
import subprocess
import sys


def build_command(root: Path, port: int = 8501) -> list[str]:
    """Use the active interpreter and an absolute script path, including spaces."""
    return [
        sys.executable, "-m", "streamlit", "run", str(root / "course_demo.py"),
        "--server.address=127.0.0.1", f"--server.port={port}",
        "--browser.gatherUsageStats=false",
    ]


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--port", type=int, default=8501, help="本机监听端口，默认 8501")
    args = parser.parse_args(argv)
    if not 1 <= args.port <= 65535:
        parser.error("端口必须在 1–65535 之间")
    root = Path(__file__).resolve().parent
    if importlib.util.find_spec("streamlit") is None:
        print("当前 Python 环境未安装 Streamlit。请先在项目目录安装依赖：", file=sys.stderr)
        print("python -m pip install -r requirements.lock.txt", file=sys.stderr)
        return 1
    print(f"启动本地应用：http://127.0.0.1:{args.port}；按 Ctrl+C 停止。", flush=True)
    try:
        return subprocess.call(build_command(root, args.port), cwd=root)
    except KeyboardInterrupt:
        return 130


if __name__ == "__main__":
    raise SystemExit(main())
