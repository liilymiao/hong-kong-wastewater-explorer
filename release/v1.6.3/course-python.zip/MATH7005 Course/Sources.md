# 数据与研究来源

本文件将项目中的数据、背景事实和方法依据对应到原始来源。核查与数据冻结日期为 **2026-10-23**。文献支持研究动机和方法选择；本项目的预测、聚类与异常结果已由冻结数据运行生成；课程源码包需按 README 重建 outputs 后查看。

编号与 [Project.md](Project.md) 的参考资料对应。官方数据文件的逐项 URL、抓取 UTC、HTTP 元数据、大小与 SHA256 见 [data/source_catalog.json](data/source_catalog.json)和 [data/audit.json](data/audit.json)。数据原件均保持冻结字节；本文件只概述其证据用途。补充 PDF、门户 HTML 和课程全文保留在内部证据档案，公开包提供官方链接；排除文件的 SHA256 与分发范围见 [release_sources.json](release_sources.json)。

## 一、主要政府数据与定义

### [1] 数据门户与原始周表

**Department of Health. Covid-19 Express's figures data. DATA.GOV.HK.**

- 数据门户：[官方数据集页面](https://data.gov.hk/en-data/dataset/hk-dh-chpsebcddr-covid-express)
- 原始数据：[covidx_data.csv](https://www.chp.gov.hk/files/misc/covidx_data.csv)
- 本地原件：[data/covidx_data.csv](data/covidx_data.csv)；门户 HTML 快照保留于内部证据档案，现行入口为上述官方数据集页面

门户确认发布机构、每周更新频率及实验室、暴发、重症、污水和哨点监测范围。实际下载的主表支持本项目的数值输入：194 个有效周、13 列，覆盖 2023W5 至 2026W42；污水有 192 个数值。它是全港周级汇总，没有站点、汇水区、地区标识、逐样本 PCR 测量或逐行发布日期。它承担主要建模与分析，不能仅凭这些字段开发站点级风险地图。

主 CSV 抓取完成时间为 `2026-10-23T08:55:58.653697+00:00`，SHA256 为 `1f348e7210d4e0dee1b8f1b8d722ee09086a3a87d2ecc7557e13c585d98e4e1c`。抓取时间与观测周末、源文件修改时间分别记录。

### [2] 官方数据字典

**Centre for Health Protection. Data dictionary of COVID-19 Express.**

原始 URL：[covidx_spec_en.pdf](https://www.chp.gov.hk/files/pdf/covidx_spec_en.pdf)。原件保留于内部证据档案；公开包使用上述官方链接与保存的 SHA256。

该单页字典支持字段名称、日期格式、比例和计数含义，以及污水指标的官方名称：*Per capita viral load (7-day geometric mean)*。字典仍用 `COVID19_GOPC`，最新 CSV 使用 `COVID19_FMC`；读取层要兼容，并保留原始字段名。字典未给出污水归一化公式和数值单位，相关单位需与周报交叉核对。列名兼容不证明历年诊所覆盖和监测方法完全一致。

### [3] 最新周报与不同临床监测序列

**Centre for Health Protection. COVID-19 & Flu Express, Volume 4, Number 42, published 22 October 2026.**

原始 URL：[2026W42 周报](https://www.chp.gov.hk/files/pdf/covid_flux_week42_22_10_2026_eng.pdf)。原件保留于内部证据档案；公开包使用上述官方链接与保存的 SHA256。

第 1 页明确报告期为 10 月 11–17 日、资料截至 10 月 21 日、出版日为 10 月 22 日。这些日期支持 `h=1` 与 `h=2` 的现实解释：从 W42 出发，W43 在发布时已进行，W44 才是下一完整监测周。出版信息只有日期，不能补造精确到时分的首发时间。

第 2 页的新记录阳性核酸检出数为 13，与 CSV `SARSCoV2_newcount` 一致；第 3 页另报告 PHLSB 的 9,188 份标本中 16 份阳性。两条序列不能互相替换，主表计数也不能作为比例的分子来反推标本分母。第 6 页使用官方污水指标名称，并以 **copy/L** 报告 W42 的 43,000；这一单位按原文保存，不自行解释为 copies/person/day 或二次人口归一化。第 7 页说明 FMC 与 PMP 求诊率按每千次求诊计算。

### [8] 日期纠错的独立证据

**Centre for Health Protection. COVID-19 & Flu Express, Volume 4, Number 6, published 12 February 2026.**

原始 URL：[2026W6 周报](https://www.chp.gov.hk/files/pdf/covid_flux_week6_12_2_2026_eng.pdf)。原件保留于内部证据档案；公开包使用上述官方链接与保存的 SHA256。

第 1 页明确报告期为 2026-02-01 至 2026-02-07，支持将主表该周错误的 `To=07/01/2026` 在派生表中更正为 `07/02/2026`。精确匹配前提、原值、修正值和来源记录于 [data/date_overrides.csv](data/date_overrides.csv)。原始 CSV 不改，未知日期错误不能自动套用这一修复规则。

### [9] 官方历史档案接口

**DATA.GOV.HK. Historical Data API Specification.**

- 文档：[官方 API 规范](https://data.gov.hk/en/help/api-spec)
- 目录接口：`https://app.data.gov.hk/v1/historical-archive/list-file-versions`
- 文件接口：`https://app.data.gov.hk/v1/historical-archive/get-file`
- 本地目录：[data/archive_versions.json](data/archive_versions.json)；API 文档 HTML 快照保留于内部证据档案，公开入口见上述官方 API 规范。

冻结的目录查询以主 CSV URL 为资源，`start=20231207`、`end=20261022`，返回 149 个版本。首尾列出时间为 2023-12-08 10:20 和 2026-10-16 10:40，文档时间区为 GMT+8。只实际下载并审计了两个样本：[首个样本](data/covidx_archive_20231208-1020.csv)包含 44 周，[最近样本](data/covidx_archive_20261016-1040.csv)包含 193 周；10 月 22 日最新主表更新尚未出现在本次冻结目录中。

这次抽查证明历史 CSV 可以通过官方接口取得，未证明全部 149 版完整，也没有建立逐期真实发布日历。最近样本与当前快照已有学校暴发数和阳性比例修订；早期样本还有精度与缺失标记差异。详细逐项比较保存在审计文件。

归档捕获时刻可用于保守地重建“截至某时刻已取得的数据”，不能直接当作原始发布日期。最早归档含有更早观测，不代表可以恢复 2023 年初的实时版本。主表的冻结版本回顾性评价与历史归档评价须分开标识。

## 二、香港背景及预测方法的原始研究

### [4] 香港监测方案的官方回顾

**Centre for Health Protection. Sewage surveillance for COVID-19 in Hong Kong – past, present and future. Communicable Diseases Watch. 2025;21(2):10–11.**

原始 URL：[cdw_v21_2.pdf](https://www.chp.gov.hk/files/pdf/cdw_v21_2.pdf)。核查位置为 PDF 第 5–6 页、印刷页 10–11。

该文支持监测方案曾优化的背景：回顾 2023 年 4 月至 2024 年 3 月资料，并讨论由较多沙井点精简至十八区各一个点、每周采样，随后比较 2024 年 4–12 月的污水与临床指标。它提示分析需要关注制度变化。报告没有给出已核实的精确方案切换日，不能据此猜定某一周作为结构断点；所报告相关也不是本项目的增量预测检验。

### [5] 香港污水与感染动态的实证研究

**Zheng X, Leung K, Xu X, et al. Wastewater Surveillance Provides Spatiotemporal SARS-CoV-2 Infection Dynamics. Engineering. 2024;40:70–77.** DOI：**10.1016/j.eng.2024.01.016**。

原始论文：[期刊全文](https://www.engineering.org.cn/engi/EN/10.1016/j.eng.2024.01.016)；机构记录：[香港大学作者库](https://hub.hku.hk/handle/10722/344222)。

§2.1 说明 2022 年连续采样、12 座污水处理厂及其覆盖范围；§3.1 比较污水和临床动态。该研究支持香港污水信号能够反映群体感染活动的科学背景。文中约三天的峰值先后关系，比较的是污水采样日与病例报告日，不能直接换算成公开数据产品可用的预警提前量。它也没有替当前项目回答：在既有临床历史之上，污水能否进一步降低样本外预测误差。

### [6] 增量预测价值的直接方法参照

**Radermacher J, Thiel S, Kannt A, Fröhlich H. Wastewater as an early indicator for short-term forecasting COVID-19 hospitalization in Germany. BMC Public Health. 2025;25:2910.** DOI：**10.1186/s12889-025-24149-2**。

原始论文：[期刊全文](https://link.springer.com/article/10.1186/s12889-025-24149-2)。

论文比较同类临床自回归模型加入和不加入污水的短期住院预测，使用滚动测试窗口。尽管存在较强的滞后相关，作者没有发现加入污水显著改善其所研究的预测任务。这支持本项目采用相同测试起点、相同模型族及配对误差比较，而不以相关系数替代信息增益证据。

该文的地区、住院结局、采样、平滑及报告延迟条件与香港方案不同。其未改善结果和具体误差都不能作为香港结论。借鉴的是对照设计与限制分析，不是把 ARIMA 作为本课程项目的主要实现。

### [7] 有正向结果的补充对照研究

**Hill DT, Alazawi MA, Moran EJ, et al. Wastewater surveillance provides 10-days forecasting of COVID-19 hospitalizations superior to cases and test positivity: A prediction study. Infectious Disease Modelling. 2023;8(4):1138–1150.** DOI：**10.1016/j.idm.2023.10.004**。

原始论文入口：[DOI](https://doi.org/10.1016/j.idm.2023.10.004)、[PubMed 官方记录](https://pubmed.ncbi.nlm.nih.gov/38023490/)、[PMC 全文](https://pmc.ncbi.nlm.nih.gov/articles/PMC10665827/)。全文机器读取入口：[Europe PMC XML](https://www.ebi.ac.uk/europepmc/webservices/rest/PMC10665827/fullTextXML)。

该纽约州研究报告污水对住院预测有价值，可用于说明研究结果受任务和验证设计影响。它的临床比较模型、协变量、随机留出、未来时段及跨县验证与本项目不同，不能把摘要中的改进幅度移植到香港，也不能把所有验证方式统称为同一种严格时间外推。项目采用它与德国研究共同说明需要在本地数据中实际检验。

## 三、课程原文与可选方法论文

### [10] 课程文件及 Moodle 快照

课程 PDF 为 **MATH7005 2026/2027 Assignment and Project Specification, 5 October 2026**。原 PDF 及 Moodle 文本快照保留于内部证据档案，不随公开包分发。[Assignment 入口](https://buelearning.hkbu.edu.hk/mod/assign/view.php?id=2013673)与 [Project 入口](https://buelearning.hkbu.edu.hk/mod/assign/view.php?id=2013674)可能需要课程登录。

[Course.md](Course.md)整理要求与当前实现、待办事项的对应，涵盖个人考核、权重、香港政府数据、可运行产品、Python/NumPy、三分钟匿名配音提案、10 分钟无幻灯片现场展示、约 20 分钟答辩、AI 声明及提交时刻。具体时间来自用户提供快照，没有重新登录 Moodle 核实最新状态。

### [11] 可选 AAAI 原创方法论文与引用计数

**Zeng A, Chen M, Zhang L, Xu Q. Are Transformers Effective for Time Series Forecasting? Proceedings of the AAAI Conference on Artificial Intelligence. 2023;37(9):11121–11128.** DOI：**10.1609/aaai.v37i9.26317**。

原始论文：[AAAI 官方页面](https://ojs.aaai.org/index.php/AAAI/article/view/26317)；预印本：[arXiv:2205.13504](https://arxiv.org/abs/2205.13504)。会议论文发表日期为 2023-06-26。论文提供简单线性时序模型和相关比较，适合讨论基线、直接预测及分解思想对本题的启发；它不要求本项目增加大型 Transformer，也不证明任何模型在香港数据中必然更优。

引用计数使用一次明确的数据库查询：[OpenAlex DOI API](https://api.openalex.org/works/https://doi.org/10.1609/aaai.v37i9.26317?select=id,doi,title,publication_year,publication_date,type,cited_by_count,updated_date,counts_by_year)。2026-10-23 查询返回 `W4382203079`，`cited_by_count=3507`；原始响应见 [sources/course_optional_paper_openalex.json](sources/course_optional_paper_openalex.json)。这一记录支持课程的“2022 年及以后、超过 2,022 次引用”门槛核查。引用数随数据库和时间变化，采用该平台、该日期的计数，不把不同版本相加。

## 四、证据使用的边界

当前政府数据冻结证据支持的是来源、可获得性、字段口径、数据质量与有限历史版本可取性。课程文件支持的是本次提供材料中的考核要求。原始研究支持科学动机、可借鉴的比较设计和已有研究的限制。三者均不能代替本项目的实际运行结果。

后续更新数据时，应新增带抓取时间和校验值的快照，并记录是否出现新字段、已修正日期或历史修订。后续论文或课程通知发生变化时，应更新对应条目及证据；已冻结来源仍保留，以便复现本次方案所依据的信息。
