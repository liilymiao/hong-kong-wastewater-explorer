# Current acceptance record — 11 November 2026

Python course candidate 1.5.3; scientific configuration 1.1; frozen input snapshot 23 October 2026. The original 1.5.2 ZIP and a separate baseline extraction were preserved. This candidate has not been pushed to GitHub or submitted to Moodle.

## Executed in this round

| Check | Result |
| --- | --- |
| Fresh Python 3.12.14 environment | Installed all 42 applicable exact locked dependencies; pip check passed |
| Original 1.5.2 baseline | Full pipeline passed; 123 tests passed, one internal-archive test deselected |
| Candidate full pipeline | Passed, including stage receipts and artifact sealing |
| Candidate applicable test suite | 157 passed, 0 failed, 0 skipped, 1 deselected; 39.53 seconds |
| Course UI, replay and language subset | 38 passed, including actual AppTest checks of all 12 horizon/score/block states |
| Offline independent copy | Full pipeline and 38 AppTest backend tests passed, zero Python network attempts |
| Frozen-result comparison | 26 CSVs, 8,173 rows, 108,164 numeric cells; zero numeric differences |
| English report | 28 factual/implementation checks passed; generated Markdown/HTML links passed; seven-page PDF rendered and visually inspected |
| Static website boundary fixes | 216 assertions passed; existing regression checks passed 12,286 assertions |
| Static website frozen data | 52 data/source assets unchanged; nine dataset hashes match their registry |

The single deselected test, `test_frozen_source_bytes_match_independent_catalogue`, requires original supporting PDF/HTML archives omitted from the distributable package. Included CSV integrity checks remain active. The legacy `scripts/check_numeric_independent.py` also requires those internal archives and was recorded as unavailable here (exit 2). The new portable reproducer compares all 26 bundled reference CSVs without them.

## Changes with numerical impact checked

The Python date importer now explicitly parses ISO-8601 values, including a mixture of date-only strings and timestamps. Reloading exported CSVs exposed the previous inference failure. Valid historical results are unchanged.

The original input and processed CSVs, config.yaml, all 26 saved reference CSVs and frozen_config.json are byte-identical to the baseline. The regenerated pattern configuration changes only its creation timestamp. Six unscored future predictions record the actual new generation time. Reports, code receipts and artifact manifests change with the revised source; they are not described as byte-identical.

Course demo and the real-origin trace call existing modules. The comparison block selector reads the saved 2/4/8-week intervals and exports the selected state. The public website now rejects blank/boolean/object numeric inputs and returns missing metrics for empty or incomplete paired comparisons. Its dataset exports retain valid frozen values.

## Commands

Run these from the extracted package with its installed environment:

```bash
python launch.py --port 8501
python scripts/reproduce_course.py --work-dir ../course-reproduction
python -m pytest -q -k "not test_frozen_source_bytes_match_independent_catalogue"
python scripts/check_report_links.py
python -m pip check
```

The reproduction destination must be new. It runs `python -m src.pipeline --config config.yaml --stage all` in an isolated copy, then compares every saved reference CSV by stable identifiers. Run `python scripts/check_offline.py` only in an expendable copy because it regenerates outputs. Optional PDF regeneration: install requirements-report.txt, then run `python scripts/build_report_pdf.py`.

## Remaining personal or environment checks

- The student must review the AI declaration, understand the mapped implementation and complete a timed ten-minute rehearsal and closed-book practice. These personal activities were not asserted as completed.
- Course dates come from the supplied handoff. The live Moodle deadline, presentation booking and individual attendance arrangements were not checked this round.
- Execution was on macOS arm64. Windows and Linux were not execution-tested.
- The offline test blocks Python network calls in the full pipeline and AppTest backend. It does not establish real-browser offline mode.
- A browser surface was unavailable for the website candidate, so the new JavaScript checks used a parsed DOM in Node. This round does not claim browser visual acceptance.
- Full historical data-vintage reconstruction, prospectively collected results and a confirmed monitoring-method change date remain outside this revision.

Raw execution logs, exact commands, baseline copies and the final ZIP extraction checks are retained beside this package in the local audit folder. This record reports current execution separately from older release history.
