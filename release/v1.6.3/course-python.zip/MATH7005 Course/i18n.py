"""Display-only bilingual adapter with canonical widget and scientific values.

Translations match complete messages or explicit message templates. No substring
replacement is applied to data, numbers, source identifiers or exported records.
"""
from __future__ import annotations
import json
import re
from pathlib import Path
from typing import Any
import pandas as pd
import streamlit as _st

CATALOG_PATH = Path(__file__).with_name("i18n_en.json")
CATALOG = json.loads(CATALOG_PATH.read_text(encoding="utf-8")) if CATALOG_PATH.exists() else {}
CJK = re.compile(r"[\u4e00-\u9fff]")


def language() -> str:
    return _st.session_state.get("ui_language", "en")


def toggle_language() -> None:
    values = dict(_st.session_state.get("_i18n_widget_values", {}))
    for key in values:
        if key in _st.session_state:
            values[key] = _st.session_state[key]
    _st.session_state["_i18n_restore"] = values
    _st.session_state["ui_language"] = "zh" if language() == "en" else "en"


def restore_widget_values() -> None:
    global CATALOG
    CATALOG = json.loads(CATALOG_PATH.read_text(encoding="utf-8"))
    _st.session_state.setdefault("ui_language", "en")
    _st.session_state["_i18n_previous_widgets"] = list(_st.session_state.get("_i18n_active_widgets", []))
    _st.session_state["_i18n_active_widgets"] = []
    for key, value in _st.session_state.pop("_i18n_restore", {}).items():
        _st.session_state[key] = value


# Explicit complete-message templates. Captures are copied without numeric conversion.
MESSAGE_TEMPLATES = [
 ("示例起点 {0}；名义发出时间 {1}；目标 {2} 至 {3}。", "Example origin {0}; nominal issue {1}; target {2} to {3}."),
 ("数据截至 {0}（{1}）", "Data through {0} ({1})"),
 ("快照日期：{0}", "Snapshot date: {0}"),
 ("训练标签可得截止：{0}", "Last training label available at: {0}"),
 ("{0} 缺少必需字段：{1}", "{0} is missing required columns: {1}"),
 ("{0} 没有可显示的记录", "{0} contains no displayable records"),
 ("图表日期 {0} 出现重复记录", "Duplicate chart dates in {0}"),
 ("未知评分视角：{0}", "Unknown scoring view: {0}"),
 ("本地分析产物无法一致读取：{0}", "The saved analysis cannot be read consistently: {0}"),
 ("{0} 必须包含一个 JSON 对象", "{0} must contain a JSON object"),
 ("来源：香港卫生署 COVID-19 Express；本地冻结日期 {0}。缺测保留为空，2026W6 的结束日期按官方周报修正，原值留在派生数据表。", "Source: Hong Kong Department of Health, COVID-19 Express. Local snapshot: {0}. Missing values stay missing. The 2026W6 end date follows the official weekly report; the original value remains in the derived table."),
 ("筛选日期 {0} 至 {1}；最新所选周 {2}。", "Selected dates: {0} to {1}. Latest selected week: {2}."),
 ("h{0} · 相对观测周后 {1} 周", "h{0} · {1} monitoring week(s) after the observed week"),
 ("假设周结束后 {0} 天（额外情境）", "Assumed {0} days after week end (additional scenario)"),
 ("假设周结束后 {0} 天", "Assumed {0} days after week end"),
 ("预测记录的实际运行时刻：{0}。", "Actual generation time recorded for this forecast: {0}."),
 ("完整运行日期：{0}。观测截止：{1}。目标：{2} 至 {3}。", "Full issue time: {0}. Observations through {1}. Target dates: {2} to {3}."),
 ("所选运行时刻，固定 h{0} 目标周已经开始。下一完整未来周为 {1} 至 {2}，对应 h{3}。", "At the selected issue time, the fixed h{0} target week has already started. The next complete future week is {1} to {2}, corresponding to h{3}."),
 ("目标周在所选运行时刻尚未开始；下一完整未来周对应 h{0}。", "The target week has not started at the selected issue time. The next complete future week corresponds to h{0}."),
 ("动态未来目标 h{0} 预测不可用：当前只保存 h1 与 h2 模型。固定 h{1} 的数值和目标日期保持对应。", "The next future target requires h{0}; an h{0} forecast is unavailable. Only h1 and h2 models are saved. The fixed h{1} values retain their original target dates."),
 ("{0}metrics.csv 没有可识别的验证或测试范围", "{0}metrics.csv has no recognized validation or test split"),
 ("当前误差使用未经范围限制的原始输出；{0}／{1} 个预测越过 0–100% 边界。模型、预测起点和参数与主评分相同。", "Errors use raw outputs without bounds; {0} of {1} predictions fall outside 0–100%. Models, forecast origins and parameters match the primary scoring view."),
 ("联合模型原始预测 MAE 为 {0} 个百分点；{1}／{2} 个预测发生 0–100% 边界截断。", "The combined model's raw MAE is {0} pp; {1} of {2} predictions were clipped to 0–100%."),
 ("当前评分 ΔMAE 的 {0} 时间块重采样区间：[{1}, {2}] 个百分点（{3} 周块、{4} 次）。", "The {0} moving-block bootstrap interval for this scoring view's ΔMAE is [{1}, {2}] pp ({3}-week blocks, {4} repetitions)."),
 ("区间结论依赖时间块长度：{0} 周块的区间包含零。完整 2／4／8 周块结果见下方敏感性表。", "Interval conclusions depend on block length: the {0}-week block interval(s) include zero. See the sensitivity table for all 2-, 4- and 8-week blocks."),
 ("每个查询仅使用其之前最多 {0} 个日历周的参考记录；查询周不参与拟合。列表排序是对所选范围已完成查询的事后比较，单周详情中的排名以该查询周为截止。", "Each query uses up to {0} earlier calendar weeks as its reference set; the query week is excluded from fitting. List order is a retrospective comparison of completed queries. The detail-view rank uses records only through the selected query week."),
 ("LOF 分数（k={0}）", "LOF score (k={0})"),
 ("{0}（k={1}）", "{0} (k={1})"),
 ("所属簇的中心特征：{0}", "Assigned cluster center: {0}"),
 ("参考区间：{0} 至 {1}；合格参考记录 {2}。", "Reference window: {0} to {1}; {2} eligible reference records."),
 ("排名只比较截至 {0} 的有效历史查询，并列分数采用相同名次。", "Ranks compare valid historical queries only through {0}; tied scores share the same rank."),
 ("数据冻结：{0}", "Data snapshot: {0}"),
 ("产物生成：{0}", "Outputs generated: {0}"),
 ("缺少本地结果：{0}", "Missing local outputs: {0}"),
 ("缺少分析文件：{0}", "Missing analysis file: {0}"),
 ("部分文件与完整运行结果不一致：{0}", "Some files differ from the complete analysis run: {0}"),
 ("缺少 {0} 阶段的完整记录，请运行 --stage all。", "The complete record for stage {0} is missing. Run --stage all."),
 ("分析产物不完整：{0}", "Incomplete analysis outputs: {0}"),
]


def _compile(template: str):
    chunks = re.split(r"(\{\d+\})", template)
    pattern = "".join(f"(?P<p{c[1:-1]}>.*?)" if re.fullmatch(r"\{\d+\}", c) else re.escape(c) for c in chunks)
    return re.compile("^" + pattern + "$", re.DOTALL)

TEMPLATES = [(_compile(a), b) for a, b in MESSAGE_TEMPLATES]
ENUM_LABELS = {
 "ok": "Available", "awaiting_observation": "Awaiting observation", "missing_query_features": "Missing query features",
 "insufficient_reference": "Insufficient reference history", "config_not_yet_available": "Pattern configuration not yet fixed",
 "frozen_retrospective": "Frozen retrospective evaluation", "frozen_snapshot_projection": "Unscored snapshot-end projection",
 "validation": "Development / validation", "test": "Final test", "future": "Unscored projection",
 "上升": "Rising", "下降": "Falling", "持平": "Flat", "平稳": "Stable",
 "冻结快照末端未评分预测": "Unscored snapshot-end forecast",
}
CLUSTER_RE = re.compile(r"^临床(较高|较低)·污水(较高|较低)（临床(上升|下降|持平|平稳)、污水(上升|下降|持平|平稳)）$")


def tr(value: Any, lang: str | None = None) -> Any:
    lang = language() if lang is None else lang
    if not isinstance(value, str) or lang == "zh":
        return value
    if value in CATALOG:
        return CATALOG[value]
    if value in ENUM_LABELS:
        return ENUM_LABELS[value]
    if not CJK.search(value):
        return value
    cluster = CLUSTER_RE.fullmatch(value)
    if cluster:
        p,w,pc,wc = cluster.groups()
        level = {"较高": "Higher", "较低": "Lower"}
        return f"{level[p]} clinical · {level[w].lower()} wastewater (clinical {tr(pc, lang).lower()}, wastewater {tr(wc, lang).lower()})"
    if re.fullmatch(r"\d+ 周", value):
        return value[:-2] + " weeks"
    for pattern, english in TEMPLATES:
        match = pattern.fullmatch(value)
        if match:
            captures = {int(k[1:]): tr(v, lang) for k, v in match.groupdict().items()}
            return english.format(*(captures[i] for i in range(len(captures))))
    return value


def translate_tree(value: Any) -> Any:
    if isinstance(value, str):
        return tr(value)
    if isinstance(value, dict):
        return {tr(k): translate_tree(v) for k,v in value.items()}
    if isinstance(value, list):
        return [translate_tree(v) for v in value]
    if isinstance(value, tuple):
        return tuple(translate_tree(v) for v in value)
    return value


def display_frame(frame: pd.DataFrame) -> pd.DataFrame:
    if language() == "zh":
        return frame
    result = frame.copy()
    for col in result:
        if pd.api.types.is_object_dtype(result[col]) or pd.api.types.is_string_dtype(result[col]):
            result[col] = result[col].map(lambda x: tr(x)).astype(result[col].dtype)
    return result.rename(columns={c: tr(c) for c in result.columns})


def display_figure(fig):
    """Translate presentation metadata only; never traverse numeric trace data."""
    if language() == "zh":
        return fig
    import plotly.graph_objects as go
    result = go.Figure(fig)
    for trace in result.data:
        if getattr(trace, "name", None): trace.name = tr(trace.name)
        if getattr(trace, "hovertemplate", None): trace.hovertemplate = tr(trace.hovertemplate)
        if getattr(trace, "text", None) is not None and isinstance(trace.text, (list, tuple)):
            trace.text = [tr(v) for v in trace.text]
    for axis_name in result.layout:
        if axis_name.startswith(("xaxis", "yaxis")):
            axis = result.layout[axis_name]
            if axis.title.text: axis.title.text = tr(axis.title.text)
            if axis.ticktext is not None: axis.ticktext = [tr(v) for v in axis.ticktext]
    if result.layout.title.text: result.layout.title.text = tr(result.layout.title.text)
    for annotation in result.layout.annotations or []: annotation.text = tr(annotation.text)
    return result


class LocalizedUI:
    """Proxy only display calls; all widget option/return values stay canonical."""
    TEXT_METHODS = {"title", "header", "subheader", "caption", "write", "markdown", "info", "warning", "error", "success", "text"}
    WIDGET_METHODS = {"selectbox", "radio", "multiselect"}

    def __init__(self, target): self._target = target
    def __enter__(self): self._target.__enter__(); return self
    def __exit__(self, *args): return self._target.__exit__(*args)

    def __getattr__(self, name):
        target = getattr(self._target, name)
        if name == "sidebar": return LocalizedUI(target)
        if name in self.TEXT_METHODS:
            return lambda *a, **kw: target(*(tr(v) for v in a), **{k: tr(v) if k in {"help"} else v for k,v in kw.items()})
        if name == "set_page_config":
            return lambda **kw: target(**{k: tr(v) if k == "page_title" else v for k,v in kw.items()})
        if name == "metric":
            return lambda *a, **kw: target(*(tr(v) for v in a), **{k: tr(v) if k in {"label", "value", "delta", "help"} else v for k,v in kw.items()})
        if name in self.WIDGET_METHODS:
            def widget(label, *args, **kwargs):
                formatter = kwargs.get("format_func", str)
                current_language = language()
                kwargs["format_func"] = lambda v: tr(formatter(v), current_language)
                if "help" in kwargs: kwargs["help"] = tr(kwargs["help"])
                key = kwargs.get("key")
                shadow = dict(_st.session_state.get("_i18n_widget_values", {}))
                previous_widgets = _st.session_state.get("_i18n_previous_widgets", [])
                if key in shadow and (key not in _st.session_state or key not in previous_widgets):
                    options = list(args[0] if args else kwargs.get("options", []))
                    saved = shadow[key]
                    if name == "multiselect":
                        _st.session_state[key] = [v for v in saved if v in options]
                    elif saved in options:
                        _st.session_state[key] = saved
                result = target(tr(label), *args, **kwargs)
                if key:
                    active_widgets = list(_st.session_state.get("_i18n_active_widgets", []))
                    active_widgets.append(key)
                    _st.session_state["_i18n_active_widgets"] = active_widgets
                    shadow[key] = result
                    _st.session_state["_i18n_widget_values"] = shadow
                return result
            return widget
        if name in {"button", "download_button"}:
            return lambda label, *a, **kw: target(tr(label), *a, **kw)
        if name == "expander":
            return lambda label, *a, **kw: LocalizedUI(target(tr(label), *a, **kw))
        if name == "columns":
            return lambda *a, **kw: [LocalizedUI(x) for x in target(*a, **kw)]
        if name == "tabs":
            return lambda labels, **kw: [LocalizedUI(x) for x in target([tr(x) for x in labels], **kw)]
        if name == "container":
            return lambda *a, **kw: LocalizedUI(target(*a, **kw))
        if name == "json":
            return lambda value, **kw: target(translate_tree(value), **kw)
        return target


st = LocalizedUI(_st)
