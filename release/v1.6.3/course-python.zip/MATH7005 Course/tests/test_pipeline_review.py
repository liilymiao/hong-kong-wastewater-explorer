"""Regression checks for rejecting mixed generations before any output writes."""
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import shutil
import pytest
import yaml
from src.artifacts import ArtifactError, verify_artifacts, verify_stage_receipt
from src.configuration import validate_config
from src.pipeline import main, preflight

ROOT = Path(__file__).resolve().parents[1]


def config():
    return yaml.safe_load((ROOT / 'config.yaml').read_text(encoding='utf-8'))


def fingerprints(root):
    return {str(path.relative_to(root)): hashlib.sha256(path.read_bytes()).hexdigest()
            for sub in ('outputs', 'data/processed') for path in (root / sub).rglob('*') if path.is_file()}


@pytest.fixture
def project_copy(tmp_path):
    for sub in ('src', 'outputs'):
        shutil.copytree(ROOT / sub, tmp_path / sub, ignore=shutil.ignore_patterns('__pycache__'))
    (tmp_path / 'data').mkdir()
    for name in ('covidx_data.csv', 'date_overrides.csv', 'source_catalog.json'):
        shutil.copy2(ROOT / 'data' / name, tmp_path / 'data' / name)
    shutil.copy2(ROOT / 'data/audit_data.py', tmp_path / 'data/audit_data.py')
    shutil.copy2(ROOT / 'requirements.lock.txt', tmp_path / 'requirements.lock.txt')
    shutil.copytree(ROOT / 'data/processed', tmp_path / 'data/processed')
    shutil.copy2(ROOT / 'config.yaml', tmp_path / 'config.yaml')
    return tmp_path


def test_complete_bundle_has_verifiable_stage_chain():
    cfg = config()
    assert verify_stage_receipt(ROOT, cfg, 'validate')['stage'] == 'validate'
    assert verify_stage_receipt(ROOT, cfg, 'test')['stage'] == 'test'
    assert verify_artifacts(ROOT, cfg)['stage'] == 'complete'


def test_changed_frozen_config_rejected_before_outputs_are_touched(project_copy):
    cfg = config(); cfg['evaluation']['seed'] += 1
    path = project_copy / 'config.yaml'
    path.write_text(yaml.safe_dump(cfg, allow_unicode=True), encoding='utf-8')
    before = fingerprints(project_copy)
    with pytest.raises(ValueError, match='Config has changed'):
        main(['--config', str(path), '--stage', 'all'])
    assert fingerprints(project_copy) == before


@pytest.mark.parametrize('filename,stage', [('validation_predictions.csv', 'test'), ('metrics.csv', 'export')])
def test_changed_prior_result_cannot_be_reused_or_resealed(project_copy, filename, stage):
    path = project_copy / 'outputs' / filename
    path.write_bytes(path.read_bytes() + b'\n')
    before = fingerprints(project_copy)
    with pytest.raises(ArtifactError, match='不一致'):
        main(['--config', str(project_copy / 'config.yaml'), '--stage', stage])
    assert fingerprints(project_copy) == before


def test_changed_numerical_code_cannot_be_resealed(project_copy):
    path = project_copy / 'src/models.py'
    path.write_text(path.read_text(encoding='utf-8') + '\n# changed numerical code\n', encoding='utf-8')
    before = fingerprints(project_copy)
    with pytest.raises(ArtifactError, match='不一致'):
        main(['--config', str(project_copy / 'config.yaml'), '--stage', 'export'])
    assert fingerprints(project_copy) == before


def test_unfinished_run_is_not_displayable(project_copy):
    path = project_copy / 'outputs/run_state.json'
    state = json.loads(path.read_text(encoding='utf-8')); state['status'] = 'failed'
    path.write_text(json.dumps(state), encoding='utf-8')
    with pytest.raises(ArtifactError, match='尚未完整完成'):
        verify_artifacts(project_copy, config())


def test_shared_sensitivity_outputs_are_integrity_checked(project_copy):
    path = project_copy / 'outputs/shared_lambda_bootstrap_sensitivity.csv'
    path.write_bytes(path.read_bytes() + b'\n')
    with pytest.raises(ArtifactError, match='不一致'):
        verify_artifacts(project_copy, config())


@pytest.mark.parametrize('record', [[], None, 'bad'])
def test_malformed_manifest_has_a_clear_error(project_copy, record):
    path = project_copy / 'outputs/artifact_manifest.json'
    metadata = json.loads(path.read_text(encoding='utf-8')); metadata['files'] = record
    path.write_text(json.dumps(metadata), encoding='utf-8')
    with pytest.raises(ArtifactError):
        verify_artifacts(project_copy, config())


@pytest.mark.parametrize('section,key,value', [
    ('data', 'target', 'unsupported'), ('patterns', 'kmeans_candidates', [2.5]),
    ('patterns', 'lof_neighbors', [5, 10.9, 15]), ('patterns', 'lof_primary_neighbors', 10.9),
    ('evaluation', 'bootstrap_block_sensitivity', [2, 8.5]), ('evaluation', 'seed', -1),
    ('evaluation', 'bootstrap_repeats', 1), ('output', 'directory', '../outside'),
])
def test_unsupported_settings_fail_before_analysis(section, key, value):
    cfg = deepcopy(config()); cfg[section][key] = value
    with pytest.raises(ValueError):
        validate_config(cfg)
