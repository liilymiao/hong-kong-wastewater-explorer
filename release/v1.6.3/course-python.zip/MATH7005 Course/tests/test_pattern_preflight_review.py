"""Frozen pattern decisions must be checked before a rebuild writes files."""
import copy
import hashlib
import json
from pathlib import Path
import shutil

import pytest
import yaml

from src.artifacts import ArtifactError
from src.data import load_snapshot
from src.pattern_pipeline import run_patterns, validate_pattern_frozen
from src.pipeline import main


ROOT = Path(__file__).resolve().parents[1]


def _evidence(root):
    return {str(path.relative_to(root)): (hashlib.sha256(path.read_bytes()).hexdigest(),
                                        path.stat().st_mtime_ns)
            for sub in ("outputs", "data/processed")
            for path in (root / sub).rglob("*") if path.is_file()}


@pytest.fixture
def pattern_project(tmp_path):
    for sub in ("src", "outputs", "data/processed"):
        shutil.copytree(ROOT / sub, tmp_path / sub,
                        ignore=shutil.ignore_patterns("__pycache__"))
    for name in ("data/covidx_data.csv", "data/date_overrides.csv", "data/source_catalog.json",
                 "data/audit_data.py", "requirements.lock.txt", "config.yaml"):
        shutil.copy2(ROOT / name, tmp_path / name)
    return tmp_path


@pytest.mark.parametrize("stage", ["all", "validate", "audit"])
@pytest.mark.parametrize("field,value", [("cluster_k", 3),
                                        ("selection_states_sha256", "changed"),
                                        ("selection_available_at", "2020-01-01T23:59:00+08:00")])
def test_changed_pattern_freeze_is_rejected_before_all_output_writes(pattern_project, stage, field, value):
    path = pattern_project / "outputs/pattern_config.json"
    frozen = json.loads(path.read_text(encoding="utf-8"))
    frozen[field] = value
    path.write_text(json.dumps(frozen), encoding="utf-8")
    before = _evidence(pattern_project)
    with pytest.raises(ValueError, match="[Pp]attern"):
        main(["--config", str(pattern_project / "config.yaml"), "--stage", stage])
    assert _evidence(pattern_project) == before


def test_changed_candidate_evidence_is_rejected_by_existing_stage_record(pattern_project):
    path = pattern_project / "outputs/pattern_config.json"
    frozen = json.loads(path.read_text(encoding="utf-8"))
    frozen["candidates"][0]["inertia"] += 0.01
    path.write_text(json.dumps(frozen), encoding="utf-8")
    before = _evidence(pattern_project)
    with pytest.raises(ArtifactError, match="模式冻结决定与验证阶段记录不一致"):
        main(["--config", str(pattern_project / "config.yaml"), "--stage", "validate"])
    assert _evidence(pattern_project) == before


def test_direct_pattern_replay_rejects_changed_selected_k_without_writing(tmp_path):
    cfg = yaml.safe_load((ROOT / "config.yaml").read_text(encoding="utf-8"))
    clean = load_snapshot(ROOT / cfg["data"]["csv"], cfg)
    frozen = json.loads((ROOT / "outputs/pattern_config.json").read_text(encoding="utf-8"))
    checked = validate_pattern_frozen(clean, cfg, frozen)
    assert len(checked) == len(clean)
    altered = copy.deepcopy(frozen)
    altered["cluster_k"] = 3
    path = tmp_path / "pattern_config.json"
    path.write_text(json.dumps(altered), encoding="utf-8")
    before = path.read_bytes()
    with pytest.raises(ValueError, match="cluster decision changed"):
        run_patterns(clean, cfg, tmp_path)
    assert path.read_bytes() == before
    assert not (tmp_path / "patterns.csv").exists()


def test_unchanged_complete_validation_rebuild_preserves_both_frozen_decisions(pattern_project):
    paths = [pattern_project / "outputs" / name
             for name in ("pattern_config.json", "frozen_config.json")]
    before = {path.name: path.read_bytes() for path in paths}
    main(["--config", str(pattern_project / "config.yaml"), "--stage", "validate"])
    assert {path.name: path.read_bytes() for path in paths} == before
    assert json.loads((pattern_project / "outputs/run_state.json").read_text())["status"] == "awaiting_export"
