"""Check report evidence and result binding, without mirroring report prose."""
from pathlib import Path
import ast
import re
import pandas as pd
from src.outputs import course_evidence
ROOT = Path(__file__).resolve().parents[1]


def test_report_mapping_uses_existing_functions_and_tests():
    for row in course_evidence().itertuples(index=False, name=None):
        testfile, testname = row[2].split(': ')
        tree = ast.parse((ROOT/'tests'/testfile).read_text())
        assert any(isinstance(n,ast.FunctionDef) and n.name==testname for n in ast.walk(tree))
        for filepath in re.findall(r'src/[a-z_]+\.py',row[1]):
            assert (ROOT/filepath).is_file()


def test_english_report_is_tied_to_actual_h2_outputs():
    text=(ROOT/'outputs/项目报告.md').read_text()
    html=(ROOT/'outputs/项目报告.html').read_text()
    assert '<html lang="en">' in html
    for name in ['metrics.csv','raw_metrics.csv']:
        df=pd.read_csv(ROOT/'outputs'/name)
        for value in df[(df.split=='test') & (df.horizon==2)].mae_pp:
            assert f'{value:.4f}' in text
    assert 'n*lambda' in text and 'mean-squared-loss' in text
    assert 'post-hoc' in text and 'AI assistance' in text
    assert all(name in text for name in ['RidgeRegressor.fit','KMeans._initialize','LOFNovelty.fit'])
