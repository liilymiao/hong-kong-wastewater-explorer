"""Independent acceptance checks for the frozen Hong Kong wastewater product.

The reference calculations below deliberately avoid the production metric and
Ridge implementations. Synthetic values are used only for numerical checks.
"""
from __future__ import annotations

import csv
import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd
import pytest
import yaml

ROOT = Path(__file__).resolve().parents[1]


@pytest.fixture(scope="module")
def config():
    return yaml.safe_load((ROOT / "config.yaml").read_text(encoding="utf-8"))


def _source_entries(value):
    if isinstance(value, dict):
        if "local_file" in value and "sha256" in value:
            yield value
        for child in value.values():
            yield from _source_entries(child)
    elif isinstance(value, list):
        for child in value:
            yield from _source_entries(child)


def test_frozen_source_bytes_match_independent_catalogue():
    """D1: hash every frozen raw source, including the two archive samples."""
    catalogue = json.loads((ROOT / "data/source_catalog.json").read_text())
    entries = list(_source_entries(catalogue))
    assert len(entries) >= 9
    for entry in entries:
        content = (ROOT / "data" / entry["local_file"]).read_bytes()
        assert hashlib.sha256(content).hexdigest() == entry["sha256"], entry["local_file"]
        assert len(content) == entry["bytes"], entry["local_file"]


def test_frozen_raw_shape_and_official_week_sequence():
    """D2: independently count blank rows and preserve official Year/Week."""
    with (ROOT / "data/covidx_data.csv").open(encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        columns = reader.fieldnames
        rows = list(reader)
    valid = [row for row in rows if any(str(v or "").strip() for v in row.values())]
    assert len(columns) == 13
    assert len(rows) - len(valid) == 2
    assert len(valid) == 194
    assert len({(row["Year"], row["Week"]) for row in valid}) == 194
    starts = pd.to_datetime([row["From"] for row in valid], format="%d/%m/%Y")
    assert (starts.dayofweek == 6).all()
    assert ((starts[1:] - starts[:-1]).days == 7).all()
    assert (valid[0]["Year"], valid[0]["Week"]) == ("2023", "5")
    assert (valid[-1]["Year"], valid[-1]["Week"]) == ("2026", "42")


@pytest.fixture(scope="module")
def snapshot(config):
    from src.data import load_snapshot
    return load_snapshot(ROOT / config["data"]["csv"], config)


def test_cleaned_dates_missing_values_and_units(snapshot):
    """D3/D4/D5: preserve raw provenance; 0.01 is one percentage point."""
    row = snapshot.loc[(snapshot.Year == 2026) & (snapshot.Week == 6)].iloc[0]
    assert row.To_raw == "07/01/2026"
    assert row.To_corrected == pd.Timestamp("2026-02-07")
    assert bool(row.correction_applied)
    assert row.correction_source_url.endswith("covid_flux_week6_12_2_2026_eng.pdf")
    assert snapshot.correction_applied.sum() == 1
    assert snapshot.loc[snapshot.Sewage_viralload.isna(), ["Year", "Week"]].values.tolist() == [[2024, 17], [2024, 18]]
    assert snapshot.Sewage_viralload.notna().sum() == 192
    assert snapshot.SARSCoV2_proportion.between(0, 1).all()
    assert abs(0.03 - 0.02) * 100 == pytest.approx(1.0)
    assert len(snapshot) == 194


@pytest.mark.parametrize("changed_field,changed_value", [
    ("Year", 2025), ("Week", 7), ("From_raw", "02/02/2026"),
    ("To", "08/01/2026"), ("To", "07/02/2026"),
])
def test_date_override_requires_every_exact_condition(changed_field, changed_value):
    from src.data import apply_date_overrides
    original = {"Year": 2026, "Week": 6, "From_raw": "01/02/2026", "To": "07/01/2026"}
    changed = {**original, changed_field: changed_value}
    result = apply_date_overrides(pd.DataFrame([original, changed]), ROOT / "data/date_overrides.csv")
    assert result.correction_applied.tolist() == [True, False]
    assert result.iloc[1].To_raw == changed["To"]
    assert result.iloc[1].To_corrected == pd.to_datetime(changed["To"], format="%d/%m/%Y")


def test_unknown_date_error_and_tampered_source_are_rejected(snapshot, config, tmp_path):
    from src.data import load_snapshot, validate_week_index
    broken = snapshot.copy()
    broken.loc[0, "To_corrected"] = broken.loc[0, "To_corrected"] + pd.Timedelta(days=1)
    with pytest.raises(ValueError, match="Unknown date error"):
        validate_week_index(broken)
    source = tmp_path / "covidx_data.csv"
    source.write_bytes((ROOT / "data/covidx_data.csv").read_bytes() + b"\n")
    with pytest.raises(ValueError, match="SHA256"):
        load_snapshot(source, config)


def test_zero_sewage_is_preserved_and_missing_spreads_to_three_anchors(snapshot):
    from src.features import build_features, eligible_training_rows
    original = build_features(snapshot)
    j = 120
    changed = snapshot.copy()
    changed.loc[j, "Sewage_viralload"] = np.nan
    changed.loc[j + 5, "Sewage_viralload"] = 0.0
    result = build_features(changed)
    changed_complete = np.flatnonzero(original.paired_complete.to_numpy() != result.paired_complete.to_numpy())
    assert changed_complete.tolist() == [j, j + 1, j + 2]
    assert result.loc[j:j + 2, "clinical_complete"].all()
    assert not result.loc[j:j + 2, "paired_complete"].any()
    assert result.loc[j + 5, "w_log1p_lag_0"] == 0.0
    train_rows = eligible_training_rows(result, j + 10, 2)
    assert not set([j, j + 1, j + 2]).intersection(train_rows)
    # Clinical and joint comparison both consume this single shared training set.
    assert result.loc[train_rows, "paired_complete"].all()


def test_ridge_matches_independent_augmented_least_squares_and_nlambda():
    from src.models import RidgeRegressor
    x = np.array([[1., 2., 9.], [2., 5., 9.], [4., 3., 9.], [7., 8., 9.], [8., 2., 9.]])
    y = np.array([0.2, 0.5, 0.1, 0.8, 0.4])
    lam = 0.35
    mean, scale = x.mean(axis=0), x.std(axis=0)
    scale[scale == 0] = 1
    z = (x - mean) / scale
    augmented_x = np.vstack([z, np.sqrt(len(y) * lam) * np.eye(x.shape[1])])
    augmented_y = np.concatenate([y - y.mean(), np.zeros(x.shape[1])])
    expected, *_ = np.linalg.lstsq(augmented_x, augmented_y, rcond=None)
    model = RidgeRegressor(lam).fit(x, y)
    np.testing.assert_allclose(model.coef_, expected, rtol=1e-12, atol=1e-12)
    np.testing.assert_allclose(model.predict(x), z @ expected + y.mean(), rtol=1e-12, atol=1e-12)
    assert model.intercept_ == pytest.approx(y.mean())
    assert model.state()["zero_variance_columns"] == [2]
    duplicated = RidgeRegressor(lam).fit(np.tile(x, (3, 1)), np.tile(y, 3))
    np.testing.assert_allclose(duplicated.predict(x), model.predict(x), rtol=1e-12, atol=1e-12)
    shifted = RidgeRegressor(lam).fit(x, y + 7)
    np.testing.assert_allclose(shifted.predict(x), model.predict(x) + 7, rtol=1e-12, atol=1e-12)
    residual = y - model.predict(x)
    assert model.loss_ == pytest.approx(np.mean(residual ** 2) + lam * np.sum(expected ** 2))


def test_label_maturity_and_configured_origin_ranges(snapshot, config):
    from src.features import build_features, eligible_training_rows, make_origin_manifest
    f = build_features(snapshot)
    manifest = make_origin_manifest(f, config)
    for h in (1, 2):
        validation = manifest[(manifest.split == "validation") & (manifest.horizon == h)]
        test = manifest[(manifest.split == "test") & (manifest.horizon == h)]
        assert validation.anchor_week.tolist() == list(range(1, 51))
        assert test.anchor_week.tolist() == list(range(1, 41))
        for t in list(validation.t) + list(test.t):
            rows = eligible_training_rows(f, int(t), h)
            assert np.all(rows + h <= t)
            assert (f.iloc[rows + h].label_available_at <= f.iloc[t].issue_at).all()
        last_validation_target = f.iloc[int(validation.t.max()) + h]
        assert last_validation_target.label_available_at < test.issue_at.min()


def test_delayed_training_feature_or_label_is_not_yet_available(snapshot):
    from src.features import build_features, eligible_training_rows
    f = build_features(snapshot)
    t, h, j = 170, 2, 120
    baseline = eligible_training_rows(f, t, h)
    assert j in baseline
    after_issue = f.iloc[t].issue_at + pd.Timedelta(days=1)
    changed_feature = f.copy()
    changed_feature.loc[j, "feature_available_at"] = after_issue
    assert j not in eligible_training_rows(changed_feature, t, h)
    changed_label = f.copy()
    changed_label.loc[j + h, "label_available_at"] = after_issue
    assert j not in eligible_training_rows(changed_label, t, h)


def test_horizons_and_late_issue_keep_fixed_target_labels(snapshot, config):
    from src.features import delay_manifest, target_dates
    t = len(snapshot) - 1
    assert target_dates(snapshot, t, 1)["target_from"] == pd.Timestamp("2026-10-18")
    assert target_dates(snapshot, t, 1)["target_week"] == 43
    assert target_dates(snapshot, t, 2)["target_from"] == pd.Timestamp("2026-10-25")
    assert target_dates(snapshot, t, 2)["target_week"] == 44
    rows = delay_manifest(snapshot, config)
    rows = rows[(rows.anchor_year == 2026) & (rows.anchor_week == 42) & (rows.horizon == 2)]
    ordinary = rows[rows.delay_days == 5].iloc[0]
    delayed = rows[rows.delay_days == 8].iloc[0]
    assert ordinary.issue_at == pd.Timestamp("2026-10-22 23:59", tz="Asia/Hong_Kong")
    assert not ordinary.target_started
    assert delayed.target_started
    assert delayed.target_from == ordinary.target_from
    assert delayed.target_week == 44
    assert delayed.next_future_horizon == 3
    assert delayed.next_future_from == pd.Timestamp("2026-11-01")
    assert not delayed.dynamic_prediction_available


@pytest.fixture(scope="module")
def fixed_parameters():
    # Fixed in advance for leakage tests; no retuning is run after perturbation.
    return {"clinical_ridge": {"1": 0.01, "2": 0.1}, "combined_ridge": {"1": 0.1, "2": 1.0}}


def test_future_perturbation_leaves_all_past_prediction_inputs_and_states_exact(snapshot, config, fixed_parameters):
    from src.backtest import predict_origin
    from src.features import build_features
    original = build_features(snapshot)
    cutoff = int(snapshot.index[(snapshot.Year == 2026) & (snapshot.Week == 20)][0])
    changed = snapshot.copy()
    after = np.arange(len(changed)) > cutoff
    changed.loc[after, "SARSCoV2_proportion"] = np.linspace(0.6, 0.95, after.sum())
    changed.loc[after, "Sewage_viralload"] = np.arange(after.sum()) * 123456 + 999999
    altered = build_features(changed)
    feature_names = [column for column in original if "_lag_" in column]
    pd.testing.assert_frame_equal(original.loc[:cutoff, feature_names], altered.loc[:cutoff, feature_names], check_exact=True)
    causal_fields = ["query_features", "train_anchor_keys", "train_last_target", "train_last_target_available_at", "n_train", "model_state", "raw_prediction", "prediction", "lambda", "was_clipped", "issue_at", "target_from", "target_to", "feature_set"]
    origins = np.flatnonzero((snapshot.Year == 2026) & (snapshot.index <= cutoff))
    assert len(origins) == 20
    for t in origins:
        for h in (1, 2):
            before = pd.DataFrame(predict_origin(original, int(t), h, fixed_parameters, config)).set_index("model_id")
            after_frame = pd.DataFrame(predict_origin(altered, int(t), h, fixed_parameters, config)).set_index("model_id")
            pd.testing.assert_frame_equal(before[causal_fields], after_frame[causal_fields], check_exact=True)
            assert before.loc["clinical_ridge", "train_anchor_keys"] == before.loc["combined_ridge", "train_anchor_keys"]
            # Future observations may alter later evaluation labels, never prediction inputs.


def test_query_availability_and_paired_missing_origin_are_enforced(snapshot, config, fixed_parameters):
    from src.backtest import predict_origin
    from src.features import build_features
    t = 170
    f = build_features(snapshot)
    assert len(predict_origin(f, t, 2, fixed_parameters, config)) == 3
    late = f.copy()
    late.loc[t, "feature_available_at"] = late.loc[t, "issue_at"] + pd.Timedelta(days=1)
    assert predict_origin(late, t, 2, fixed_parameters, config) == []
    missing = snapshot.copy()
    missing.loc[t, "Sewage_viralload"] = np.nan
    assert predict_origin(build_features(missing), t, 2, fixed_parameters, config) == []


@pytest.fixture(scope="module")
def validation_run(snapshot, config, tmp_path_factory):
    from src.backtest import freeze_config, rolling_validate
    from src.features import build_features
    features = build_features(snapshot)
    candidates = rolling_validate(features, config)
    frozen = freeze_config(candidates, features, config, tmp_path_factory.mktemp("acceptance_freeze") / "frozen.json")
    return features, candidates, frozen


def test_validation_candidates_have_equal_budget_rows_and_independent_lambda_selection(validation_run, config):
    features, candidates, frozen = validation_run
    expected_lambdas = set(config["models"]["ridge_lambdas"])
    for h in (1, 2):
        frame = candidates[candidates.horizon == h]
        keys = ["anchor_from", "target_from", "issue_at", "evaluation_vintage"]
        reference_keys = None
        score_by_model = {}
        for model in ("clinical_ridge", "combined_ridge"):
            model_rows = frame[frame.model_id == model]
            assert set(model_rows["lambda"]) == expected_lambdas
            score_by_model[model] = {}
            for lam in sorted(expected_lambdas):
                one = model_rows[model_rows["lambda"] == lam].sort_values("anchor_from")
                assert len(one) == 50
                these_keys = list(one[keys].itertuples(index=False, name=None))
                reference_keys = these_keys if reference_keys is None else reference_keys
                assert these_keys == reference_keys
                errors = 100 * np.abs(one.observed.to_numpy() - one.prediction.to_numpy())
                np.testing.assert_allclose(one.abs_error_pp, errors, rtol=1e-12)
                score_by_model[model][lam] = errors.mean()
            best = min(score_by_model[model].values())
            expected = max(lam for lam, score in score_by_model[model].items() if score <= best + 1e-6)
            assert frozen["parameters"][model][str(h)] == expected
        shared_scores = {lam: (score_by_model["clinical_ridge"][lam] + score_by_model["combined_ridge"][lam]) / 2 for lam in expected_lambdas}
        shared_best = min(shared_scores.values())
        expected_shared = max(lam for lam, score in shared_scores.items() if score <= shared_best + 1e-6)
        for model in ("clinical_ridge", "combined_ridge"):
            assert frozen["shared_parameters"][model][str(h)] == expected_shared
        comparison = frame[frame.model_id.isin(["clinical_ridge", "combined_ridge"])]
        assert comparison.groupby(keys, dropna=False).train_anchor_keys.nunique().eq(1).all()
    assert pd.Timestamp(frozen["validation_last_label_available_at"]) < pd.Timestamp(frozen["first_test_issue_at"])
    assert "retrospect" in frozen["time_claim"].lower()


def test_test_set_values_do_not_change_selected_parameters(validation_run, snapshot, config, tmp_path):
    from src.backtest import freeze_config, rolling_validate
    from src.features import build_features
    features, candidates, frozen = validation_run
    changed = snapshot.copy()
    changed.loc[changed.Year == 2026, "SARSCoV2_proportion"] = 0.99
    changed.loc[changed.Year == 2026, "Sewage_viralload"] = 9999999.0
    altered_features = build_features(changed)
    rerun_candidates = rolling_validate(altered_features, config)
    pd.testing.assert_frame_equal(candidates, rerun_candidates, check_exact=True)
    selected = freeze_config(rerun_candidates, altered_features, config, tmp_path / "second.json")
    assert selected["parameters"] == frozen["parameters"]
    assert selected["shared_parameters"] == frozen["shared_parameters"]


def test_bootstrap_blocks_do_not_cross_calendar_gaps_and_match_independent_draws():
    from src.backtest import moving_block_interval
    values = np.array([1., 2., 3., 100., 101., 102.])
    dates = pd.to_datetime(["2026-01-04", "2026-01-11", "2026-01-18", "2026-02-08", "2026-02-15", "2026-02-22"])
    result = moving_block_interval(values, dates, block=3, repeats=2000, seed=42)
    assert result["n_blocks"] == 2
    rng = np.random.default_rng(42)
    draws = rng.integers(2, size=(2000, 2))
    blocks = np.array([values[:3], values[3:]])
    means = np.array([np.concatenate([blocks[i] for i in pair]).mean() for pair in draws])
    lo, hi = np.percentile(means, [2.5, 97.5])
    assert result["low"] == pytest.approx(lo)
    assert result["high"] == pytest.approx(hi)
    no_blocks = moving_block_interval(values, dates, block=4)
    assert no_blocks["n_blocks"] == 0
    assert np.isnan(no_blocks["low"]) and np.isnan(no_blocks["high"])


def test_metrics_recomputed_from_actual_predictions_and_future_excluded(validation_run, config):
    from src.backtest import paired_evaluate, rolling_test
    features, _, frozen = validation_run
    predictions = rolling_test(features, config, frozen)
    future = rolling_test(features, config, frozen, split="future")
    assert len(future) == 6
    assert future.issue_at.nunique() == 1, "A forecast run must share one issue time across its models and horizons."
    assert future.status.eq("awaiting_observation").all()
    assert future[["observed", "abs_error_pp", "squared_error_pp2"]].isna().all().all()
    all_rows = pd.concat([predictions, future], ignore_index=True)
    metrics, errors, _, stages = paired_evaluate(all_rows, config, {"test": 40})
    assert len(metrics) == 6
    assert metrics.split.eq("test").all()
    for h in (1, 2):
        one_h = predictions[predictions.horizon == h]
        one_m = metrics[metrics.horizon == h].set_index("model_id")
        assert one_m.paired_set_id.nunique() == 1
        calculated = {}
        for model in ("persistence", "clinical_ridge", "combined_ridge"):
            rows = one_h[one_h.model_id == model]
            actual_error = (rows.observed.to_numpy() - rows.prediction.to_numpy()) * 100
            calculated[model] = np.abs(actual_error).mean()
            assert one_m.loc[model, "n_origins"] == 40
            assert one_m.loc[model, "mae_pp"] == pytest.approx(calculated[model], rel=1e-12)
            assert one_m.loc[model, "rmse_pp"] == pytest.approx(np.sqrt(np.mean(actual_error ** 2)), rel=1e-12)
        delta = calculated["clinical_ridge"] - calculated["combined_ridge"]
        assert one_m.loc["combined_ridge", "delta_mae_pp"] == pytest.approx(delta, rel=1e-12, abs=1e-12)
        assert one_m.loc["combined_ridge", "relative_gain_pct"] == pytest.approx(100 * delta / calculated["clinical_ridge"])
        assert one_m.loc[["persistence", "clinical_ridge"], "delta_mae_pp"].isna().all()
    assert len(errors) == 80
    assert stages.groupby("horizon").n_origins.sum().eq(40).all()


def _one_origin_predictions(snapshot, config, fixed_parameters):
    from src.backtest import predict_origin
    from src.features import build_features
    return pd.DataFrame(predict_origin(build_features(snapshot), 170, 2, fixed_parameters, config))


def test_gain_sign_and_zero_denominator(snapshot, config, fixed_parameters):
    from src.backtest import paired_evaluate
    rows = _one_origin_predictions(snapshot, config, fixed_parameters)
    for prediction, expected_gain in [(0.19, 0.09), (0.30, 0.0)]:
        fake = rows.copy()
        fake["observed"] = .2
        fake["prediction"] = .1
        fake.loc[fake.model_id == "combined_ridge", "prediction"] = prediction
        fake["abs_error_pp"] = 100 * abs(fake.observed - fake.prediction)
        fake["squared_error_pp2"] = fake.abs_error_pp ** 2
        result, *_ = paired_evaluate(fake, config)
        gain = result.loc[result.model_id == "combined_ridge", "delta_mae_pp"].iloc[0]
        assert gain == pytest.approx(expected_gain * 100, abs=1e-12)
    rows["prediction"] = rows.observed
    rows["abs_error_pp"] = 0.0
    rows["squared_error_pp2"] = 0.0
    result, *_ = paired_evaluate(rows, config)
    assert np.isnan(result.loc[result.model_id == "combined_ridge", "relative_gain_pct"].iloc[0])


def test_mismatched_issue_times_cannot_enter_paired_evaluation(snapshot, config, fixed_parameters):
    from src.backtest import paired_evaluate
    rows = _one_origin_predictions(snapshot, config, fixed_parameters)
    rows.loc[rows.model_id == "combined_ridge", "issue_at"] += pd.Timedelta(days=1)
    result, errors, _, _ = paired_evaluate(rows, config)
    assert result.empty and errors.empty


def test_lagged_feature_availability_propagates_to_every_dependent_anchor(snapshot):
    from src.features import build_features, eligible_training_rows
    t, j = 170, 120
    changed = snapshot.copy()
    after_issue = changed.iloc[t].issue_at + pd.Timedelta(days=1)
    changed.loc[j, "feature_available_at"] = after_issue
    result = build_features(changed)
    assert result.loc[j:j + 2, "feature_available_at"].eq(after_issue).all()
    rows = eligible_training_rows(result, t, 2)
    assert not {j, j + 1, j + 2}.intersection(rows)
    assert j - 1 in rows and j + 3 in rows


@pytest.mark.parametrize("field,new_value", [
    ("source_version", "different-input-snapshot"),
    ("evaluation_vintage", "different-scoring-snapshot"),
    ("backtest_mode", "archive_asof"),
])
def test_mismatched_source_or_mode_is_not_paired(field, new_value, snapshot, config, fixed_parameters):
    from src.backtest import paired_evaluate
    rows = _one_origin_predictions(snapshot, config, fixed_parameters)
    rows.loc[rows.model_id == "combined_ridge", field] = new_value
    metrics, errors, _, _ = paired_evaluate(rows, config)
    assert metrics.empty and errors.empty


def test_inconsistent_observed_labels_are_rejected(snapshot, config, fixed_parameters):
    from src.backtest import paired_evaluate
    rows = _one_origin_predictions(snapshot, config, fixed_parameters)
    rows.loc[rows.model_id == "combined_ridge", "observed"] += .01
    with pytest.raises(ValueError, match="observed labels"):
        paired_evaluate(rows, config)


def test_exported_predictions_and_metrics_independent_csv_recalculation(config):
    """E1/E4/E5: verify the delivered CSVs, not only in-memory function results."""
    predictions_path = ROOT / "outputs/predictions.csv"
    metrics_path = ROOT / "outputs/metrics.csv"
    assert predictions_path.exists() and metrics_path.exists(), "Run validate and test pipeline stages before acceptance."
    predictions = pd.read_csv(predictions_path)
    metrics = pd.read_csv(metrics_path)
    required = {"run_id", "backtest_mode", "source_version", "evaluation_vintage", "issue_at", "anchor_year", "anchor_week", "anchor_from", "anchor_to", "target_year", "target_week", "target_from", "target_to", "horizon", "model_id", "feature_set", "n_train", "lambda", "raw_prediction", "prediction", "observed", "abs_error_pp", "squared_error_pp2", "was_clipped", "status"}
    assert required <= set(predictions)
    assert predictions[["source_version", "evaluation_vintage", "issue_at", "target_from", "target_to"]].notna().all().all()
    key = ["split", "horizon", "anchor_from", "target_from", "issue_at", "source_version", "evaluation_vintage", "backtest_mode", "model_id"]
    assert not predictions.duplicated(key).any()
    future = predictions[predictions.status == "awaiting_observation"]
    assert len(future) == 6
    assert future.issue_at.nunique() == 1, "Exported projections must share one run issue time."
    assert future[["observed", "abs_error_pp", "squared_error_pp2"]].isna().all().all()
    assert not metrics.split.eq("future").any()
    for (split, horizon), group in metrics.groupby(["split", "horizon"]):
        scored = predictions[(predictions.split == split) & (predictions.horizon == horizon) & (predictions.status == "ok")]
        assert group.paired_set_id.nunique() == 1
        errors = {}
        sets = []
        for row in group.itertuples(index=False):
            current = scored[scored.model_id == row.model_id].sort_values("anchor_from")
            sets.append(set(zip(current.anchor_from, current.target_from, current.issue_at, current.evaluation_vintage)))
            error_pp = 100 * (current.observed.to_numpy() - current.prediction.to_numpy())
            errors[row.model_id] = np.abs(error_pp).mean()
            assert row.n_origins == len(current)
            assert row.mae_pp == pytest.approx(errors[row.model_id], rel=1e-11, abs=1e-12)
            assert row.rmse_pp == pytest.approx(np.sqrt(np.mean(error_pp ** 2)), rel=1e-11, abs=1e-12)
            np.testing.assert_allclose(current.abs_error_pp, abs(error_pp), rtol=1e-11, atol=1e-12)
        assert all(one == sets[0] for one in sets)
        combined = group[group.model_id == "combined_ridge"].iloc[0]
        delta = errors["clinical_ridge"] - errors["combined_ridge"]
        assert combined.delta_mae_pp == pytest.approx(delta, rel=1e-11, abs=1e-12)
        assert combined.relative_gain_pct == pytest.approx(100 * delta / errors["clinical_ridge"], rel=1e-11, abs=1e-12)
    ridges = predictions[predictions.model_id.isin(["clinical_ridge", "combined_ridge"])]
    assert ridges.groupby(key[:-1], dropna=False).train_anchor_keys.nunique().eq(1).all()
