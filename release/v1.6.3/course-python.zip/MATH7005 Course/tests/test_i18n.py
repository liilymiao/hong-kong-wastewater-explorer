"""Independent language regressions against the actual saved monitoring outputs.

The checks exercise Streamlit callbacks and compare numerical tables, chart data
and content-addressed CSV URLs across both language directions.
"""
import json
import re

import pandas as pd
import pytest
from streamlit.testing.v1 import AppTest

from app import ROOT


CJK = re.compile(r"[\u4e00-\u9fff]")
PAGES = {
    "监测概览": "Monitoring overview",
    "历史回放": "Historical replay",
    "模型比较": "Model comparison",
    "状态与异常": "Patterns & anomalies",
}


def start():
    result = AppTest.from_file(str(ROOT / "app.py"), default_timeout=30).run()
    healthy(result)
    return result


def healthy(app):
    assert not app.exception
    assert not app.error


def toggle(app):
    app.button(key="language_toggle").click().run()
    healthy(app)


def english_visible_text(app):
    """Ignore canonical widget values and source identifiers, inspect UI copy."""
    for kind in ["title", "header", "subheader", "caption", "markdown", "text", "info", "warning", "success", "error"]:
        for item in getattr(app, kind):
            assert not CJK.search(str(item.value)), (kind, item.value)
    for kind in ["radio", "selectbox", "multiselect", "button", "metric", "tabs", "expander"]:
        for item in getattr(app, kind, []):
            label = getattr(item, "label", "")
            if getattr(item, "key", None) != "language_toggle":
                assert not CJK.search(label), (kind, label)
            for option in getattr(item, "options", []):
                assert not CJK.search(str(option)), (kind, option)
    for table in app.dataframe:
        for name in table.value.columns:
            assert not CJK.search(str(name)), ("table column", name)
        for name in table.value.select_dtypes(include=["object", "string"]):
            for value in table.value[name].dropna().astype(str).unique():
                assert not CJK.search(value), ("table value", name, value)
    for element in app.get("plotly_chart"):
        spec = json.loads(element.proto.spec)
        for trace in spec["data"]:
            for name in ["name", "hovertemplate"]:
                assert not CJK.search(str(trace.get(name, ""))), ("chart", trace.get(name))
        for key, value in spec["layout"].items():
            if key.startswith(("xaxis", "yaxis")) and isinstance(value, dict):
                assert not CJK.search(str(value.get("title", ""))), ("axis", value)
        for annotation in spec["layout"].get("annotations", []):
            assert not CJK.search(annotation.get("text", ""))


def numeric_snapshot(app):
    frames = []
    null_masks = []
    for item in app.dataframe:
        # An all-null optional URL column may deserialize as object in one
        # language and float in the other. Its missingness is checked separately.
        frame = item.value.dropna(axis=1, how="all").select_dtypes(include=["number", "bool", "datetime"]).copy()
        frame.columns = range(len(frame.columns))
        frames.append(frame)
        missing = item.value.isna()
        missing.columns = range(len(missing.columns))
        null_masks.append(missing)
    charts = []
    for item in app.get("plotly_chart"):
        traces = json.loads(item.proto.spec)["data"]
        for trace in traces:
            # Only presentation text is permitted to vary with language.
            for name in ["name", "hovertemplate", "text"]:
                trace.pop(name, None)
        charts.append(traces)
    return frames, charts, [item.proto.url for item in app.get("download_button")], null_masks


def assert_numeric_snapshot(app, expected):
    frames, charts, downloads, null_masks = numeric_snapshot(app)
    before_frames, before_charts, before_downloads, before_null_masks = expected
    assert len(frames) == len(before_frames)
    for left, right in zip(frames, before_frames):
        pd.testing.assert_frame_equal(left, right)
    for left, right in zip(null_masks, before_null_masks):
        pd.testing.assert_frame_equal(left, right)
    assert charts == before_charts
    # Streamlit hashes the CSV contents, MIME type and filename into this URL.
    assert downloads == before_downloads


def set_control(app, kind, key, value):
    getattr(app, kind)(key=key).set_value(value).run()
    healthy(app)


def test_fresh_session_is_english_with_one_language_button_on_all_pages():
    app = start()
    assert app.session_state["ui_language"] == "en"
    for page, english in PAGES.items():
        set_control(app, "radio", "page", page)
        assert app.title[0].value == english
        assert app.button(key="language_toggle").label == "中文"
        assert sum(item.key == "language_toggle" for item in app.button) == 1
        assert not [item for item in app.selectbox if item.key in {"language", "ui_language"}]
        english_visible_text(app)


CASES = [
    ("监测概览", [
        ("multiselect", "overview_years", [2023, 2026]),
        ("radio", "overview_scale", "log(1＋w)"),
    ]),
    ("历史回放", [
        ("selectbox", "replay_split", "validation"),
        ("selectbox", "replay_horizon", 1),
        ("selectbox", "replay_delay", 8),
        ("radio", "replay_score", "raw"),
        ("selectbox", "replay_anchor", "2025W20"),
    ]),
    ("模型比较", [
        ("radio", "compare_score", "raw"),
        ("selectbox", "compare_split", "validation"),
        ("selectbox", "compare_horizon", 1),
        ("multiselect", "compare_models", ["clinical_ridge", "combined_ridge"]),
    ]),
    ("状态与异常", [
        ("multiselect", "patterns_years", [2025, 2026]),
        ("radio", "patterns_sort", "监测周从近到远"),
        ("selectbox", "pattern_week", "2026W28"),
        ("selectbox", "neighbors_k", 15),
    ]),
]


@pytest.mark.parametrize("page,controls", CASES, ids=["overview", "replay", "comparison", "patterns"])
def test_language_roundtrip_preserves_current_controls_and_numeric_outputs(page, controls):
    app = start()
    set_control(app, "radio", "page", page)
    for kind, key, value in controls:
        set_control(app, kind, key, value)
    baseline = numeric_snapshot(app)
    for lang in ["zh", "en"]:
        toggle(app)
        assert app.session_state["ui_language"] == lang
        assert app.radio(key="page").value == page
        assert app.title[0].value == (page if lang == "zh" else PAGES[page])
        assert app.button(key="language_toggle").label == ("English" if lang == "zh" else "中文")
        for kind, key, value in controls:
            assert getattr(app, kind)(key=key).value == value, key
        assert_numeric_snapshot(app, baseline)
        if lang == "en":
            english_visible_text(app)


def test_future_unscored_records_and_h3_timing_survive_language_roundtrip():
    app = start()
    set_control(app, "radio", "page", "历史回放")
    set_control(app, "selectbox", "replay_split", "future")
    set_control(app, "selectbox", "replay_horizon", 2)
    set_control(app, "selectbox", "replay_delay", 8)
    set_control(app, "radio", "replay_score", "raw")
    baseline = numeric_snapshot(app)
    for lang in ["en", "zh", "en"]:
        if app.session_state["ui_language"] != lang:
            toggle(app)
        assert app.selectbox(key="replay_split").value == "future"
        assert app.selectbox(key="replay_horizon").value == 2
        assert app.selectbox(key="replay_delay").value == 8
        assert any("h3" in item.value for item in app.warning)
        observed = "实际（%）" if lang == "zh" else "Observed (%)"
        error = "绝对误差（百分点）" if lang == "zh" else "Absolute error (pp)"
        assert app.dataframe[0].value[observed].isna().all()
        assert app.dataframe[0].value[error].isna().all()
        assert_numeric_snapshot(app, baseline)
        if lang == "en":
            english_visible_text(app)


def test_language_switch_preserves_inactive_page_filters_when_returning():
    app = start()
    set_control(app, "radio", "page", "历史回放")
    set_control(app, "selectbox", "replay_horizon", 1)
    set_control(app, "selectbox", "replay_anchor", "2026W17")
    set_control(app, "radio", "replay_score", "raw")
    replay_before = numeric_snapshot(app)
    set_control(app, "radio", "page", "监测概览")
    set_control(app, "multiselect", "overview_years", [2026])
    set_control(app, "radio", "overview_scale", "log(1＋w)")
    overview_before = numeric_snapshot(app)
    toggle(app)
    set_control(app, "radio", "page", "历史回放")
    assert app.selectbox(key="replay_horizon").value == 1
    assert app.selectbox(key="replay_anchor").value == "2026W17"
    assert app.radio(key="replay_score").value == "raw"
    assert_numeric_snapshot(app, replay_before)
    set_control(app, "radio", "page", "监测概览")
    assert app.multiselect(key="overview_years").value == [2026]
    assert app.radio(key="overview_scale").value == "log(1＋w)"
    assert_numeric_snapshot(app, overview_before)


def test_empty_filters_and_unavailable_pattern_status_remain_english():
    app = start()
    set_control(app, "multiselect", "overview_years", [])
    assert any("Select at least one monitoring year" in item.value for item in app.info)
    toggle(app)
    assert app.multiselect(key="overview_years").value == []
    toggle(app)
    assert app.multiselect(key="overview_years").value == []
    set_control(app, "radio", "page", "状态与异常")
    set_control(app, "multiselect", "patterns_years", [2023])
    set_control(app, "selectbox", "pattern_week", "2023W5")
    assert any("missing" in item.value.lower() for item in app.warning)
    english_visible_text(app)
