"""Meaningful UI smoke checks and calendar/scale boundary checks.

AppTest checks use the actual saved analysis bundle; no synthetic monitoring
records enter the app or main outputs. The two-row unit fixture only tests the
mathematical display boundary.
"""
from pathlib import Path

import pandas as pd
import pytest

from app import ROOT, csv_bytes, filter_predictions, percent, pp, timing_for_row


def test_display_units_are_applied_once():
    assert percent(0.01) == "1.00%"
    assert pp(1.0) == "1.000"
    assert percent(float("nan")) == "暂无"


def test_calendar_delay_does_not_relabel_h2():
    row = pd.Series({"anchor_from": "2026-10-11", "anchor_to": "2026-10-17", "target_from": "2026-10-25"})
    normal = timing_for_row(row, 5)
    saturday = timing_for_row(row, 7)
    late = timing_for_row(row, 8)
    assert normal["display_issue_at"] == "2026-10-22T23:59:00+08:00"
    assert not saturday["target_started"]
    assert saturday["next_future_from"] == "2026-10-25"
    assert late["target_started"]
    assert late["next_future_from"] == "2026-11-01"
    assert late["next_future_horizon"] == 3
    assert not late["dynamic_prediction_available"]
    assert row.target_from == "2026-10-25"


@pytest.fixture
def saved_outputs():
    required = [ROOT / "data/processed/clean.csv", ROOT / "outputs/predictions.csv", ROOT / "outputs/metrics.csv"]
    if not all(path.exists() for path in required):
        pytest.skip("Actual pipeline outputs have not been generated yet")
    return required


def test_export_is_exact_filter_and_future_is_unscored(saved_outputs):
    from app import prepare_frames
    clean, predictions = prepare_frames(pd.read_csv(saved_outputs[0]), pd.read_csv(saved_outputs[1]))
    view = filter_predictions(predictions, "test", 2)
    assert not view.empty
    assert view.split.eq("test").all() and view.horizon.eq(2).all()
    assert csv_bytes(view).startswith(b"\xef\xbb\xbf")
    future = filter_predictions(predictions, "future", 2)
    assert not future.empty
    assert future[["observed", "abs_error_pp", "squared_error_pp2"]].isna().all().all()


def test_all_four_pages_render_real_outputs(saved_outputs):
    from streamlit.testing.v1 import AppTest
    app = AppTest.from_file(str(ROOT / "app.py"), default_timeout=30).run()
    app.button(key="language_toggle").click().run()
    assert not app.exception
    assert not app.error
    assert app.title[0].value == "监测概览"
    assert not any("deprecated" in w.value for w in app.warning)
    for page in ["历史回放", "模型比较", "状态与异常"]:
        app.radio(key="page").set_value(page).run()
        assert not app.exception, f"{page}: {app.exception}"
        assert not app.error, f"{page}: {app.error}"
        assert app.title[0].value == page
        assert not any("deprecated" in w.value for w in app.warning)


def test_replay_future_and_late_delay_have_explicit_states(saved_outputs):
    from streamlit.testing.v1 import AppTest
    app = AppTest.from_file(str(ROOT / "app.py"), default_timeout=30).run()
    app.button(key="language_toggle").click().run()
    app.radio(key="page").set_value("历史回放").run()
    app.selectbox(key="replay_split").set_value("future").run()
    app.selectbox(key="replay_horizon").set_value(2).run()
    app.selectbox(key="replay_delay").set_value(8).run()
    assert not app.exception
    assert not app.error
    assert any("h3 预测不可用" in warning.value for warning in app.warning)
    forecast = app.dataframe[0].value
    assert forecast["实际（%）"].isna().all()
    assert forecast["绝对误差（百分点）"].isna().all()


def test_widget_filters_change_real_records(saved_outputs):
    from streamlit.testing.v1 import AppTest
    app = AppTest.from_file(str(ROOT / "app.py"), default_timeout=30).run()
    app.button(key="language_toggle").click().run()
    before = len(app.dataframe[0].value)
    app.multiselect(key="overview_years").set_value([2026]).run()
    assert not app.exception
    assert not app.error
    assert 0 < len(app.dataframe[0].value) < before
    assert app.dataframe[0].value["官方监测周"].str.startswith("2026").all()
    app.radio(key="page").set_value("模型比较").run()
    app.multiselect(key="compare_models").set_value(["combined_ridge"]).run()
    assert not app.exception
    assert not app.error
    assert len(app.dataframe[0].value) == 1
