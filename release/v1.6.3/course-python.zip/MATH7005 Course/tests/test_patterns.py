"""Numerical and temporal checks on explicitly synthetic test data."""

import json
import copy

import numpy as np
import pandas as pd
import pytest

from src.patterns import (KMeans, LOFNovelty, Standardizer, adjusted_rand_score,
                          silhouette_score)
from src.pattern_pipeline import (STATE_FEATURES, build_state_features,
                                  freeze_pattern_config, run_patterns,
                                  _rank_novelty_queries)


def test_standardizer_uses_reference_only_and_constant_scale():
    x = np.array([[1.0, 3.0], [3.0, 3.0]])
    scaler = Standardizer().fit(x)
    np.testing.assert_allclose(scaler.mean_, [2, 3])
    np.testing.assert_allclose(scaler.scale_, [1, 1])
    np.testing.assert_allclose(scaler.transform([[100, 3]]), [[98, 0]])
    np.testing.assert_allclose(scaler.mean_, [2, 3])
    assert scaler.constant_columns_.tolist() == [False, True]


def test_kmeans_assignments_centers_and_reproducibility():
    x = np.array([[-1.1, 0], [-1.0, 0], [-0.9, 0], [5.9, 1], [6, 1], [6.1, 1]])
    a = KMeans(2, random_state=42).fit(x)
    b = KMeans(2, random_state=42).fit(x)
    np.testing.assert_array_equal(a.labels_, [0, 0, 0, 1, 1, 1])
    np.testing.assert_allclose(a.cluster_centers_, [[-1, 0], [6, 1]])
    np.testing.assert_array_equal(a.cluster_centers_, b.cluster_centers_)
    np.testing.assert_array_equal(a.labels_, b.labels_)
    np.testing.assert_array_equal(a.predict(x), a.labels_)
    assert a.inertia_ == pytest.approx(0.04)
    assert a.converged_
    assert a.effective_k_ == 2
    assert a.n_distinct_points_ == len(x)


def test_kmeans_rejects_fewer_distinct_points_than_clusters():
    with pytest.raises(ValueError, match="distinct reference points"):
        KMeans(4).fit(np.zeros((8, 2)))
    with pytest.raises(ValueError, match="distinct reference points"):
        KMeans(3).fit([[0], [0], [0], [1], [1], [1]])


def test_kmeans_repairs_empty_initial_clusters(monkeypatch):
    x = np.array([[0.0], [1.0], [2.0], [10.0]])
    model = KMeans(3, n_init=1)
    monkeypatch.setattr(model, "_initialize", lambda x, rng: np.zeros((3, 1)))
    model.fit(x)
    assert np.all(np.bincount(model.labels_, minlength=3) > 0)
    assert np.isfinite(model.cluster_centers_).all()
    np.testing.assert_allclose(model.cluster_centers_, [[0.5], [2.0], [10.0]])
    np.testing.assert_array_equal(model.labels_, model.predict(x))
    assert model.converged_
    assert model.effective_k_ == 3
    assert model.inertia_ == pytest.approx(0.5)
    for k in range(3):
        np.testing.assert_array_equal(model.cluster_centers_[k], x[model.labels_ == k].mean(axis=0))


def test_kmeans_iteration_limit_reassigns_labels_and_reports_nonconvergence():
    x = np.random.default_rng(0).normal(size=(20, 2))
    model = KMeans(3, n_init=1, max_iter=1, random_state=42, tol=0).fit(x)
    assert model.n_iter_ == 1
    assert not model.converged_
    assert model.effective_k_ == 3
    np.testing.assert_array_equal(model.labels_, model.predict(x))
    distances_squared = ((x[:, None, :] - model.cluster_centers_[None, :, :]) ** 2).sum(axis=2)
    assert model.inertia_ == pytest.approx(distances_squared.min(axis=1).sum())


def test_lof_manual_distance_density_and_novelty_score():
    model = LOFNovelty(1).fit(np.array([[0.0], [1.0], [2.0]]))
    np.testing.assert_array_equal(model.neighbors_, [[1], [0], [1]])
    np.testing.assert_allclose(model.k_distances_, [1, 1, 1])
    np.testing.assert_allclose(model.lrd_, [1, 1, 1])
    np.testing.assert_allclose(model.reference_scores_, [1, 1, 1])
    details = model.query_details(np.array([[1.1], [10.0]]))
    np.testing.assert_allclose(details["scores"], [1, 8])
    np.testing.assert_allclose(details["lrd"], [1, 1 / 8])
    np.testing.assert_allclose(details["reachability_distances"], [[1], [8]])


def test_lof_self_exclusion_stable_ties_and_duplicate_stability():
    x = np.zeros((4, 2))
    model = LOFNovelty(2).fit(x)
    np.testing.assert_array_equal(model.neighbors_, [[1, 2], [0, 2], [0, 1], [0, 1]])
    assert not np.any(model.neighbors_ == np.arange(4)[:, None])
    assert model.duplicate_rows_ == 4
    assert model.duplicate_pairs_ == 6
    np.testing.assert_allclose(model.reference_scores_, 1)
    scores = model.score_samples([[0, 0], [1, 0]])
    assert np.isfinite(scores).all()
    assert scores[0] == pytest.approx(1)
    assert scores[1] > scores[0]


def test_queries_do_not_modify_fitted_lof_neighbors_or_density():
    rng = np.random.default_rng(3)
    model = LOFNovelty(5).fit(rng.normal(size=(30, 4)))
    neighbors = model.neighbors_.copy()
    lrd = model.lrd_.copy()
    score = model.score_samples([[0, 0, 0, 0]])
    model.score_samples([[1e6, 1e6, 1e6, 1e6]])
    np.testing.assert_array_equal(model.neighbors_, neighbors)
    np.testing.assert_array_equal(model.lrd_, lrd)
    np.testing.assert_array_equal(model.score_samples([[0, 0, 0, 0]]), score)


def test_silhouette_and_ari_are_label_permutation_invariant():
    x = np.array([[0.0], [1.0], [10.0], [11.0]])
    labels = np.array([0, 0, 1, 1])
    expected = np.mean([1 - 1 / 10.5, 1 - 1 / 9.5, 1 - 1 / 9.5, 1 - 1 / 10.5])
    assert silhouette_score(x, labels) == pytest.approx(expected)
    assert adjusted_rand_score(labels, 1 - labels) == pytest.approx(1)
    assert adjusted_rand_score(labels, np.array([0, 1, 0, 1])) == pytest.approx(-0.5)


def _synthetic_snapshot(n=72):
    index = np.arange(n)
    start = pd.date_range("2023-01-29", periods=n, freq="7D")
    end = start + pd.Timedelta(days=6)
    return pd.DataFrame({"week_key": [f"synthetic{i:03}" for i in index],
                         "Year": start.year, "Week": index % 52 + 1,
                         "From": start, "To_corrected": end,
                         "SARSCoV2_proportion": 0.04 + 0.02 * np.sin(index / 5),
                         "Sewage_viralload": np.exp(5 + np.cos(index / 6)),
                         "source_version": "synthetic_test_only",
                         "source_row_key": [f"synthetic:{i}" for i in index],
                         "issue_at": (end + pd.Timedelta(days=5, hours=23, minutes=59)).tz_localize("Asia/Hong_Kong")})


def _config():
    return {"project": {"timezone": "Asia/Hong_Kong"},
            "data": {"target": "SARSCoV2_proportion", "sewage": "Sewage_viralload"},
            "evaluation": {"seed": 42},
            "timing": {"nominal_issue_time_hkt": "23:59", "nominal_issue_days_after_week_end": 5},
            "split": {"warmup_weeks": 60, "test_origin_year": 2026,
                      "validation_origin_year": 2025,
                      "test_origin_week_range": {"start_week": 1, "end_week": 40}},
            "patterns": {"kmeans_candidates": [2, 3, 4], "kmeans_initializations": 3,
                         "kmeans_max_iterations": 300, "reference_window_weeks": 104,
                         "reference_end_offset_weeks": 1, "minimum_reference_rows": 52,
                         "lof_neighbors": [5, 10, 15], "lof_primary_neighbors": 10,
                         "score_queries_as_novelty": True}}


def test_state_features_respect_exact_calendar_lags_and_missing_values():
    frame = _synthetic_snapshot()
    frame.loc[10, "Sewage_viralload"] = np.nan
    state = build_state_features(frame, _config())
    assert not state.loc[[0, 1, 10, 12], "state_valid"].any()
    assert state.loc[11, "state_valid"]
    sparse = frame.drop(index=20)
    result = build_state_features(sparse, _config())
    assert not result.loc[result["week_key"] == "synthetic022", "state_valid"].iloc[0]


def test_freezing_ignores_all_post_warmup_observations(tmp_path):
    frame, config = _synthetic_snapshot(), _config()
    a = freeze_pattern_config(frame, config, tmp_path / "a")["frozen_config"]
    changed = frame.copy()
    changed.loc[60:, "SARSCoV2_proportion"] = 0.99
    changed.loc[60:, "Sewage_viralload"] = 1e12
    b = freeze_pattern_config(changed, config, tmp_path / "b")["frozen_config"]
    a.pop("configuration_created_at_utc")
    b.pop("configuration_created_at_utc")
    assert a == b
    assert a["selection_data_end"] == "synthetic059"
    assert a["selection_complete_states"] == 58


def test_rolling_reference_excludes_query_and_future_perturbations(tmp_path):
    frame, config = _synthetic_snapshot(), _config()
    freeze_pattern_config(frame, config, tmp_path)
    outputs = run_patterns(frame, config, tmp_path)
    initial = pd.read_csv(outputs["patterns_csv"])
    center_initial = pd.read_csv(outputs["centers_csv"])
    neighbor_initial = pd.read_csv(outputs["neighbors_csv"])
    sensitivity_initial = pd.read_csv(outputs["sensitivity_csv"])
    changed = frame.copy()
    changed.loc[65:, "SARSCoV2_proportion"] = 0.99
    changed.loc[65:, "Sewage_viralload"] = 1e12
    run_patterns(changed, config, tmp_path)
    altered = pd.read_csv(outputs["patterns_csv"])
    pd.testing.assert_frame_equal(initial.iloc[:65], altered.iloc[:65])
    for name in ["reference_hash", "reference_start", "reference_end", "n_reference"]:
        assert initial.loc[65, name] == altered.loc[65, name]
    for feature in STATE_FEATURES:
        assert initial.loc[65, feature + "_reference_mean"] == altered.loc[65, feature + "_reference_mean"]
        assert initial.loc[65, feature + "_reference_scale"] == altered.loc[65, feature + "_reference_scale"]
    center_altered = pd.read_csv(outputs["centers_csv"])
    pd.testing.assert_frame_equal(center_initial.loc[center_initial.query_week_key <= "synthetic065"].reset_index(drop=True),
                                  center_altered.loc[center_altered.query_week_key <= "synthetic065"].reset_index(drop=True))
    assert initial.loc[65, "reference_end"] == "synthetic064"
    assert (initial.loc[60:, "status"] == "ok").all()
    assert initial.loc[60:, "kmeans_converged"].all()
    assert (initial.loc[60:, "kmeans_effective_k"] == initial.loc[60:, "cluster_k"]).all()
    sensitivity_altered = pd.read_csv(outputs["sensitivity_csv"])
    as_of_columns = ["week_key", "lof_k", "lof_score", "rank_as_of", "n_scored_as_of"]
    earlier = sensitivity_initial.week_key < "synthetic065"
    pd.testing.assert_frame_equal(sensitivity_initial.loc[earlier, as_of_columns].reset_index(drop=True),
                                  sensitivity_altered.loc[earlier, as_of_columns].reset_index(drop=True))
    assert not sensitivity_initial.loc[earlier, "rank_all"].equals(sensitivity_altered.loc[earlier, "rank_all"])
    assert (sensitivity_initial.rank_all_cutoff_week == "synthetic071").all()
    for query, group in neighbor_initial.groupby("query_week_key"):
        assert (group["neighbor_week_key"] < query).all()
    assert json.loads((tmp_path / "pattern_config.json").read_text())["neighbor_tie_rule"].endswith("exclude_self")


def test_reference_calendar_window_and_missing_query_status(tmp_path):
    frame, config = _synthetic_snapshot(170), _config()
    config["patterns"]["kmeans_initializations"] = 1
    config["patterns"]["kmeans_candidates"] = [2]
    frame.loc[164, "Sewage_viralload"] = np.nan
    freeze_pattern_config(frame, config, tmp_path)
    outputs = run_patterns(frame, config, tmp_path)
    result = pd.read_csv(outputs["patterns_csv"])
    assert result.loc[169, "reference_start"] == "synthetic065"
    assert result.loc[169, "reference_end"] == "synthetic168"
    assert result.loc[169, "n_reference_calendar"] == 104
    assert result.loc[169, "n_reference"] == 102
    assert result.loc[164, "status"] == "missing_query_features"
    assert result.loc[166, "status"] == "missing_query_features"
    assert len(result) == len(frame)


def test_run_requires_existing_frozen_config(tmp_path):
    with pytest.raises(FileNotFoundError, match="freeze_pattern_config"):
        run_patterns(_synthetic_snapshot(), _config(), tmp_path)


def test_frozen_configuration_is_idempotent_and_refuses_overwrite(tmp_path):
    frame, config = _synthetic_snapshot(), _config()
    initial = freeze_pattern_config(frame, config, tmp_path)["frozen_config"]
    before = (tmp_path / "pattern_config.json").read_bytes()
    repeated = freeze_pattern_config(frame, config, tmp_path)["frozen_config"]
    assert initial == repeated
    assert (tmp_path / "pattern_config.json").read_bytes() == before
    changed = frame.copy()
    changed.loc[30, "SARSCoV2_proportion"] += 0.01
    with pytest.raises(ValueError, match="new output directory"):
        freeze_pattern_config(changed, config, tmp_path)
    assert (tmp_path / "pattern_config.json").read_bytes() == before


def test_rolling_rejects_changed_development_states_before_writing(tmp_path):
    frame, config = _synthetic_snapshot(), _config()
    freeze_pattern_config(frame, config, tmp_path)
    outputs = run_patterns(frame, config, tmp_path)
    before = (tmp_path / "patterns.csv").read_bytes()
    changed = frame.copy()
    changed.loc[30, "SARSCoV2_proportion"] += 0.01
    with pytest.raises(ValueError, match="development states changed after freezing"):
        run_patterns(changed, config, tmp_path)
    assert (tmp_path / "patterns.csv").read_bytes() == before
    assert outputs["patterns_csv"] == str(tmp_path / "patterns.csv")


def test_known_stability_description_upgrade_preserves_frozen_decision(tmp_path):
    frame, config = _synthetic_snapshot(), _config()
    original = freeze_pattern_config(frame, config, tmp_path)["frozen_config"]
    legacy = copy.deepcopy(original)
    legacy["selection_rule"] = ("0.5*silhouette + 0.5*mean_contiguous_block_leave_out_ARI; "
                                "ties within 1e-12 select smaller k")
    legacy["stability_rule"] = ("five contiguous calendar blocks; omit each block, "
                                "refit scaler and kmeans; compare partitions on all "
                                "development rows using adjusted Rand index")
    (tmp_path / "pattern_config.json").write_text(json.dumps(legacy))
    upgraded = freeze_pattern_config(frame, config, tmp_path)["frozen_config"]
    assert upgraded == original
    assert "state-vector anchor rows" in upgraded["stability_rule"]
    altered_rule = copy.deepcopy(upgraded)
    altered_rule["stability_rule"] = "changed algorithm"
    (tmp_path / "pattern_config.json").write_text(json.dumps(altered_rule))
    with pytest.raises(ValueError, match="new output directory"):
        freeze_pattern_config(frame, config, tmp_path)


def test_cumulative_rank_ties_calendar_order_and_retrospective_cutoffs():
    # Deliberately unsorted and with non-padded week labels. The expected
    # cumulative ranks are hand-computed for scores 2, 3, 2, 5.
    rows = pd.DataFrame({"week_key": ["2025W10", "2025W8", "2025W11", "2025W9"],
                         "query_from": pd.to_datetime(["2025-03-02", "2025-02-16", "2025-03-09", "2025-02-23"]),
                         "period": ["test", "validation", "test", "validation"],
                         "lof_k": [10, 10, 10, 10], "lof_score": [2.0, 2.0, 5.0, 3.0]})
    ranked = _rank_novelty_queries(rows)
    assert ranked.week_key.tolist() == ["2025W8", "2025W9", "2025W10", "2025W11"]
    assert ranked.rank_as_of.tolist() == [1, 1, 2, 1]
    assert ranked.n_scored_as_of.tolist() == [1, 2, 3, 4]
    assert ranked.rank_all.tolist() == [3, 2, 3, 1]
    assert ranked.rank_period.tolist() == [2, 1, 2, 1]
    assert ranked.rank_all_cutoff_week.tolist() == ["2025W11"] * 4
    assert ranked.rank_period_cutoff_week.tolist() == ["2025W9", "2025W9", "2025W11", "2025W11"]
    past = _rank_novelty_queries(rows.loc[rows.query_from < pd.Timestamp("2025-03-09")])
    pd.testing.assert_frame_equal(ranked.iloc[:3][["rank_as_of", "n_scored_as_of"]],
                                  past[["rank_as_of", "n_scored_as_of"]])


@pytest.mark.parametrize("field,value", [("reference_window_weeks", 80),
                                        ("kmeans_candidates", [2, 3]),
                                        ("lof_primary_neighbors", 5)])
def test_rolling_rejects_changed_pattern_configuration(tmp_path, field, value):
    frame, config = _synthetic_snapshot(), _config()
    freeze_pattern_config(frame, config, tmp_path)
    changed = copy.deepcopy(config)
    changed["patterns"][field] = value
    with pytest.raises(ValueError, match="changed after freezing"):
        run_patterns(frame, changed, tmp_path)
