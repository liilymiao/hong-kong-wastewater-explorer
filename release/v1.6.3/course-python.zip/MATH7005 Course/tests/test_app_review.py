"""Review regressions: calendar gaps, score meaning, output guards and launch paths."""
from pathlib import Path
import hashlib
import io
import os
import sys

import numpy as np
import pandas as pd
import pytest

import app as dashboard
import launch


def actual_frames():
    root = dashboard.ROOT
    return dashboard.prepare_frames(
        pd.read_csv(root / "data/processed/clean.csv"),
        pd.read_csv(root / "outputs/predictions.csv"),
    )


def start_app():
    from streamlit.testing.v1 import AppTest
    app = AppTest.from_file(str(dashboard.ROOT / "app.py"), default_timeout=30).run()
    app.button(key="language_toggle").click().run()
    assert not app.exception
    assert not app.error
    return app


def assert_healthy(app):
    assert not app.exception
    assert not app.error


def test_nonconsecutive_years_keep_plot_gaps_and_exports_unchanged():
    clean, _ = actual_frames()
    selected = clean.loc[clean.Year.isin([2023, 2025])].copy()
    chart = dashboard.calendar_chart_frame(selected)
    inserted = chart.week_key.isna()
    assert inserted.any()
    assert chart.loc[inserted, ["SARSCoV2_proportion", "Sewage_viralload"]].isna().all().all()
    assert chart.From.diff().dropna().eq(pd.Timedelta(days=7)).all()
    retained = chart.loc[~inserted].set_index("week_key")
    original = selected.set_index("week_key")
    np.testing.assert_allclose(retained.SARSCoV2_proportion, original.SARSCoV2_proportion)
    assert len(selected) == int(clean.Year.isin([2023, 2025]).sum())
    assert set(pd.read_csv(io.BytesIO(dashboard.csv_bytes(selected))).Year) == {2023, 2025}


def test_csv_cache_refreshes_replaced_content_with_preserved_mtime(tmp_path):
    path = tmp_path / "cache_boundary.csv"
    path.write_text("value\n1\n")
    timestamp = path.stat().st_mtime_ns
    first_digest = hashlib.sha256(path.read_bytes()).hexdigest()
    first = dashboard.read_csv(str(path), timestamp, first_digest)
    path.write_text("value\n2\n")
    os.utime(path, ns=(timestamp, timestamp))
    second_digest = hashlib.sha256(path.read_bytes()).hexdigest()
    second = dashboard.read_csv(str(path), timestamp, second_digest)
    assert first.value.iloc[0] == 1
    assert second.value.iloc[0] == 2


@pytest.mark.parametrize("filename,missing", [
    ("metrics.csv", "horizon"),
    ("patterns.csv", "lof_score"),
    ("raw_bootstrap_sensitivity.csv", "low"),
])
def test_saved_output_schema_has_actionable_errors(filename, missing):
    source_name = filename.removeprefix("raw_")
    frame = pd.read_csv(dashboard.ROOT / "outputs" / source_name)
    with pytest.raises(dashboard.OutputDataError, match=filename):
        dashboard.validate_columns(frame.drop(columns=missing), filename)


def test_empty_year_filters_and_unscored_pattern_week_render_safely():
    app = start_app()
    app.multiselect(key="overview_years").set_value([]).run()
    assert_healthy(app)
    assert any("至少一个" in item.value for item in app.info)
    app.radio(key="page").set_value("状态与异常").run()
    app.multiselect(key="patterns_years").set_value([2023]).run()
    app.selectbox(key="pattern_week").set_value("2023W5").run()
    assert_healthy(app)
    assert any("特征缺失" in item.value for item in app.warning)
    app.multiselect(key="patterns_years").set_value([]).run()
    assert_healthy(app)


def test_raw_replay_uses_saved_raw_prediction_and_corresponding_error():
    _, predictions = actual_frames()
    candidate = predictions.loc[
        (predictions.split == "test") & (predictions.horizon == 2)
        & (predictions.model_id == "combined_ridge") & predictions.was_clipped
    ].iloc[0]
    app = start_app()
    app.radio(key="page").set_value("历史回放").run()
    app.selectbox(key="replay_anchor").set_value(candidate.anchor_key).run()
    app.radio(key="replay_score").set_value("raw").run()
    assert_healthy(app)
    table = app.dataframe[0].value
    joint = table.loc[table["模型"] == dashboard.MODEL_NAMES["combined_ridge"]].iloc[0]
    assert joint["预测（%）"] == pytest.approx(candidate.raw_prediction * 100)
    assert joint["绝对误差（百分点）"] == pytest.approx(candidate.raw_abs_error_pp)
    assert joint["预测（%）"] != pytest.approx(candidate.prediction * 100)


def test_score_switch_uses_matching_saved_metrics_and_error_definition():
    _, predictions = actual_frames()
    selected = predictions.loc[(predictions.split == "test") & (predictions.horizon == 2)]
    app = start_app()
    app.radio(key="page").set_value("模型比较").run()
    for mode, column in [("clipped", "prediction"), ("raw", "raw_prediction")]:
        app.radio(key="compare_score").set_value(mode).run()
        assert_healthy(app)
        table = app.dataframe[0].value
        for model_id, model_name in dashboard.MODEL_NAMES.items():
            rows = selected.loc[selected.model_id == model_id]
            expected = float((rows.observed - rows[column]).abs().mean() * 100)
            shown = table.loc[table["模型"] == model_name, "MAE（百分点）"].iloc[0]
            assert shown == pytest.approx(expected)
    app.multiselect(key="compare_models").set_value([]).run()
    assert_healthy(app)
    assert app.dataframe[0].value.empty


def test_pattern_asof_ranks_and_actual_trends_are_distinct_from_centers():
    app = start_app()
    app.radio(key="page").set_value("状态与异常").run()
    app.multiselect(key="patterns_years").set_value([2025]).run()
    app.selectbox(key="pattern_week").set_value("2025W1").run()
    assert_healthy(app)
    ranked = [item.value for item in app.dataframe if "截至查询周名次" in item.value]
    assert len(ranked) == 1
    assert ranked[0]["截至查询周名次"].eq(1).all()
    assert ranked[0]["截至查询周有效周数"].eq(1).all()
    assert "rank_all" not in ranked[0]
    assert "所属簇中心特征" in app.dataframe[0].value
    labels = [item.label for item in app.metric]
    assert "查询周临床两周变化（百分点）" in labels
    assert "查询周污水两周变化 · log(1＋w)" in labels


def test_required_output_error_is_shown_without_bare_traceback(monkeypatch):
    from streamlit.testing.v1 import AppTest
    original = dashboard.read_csv

    def read_with_bad_metrics(path, modified_ns, content_sha256=""):
        frame = original(path, modified_ns, content_sha256)
        return frame.drop(columns="horizon") if Path(path).name == "metrics.csv" else frame

    monkeypatch.setattr(dashboard, "read_csv", read_with_bad_metrics)
    app = AppTest.from_string("import app\napp.main()", default_timeout=30).run()
    assert not app.exception
    assert any("metrics.csv" in item.value and "horizon" in item.value for item in app.error)
    assert any("--stage all" in item.value for item in app.code)


def test_launcher_uses_active_python_absolute_app_and_selected_port(monkeypatch, tmp_path):
    calls = []
    monkeypatch.chdir(tmp_path)
    monkeypatch.setattr(launch.importlib.util, "find_spec", lambda _: object())
    monkeypatch.setattr(launch.subprocess, "call", lambda command, cwd: calls.append((command, cwd)) or 0)
    assert launch.main(["--port", "8502"]) == 0
    command, cwd = calls[0]
    assert command[0] == sys.executable
    assert command[4] == str(Path(launch.__file__).resolve().parent / "course_demo.py")
    assert cwd == Path(launch.__file__).resolve().parent
    assert "--server.address=127.0.0.1" in command
    assert "--server.port=8502" in command
    with pytest.raises(SystemExit):
        launch.main(["--port", "0"])
