"""Course acceptance: calendar gaps and the twelve saved scoring states.

Future perturbation, label availability, standardization, parameter selection
and historical pattern references are covered by test_acceptance.py,
test_forecast_review.py and test_patterns.py; these cases add missing coverage.
"""
from pathlib import Path

import numpy as np
import pandas as pd
import pytest
import yaml

from src.backtest import paired_evaluate, predict_origin
from src.data import load_snapshot, validate_week_index
from src.features import build_features, eligible_training_rows

ROOT = Path(__file__).resolve().parents[1]


@pytest.fixture(scope='module')
def config():
    return yaml.safe_load((ROOT / 'config.yaml').read_text(encoding='utf-8'))


@pytest.fixture(scope='module')
def snapshot(config):
    return load_snapshot(ROOT / config['data']['csv'], config, project_root=ROOT)


def test_deleted_calendar_week_is_rejected_before_lag_construction(snapshot, config, tmp_path):
    """A deleted row must never silently turn a two-week gap into lag one."""
    missing_week = snapshot.drop(index=120).reset_index(drop=True)
    with pytest.raises(ValueError, match='Non-contiguous weekly index'):
        validate_week_index(missing_week)
    raw = pd.read_csv(ROOT / config['data']['csv'])
    raw = raw[~((raw.Year == snapshot.iloc[120].Year) & (raw.Week == snapshot.iloc[120].Week))]
    path = tmp_path / 'missing_week.csv'
    raw.to_csv(path, index=False)
    # Hash checking is disabled only for this deliberately corrupted fixture.
    with pytest.raises(ValueError, match='Non-contiguous weekly index'):
        load_snapshot(path, config, project_root=ROOT, verify_hash=False)


def test_preserved_calendar_missing_week_does_not_compress_lags(snapshot):
    """An unmeasured week remains in the calendar and invalidates all used lags."""
    changed = snapshot.copy()
    j = 120
    changed.loc[j, ['SARSCoV2_proportion', 'Sewage_viralload']] = np.nan
    validate_week_index(changed)
    f = build_features(changed)
    assert f.From.equals(snapshot.From)
    for lag in (0, 1, 2):
        assert pd.isna(f.loc[j + lag, f'p_lag_{lag}'])
        assert pd.isna(f.loc[j + lag, f'w_log1p_lag_{lag}'])
        assert not f.loc[j + lag, 'paired_complete']
    assert f.loc[j + 3, 'p_lag_2'] == snapshot.loc[j + 1, 'SARSCoV2_proportion']
    training = eligible_training_rows(f, j + 10, 2)
    assert not set([j, j + 1, j + 2, j - 2]).intersection(training)


def test_insufficient_mature_history_returns_no_predictions(snapshot, config):
    f = build_features(snapshot)
    parameters = {m: {'1': .0001, '2': .0001} for m in ('clinical_ridge', 'combined_ridge')}
    assert len(eligible_training_rows(f, 20, 2)) < config['forecast']['minimum_training_rows']
    assert predict_origin(f, 20, 2, parameters, config) == []


@pytest.fixture(scope='module')
def evaluations(config):
    predictions = pd.read_csv(ROOT / 'outputs/predictions.csv')
    return {score: paired_evaluate(predictions, config, {'test': 40, 'validation': 50}, score_mode=score)
            for score in ('raw', 'clipped')}


@pytest.mark.parametrize('column', ['anchor_from', 'target_from', 'issue_at'])
def test_csv_reimport_rejects_invalid_iso_dates(config, column):
    predictions = pd.read_csv(ROOT / 'outputs/predictions.csv')
    predictions.loc[0, column] = 'not-a-date'
    with pytest.raises(ValueError):
        paired_evaluate(predictions, config, {'test': 40, 'validation': 50})


def test_csv_reimport_normalizes_equivalent_issue_time_offsets(config):
    predictions = pd.read_csv(ROOT / 'outputs/predictions.csv')
    original = paired_evaluate(predictions, config, {'test': 40, 'validation': 50})
    # One model uses UTC ISO text; all other rows retain +08:00 CSV spelling.
    ix = predictions.model_id.eq('combined_ridge') & predictions.status.eq('ok')
    predictions.loc[ix, 'issue_at'] = pd.to_datetime(predictions.loc[ix, 'issue_at'], utc=True).map(lambda x: x.isoformat())
    normalized = paired_evaluate(predictions, config, {'test': 40, 'validation': 50})
    for before, after in zip(original, normalized):
        pd.testing.assert_frame_equal(before, after, check_exact=True)


@pytest.mark.parametrize('horizon', [1, 2])
@pytest.mark.parametrize('score', ['raw', 'clipped'])
@pytest.mark.parametrize('block_weeks', [2, 4, 8])
def test_twelve_scoring_states_share_rows_and_match_saved_exports(evaluations, horizon, score, block_weeks):
    metrics, pairs, intervals, _ = evaluations[score]
    prefix = 'raw_' if score == 'raw' else ''
    saved_metrics = pd.read_csv(ROOT / f'outputs/{prefix}metrics.csv')
    saved_pairs = pd.read_csv(ROOT / f'outputs/{prefix}paired_errors.csv')
    saved_ci = pd.read_csv(ROOT / f'outputs/{prefix}bootstrap_sensitivity.csv')
    predictions = pd.read_csv(ROOT / 'outputs/predictions.csv')
    for split, expected_n in [('validation', 50), ('test', 40)]:
        metric = metrics[(metrics.split == split) & (metrics.horizon == horizon)].set_index('model_id')
        saved = saved_metrics[(saved_metrics.split == split) & (saved_metrics.horizon == horizon)].set_index('model_id')
        assert set(metric.index) == {'persistence', 'clinical_ridge', 'combined_ridge'}
        assert metric.paired_set_id.nunique() == 1
        assert metric.n_origins.eq(expected_n).all()
        pp = pairs[(pairs.split == split) & (pairs.horizon == horizon)]
        saved_pp = saved_pairs[(saved_pairs.split == split) & (saved_pairs.horizon == horizon)]
        assert len(pp) == expected_n
        assert not pp.duplicated(['anchor_from', 'target_from']).any()
        np.testing.assert_array_equal(pd.to_datetime(pp.anchor_from), pd.to_datetime(saved_pp.anchor_from))
        np.testing.assert_array_equal(pd.to_datetime(pp.target_from), pd.to_datetime(saved_pp.target_from))
        assert pp.paired_set_id.eq(metric.paired_set_id.iloc[0]).all()
        np.testing.assert_allclose(pp.delta_error_pp, saved_pp.delta_error_pp, rtol=1e-10, atol=1e-12)
        one = predictions[(predictions.split == split) & (predictions.horizon == horizon)]
        signed = {}
        for model in metric.index:
            p = one[one.model_id == model].sort_values('anchor_from')
            assert len(p) == expected_n
            signed[model] = 100 * (p.observed.to_numpy() - p['raw_prediction' if score == 'raw' else 'prediction'].to_numpy())
            assert metric.loc[model, 'mae_pp'] == pytest.approx(np.abs(signed[model]).mean(), rel=1e-12)
            assert metric.loc[model, 'rmse_pp'] == pytest.approx(np.sqrt(np.mean(signed[model] ** 2)), rel=1e-12)
            for column in ['mae_pp', 'rmse_pp', 'raw_mae_pp', 'raw_rmse_pp', 'n_origins', 'n_clipped']:
                assert metric.loc[model, column] == pytest.approx(saved.loc[model, column], rel=1e-10, abs=1e-12)
        ci = intervals[(intervals.split == split) & (intervals.horizon == horizon) & (intervals.block_weeks == block_weeks)].iloc[0]
        saved_interval = saved_ci[(saved_ci.split == split) & (saved_ci.horizon == horizon) & (saved_ci.block_weeks == block_weeks)].iloc[0]
        assert ci.paired_set_id == metric.paired_set_id.iloc[0] == saved_interval.paired_set_id
        assert ci.n_origins == expected_n
        assert ci.confidence_level == .95
        assert ci.delta_mae_pp == pytest.approx(np.mean(np.abs(signed['clinical_ridge']) - np.abs(signed['combined_ridge'])), rel=1e-12)
        for column in ['delta_mae_pp', 'low', 'high', 'n_blocks', 'n_covered', 'n_uncovered']:
            assert ci[column] == pytest.approx(saved_interval[column], rel=1e-10, abs=1e-12)
        other_score = evaluations['clipped' if score == 'raw' else 'raw'][0]
        other = other_score[(other_score.split == split) & (other_score.horizon == horizon)]
        assert set(other.paired_set_id) == {ci.paired_set_id}

