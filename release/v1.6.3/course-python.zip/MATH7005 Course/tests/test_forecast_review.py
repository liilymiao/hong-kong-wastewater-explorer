"""Regression checks for the independent forecasting review.

These tests exercise availability and protocol boundaries absent from the
original nominal-date fixture. Small artificial arrays only test mathematics;
the forecasting regression continues to use the frozen government data.
"""
from __future__ import annotations

import copy
from pathlib import Path

import numpy as np
import pandas as pd
import pytest
import yaml

from src.backtest import (
    freeze_config, moving_block_interval, paired_evaluate, predict_origin,
    rolling_test, rolling_validate, validate_frozen,
)
from src.data import load_snapshot
from src.features import build_features, eligible_training_rows
from src.models import RidgeRegressor, Standardizer


ROOT = Path(__file__).resolve().parents[1]


@pytest.fixture(scope="module")
def review_data(tmp_path_factory):
    config = yaml.safe_load((ROOT / "config.yaml").read_text(encoding="utf-8"))
    snapshot = load_snapshot(ROOT / config["data"]["csv"], config)
    features = build_features(snapshot, config["forecast"]["lags"])
    candidates = rolling_validate(features, config)
    path = tmp_path_factory.mktemp("forecast_review") / "frozen.json"
    frozen = freeze_config(candidates, features, config, path)
    predictions = rolling_test(features, config, frozen)
    return config, snapshot, features, candidates, frozen, predictions


def test_override_time_governs_query_and_training_availability(review_data):
    config, _, features, _, frozen, _ = review_data
    t, h = 170, 2
    original_issue = features.iloc[t].issue_at
    early_issue = original_issue - pd.Timedelta(days=8)
    assert predict_origin(features, t, h, frozen["parameters"], config,
                          issue_at_override=early_issue) == []

    delayed = features.copy()
    delayed.loc[t, "feature_available_at"] = original_issue + pd.Timedelta(days=1)
    delayed.loc[120, "label_available_at"] = original_issue + pd.Timedelta(days=1)
    later_issue = original_issue + pd.Timedelta(days=2)
    assert predict_origin(delayed, t, h, frozen["parameters"], config) == []
    rows = predict_origin(delayed, t, h, frozen["parameters"], config,
                          issue_at_override=later_issue)
    assert len(rows) == 3
    assert all(row["issue_at"] == later_issue for row in rows)
    before = eligible_training_rows(delayed, t, h)
    after = eligible_training_rows(delayed, t, h, issue_at=later_issue)
    assert 120 - h not in before and 120 - h in after
    assert (delayed.iloc[after + h].label_available_at <= later_issue).all()
    assert (after + h <= t).all()


def test_unknown_arrival_propagates_to_every_dependent_anchor(review_data):
    config, snapshot, _, _, frozen, _ = review_data
    changed = snapshot.copy()
    j = 170
    changed.loc[j, "feature_available_at"] = pd.NaT
    features = build_features(changed, config["forecast"]["lags"])
    assert features.loc[j:j + 2, "feature_available_at"].isna().all()
    assert predict_origin(features, j, 2, frozen["parameters"], config) == []
    eligible = eligible_training_rows(features, j + 10, 2)
    assert not set(range(j, j + 3)).intersection(eligible)
    with pytest.raises(ValueError, match="timezone-aware"):
        predict_origin(features, j + 3, 2, frozen["parameters"], config,
                       issue_at_override=pd.Timestamp("2026-08-01"))


def test_freeze_checks_all_used_validation_targets_not_only_last_week(review_data, tmp_path):
    config, _, features, candidates, frozen, _ = review_data
    changed = features.copy()
    # W51 is scored by validation forecasts, but follows every validation
    # origin. Delaying it changes no forecast training rows, only the time at
    # which its validation error could legitimately select a parameter.
    j = int(changed.index[(changed.Year == 2025) & (changed.Week == 51)][0])
    changed.loc[j, "label_available_at"] = pd.Timestamp(frozen["first_test_issue_at"]) + pd.Timedelta(days=1)
    path = tmp_path / "late.json"
    with pytest.raises(ValueError, match="before first test"):
        freeze_config(candidates, changed, config, path)
    assert not path.exists()
    changed.loc[j, "label_available_at"] = pd.NaT
    with pytest.raises(ValueError, match="Unknown label_available_at"):
        freeze_config(candidates, changed, config, tmp_path / "unknown.json")


def test_read_only_frozen_validation_protects_source_and_development(review_data):
    config, _, features, _, frozen, _ = review_data
    assert validate_frozen(features, config, frozen) is None
    changed_config = copy.deepcopy(config)
    changed_config["forecast"]["lags"] = [0, 1]
    with pytest.raises(ValueError, match="Config has changed"):
        validate_frozen(features, changed_config, frozen)
    changed_source = features.copy()
    changed_source["source_version"] = "another-snapshot"
    with pytest.raises(ValueError, match="Source version"):
        rolling_test(changed_source, config, frozen)
    changed_development = features.copy()
    changed_development.loc[110, "p_lag_0"] += .01
    with pytest.raises(ValueError, match="Development evidence"):
        validate_frozen(changed_development, config, frozen)
    # Future/test observations are deliberately outside the tuning fingerprint.
    changed_test = features.copy()
    changed_test.loc[170, "SARSCoV2_proportion"] += .01
    assert validate_frozen(changed_test, config, frozen) is None
    changed_decision = copy.deepcopy(frozen)
    changed_decision["parameters"]["clinical_ridge"]["2"] = 1.0
    with pytest.raises(ValueError, match="decision contents"):
        validate_frozen(features, config, changed_decision)


def test_freeze_records_both_evidence_clocks_and_is_repeatable(review_data, tmp_path):
    config, _, features, candidates, frozen, _ = review_data
    basis = frozen["development_basis"]
    expected_input = features.iloc[basis["feature_rows"]].feature_available_at.max()
    expected_label = features.iloc[basis["label_rows"]].label_available_at.max()
    assert pd.Timestamp(frozen["validation_last_input_available_at"]) == expected_input
    assert pd.Timestamp(frozen["validation_last_label_available_at"]) == expected_label
    assert pd.Timestamp(frozen["frozen_available_at"]) == max(expected_input, expected_label)
    path = tmp_path / "frozen.json"
    assert freeze_config(candidates, features, config, path) == frozen
    before = path.read_bytes()
    assert freeze_config(candidates, features, config, path) == frozen
    assert path.read_bytes() == before


def test_validation_rejects_duplicate_or_unpaired_candidates(review_data, tmp_path):
    config, _, features, candidates, _, _ = review_data
    ridge = candidates[candidates.model_id == "clinical_ridge"].iloc[[0]]
    duplicate = pd.concat([candidates, ridge], ignore_index=True)
    with pytest.raises(ValueError, match="Duplicate validation"):
        freeze_config(duplicate, features, config, tmp_path / "duplicate.json")
    dropped = candidates.drop(ridge.index)
    with pytest.raises(ValueError, match="share origins"):
        freeze_config(dropped, features, config, tmp_path / "unpaired.json")


def test_short_gap_segment_cannot_silently_disappear_from_interval():
    result = moving_block_interval(
        [0., 0., 0., 0., 100.],
        pd.to_datetime(["2026-01-04", "2026-01-11", "2026-01-18", "2026-01-25", "2026-02-08"]),
        block=4,
    )
    assert result["status"] == "incomplete_block_coverage"
    assert result["n_origins"] == 5 and result["n_covered"] == 4
    assert result["n_uncovered"] == 1 and result["n_blocks"] == 1
    assert np.isnan(result["low"]) and np.isnan(result["high"])


def test_confidence_level_matches_independent_block_draws():
    values = np.array([1., -2., 3., 4., -1., 6., 2., 8.])
    dates = pd.date_range("2026-01-04", periods=8, freq="7D")
    rng = np.random.default_rng(42)
    blocks = [values[i:i + 4] for i in range(5)]
    draws = rng.integers(5, size=(500, 2))
    means = np.array([np.concatenate([blocks[j] for j in draw]).mean() for draw in draws])
    for confidence in (.8, .95):
        actual = moving_block_interval(values, dates, block=4, repeats=500, confidence_level=confidence)
        expected = np.quantile(means, [(1 - confidence) / 2, (1 + confidence) / 2])
        assert actual["status"] == "ok" and actual["n_covered"] == 8
        assert actual["confidence_level"] == confidence
        np.testing.assert_allclose([actual["low"], actual["high"]], expected)


@pytest.mark.parametrize("kwargs", [
    {"block": 0}, {"block": 1.5}, {"repeats": 1}, {"seed": -1},
    {"confidence_level": 0}, {"confidence_level": 1}, {"confidence_level": np.nan},
])
def test_bootstrap_rejects_invalid_parameters(kwargs):
    with pytest.raises(ValueError):
        moving_block_interval([1., 2.], pd.date_range("2026-01-04", periods=2, freq="7D"), **kwargs)


def test_bootstrap_rejects_duplicate_dates_and_nonfinite_errors():
    with pytest.raises(ValueError, match="unique"):
        moving_block_interval([1., 2.], ["2026-01-04", "2026-01-04"], block=1)
    with pytest.raises(ValueError, match="Finite"):
        moving_block_interval([1., np.inf], ["2026-01-04", "2026-01-11"], block=1)


def test_raw_and_clipped_scores_use_same_pairs_but_distinct_losses(review_data):
    config, _, _, _, _, predictions = review_data
    clipped, _, clipped_ci, _ = paired_evaluate(predictions, config, {"test": 40})
    raw, _, raw_ci, _ = paired_evaluate(predictions, config, {"test": 40}, score_mode="raw")
    assert clipped.score_mode.eq("clipped").all() and raw.score_mode.eq("raw").all()
    assert clipped.paired_set_id.tolist() == raw.paired_set_id.tolist()
    for row in raw.itertuples(index=False):
        records = predictions[(predictions.horizon == row.horizon) & (predictions.model_id == row.model_id)]
        errors = 100 * (records.observed.to_numpy() - records.raw_prediction.to_numpy())
        assert row.mae_pp == pytest.approx(np.abs(errors).mean())
        assert row.rmse_pp == pytest.approx(np.sqrt(np.mean(errors ** 2)))
        assert row.raw_mae_pp == pytest.approx(row.mae_pp)
    clipped_h2 = clipped[(clipped.horizon == 2) & (clipped.model_id == "combined_ridge")].iloc[0]
    raw_h2 = raw[(raw.horizon == 2) & (raw.model_id == "combined_ridge")].iloc[0]
    assert clipped_h2.mae_pp == pytest.approx(.7001810329557117, rel=1e-11)
    assert clipped_h2.delta_mae_pp == pytest.approx(.304721903921267, rel=1e-11)
    assert raw_h2.mae_pp == pytest.approx(.8902327608302562, rel=1e-11)
    assert raw_h2.delta_ci_low_pp < 0 < raw_h2.delta_ci_high_pp
    assert raw_ci.score_mode.eq("raw").all() and clipped_ci.score_mode.eq("clipped").all()


def test_pair_evaluation_passes_configured_confidence_and_recomputes_errors(review_data):
    config, _, _, _, _, predictions = review_data
    changed = copy.deepcopy(config)
    changed["evaluation"]["bootstrap_confidence_level"] = .8
    altered_records = predictions.copy()
    # Derived cache columns are not an independent source of truth.
    altered_records["abs_error_pp"] = 999.0
    altered_records["squared_error_pp2"] = 999.0
    actual, _, intervals, _ = paired_evaluate(altered_records, changed)
    expected, _, _, _ = paired_evaluate(predictions, config)
    np.testing.assert_allclose(actual.mae_pp, expected.mae_pp)
    assert intervals.confidence_level.eq(.8).all()
    a = actual[(actual.horizon == 2) & (actual.model_id == "combined_ridge")].iloc[0]
    b = expected[(expected.horizon == 2) & (expected.model_id == "combined_ridge")].iloc[0]
    assert a.delta_ci_low_pp > b.delta_ci_low_pp
    assert a.delta_ci_high_pp < b.delta_ci_high_pp


def test_pair_evaluation_rejects_duplicate_nonfinite_and_unfair_rows(review_data):
    config, _, _, _, _, predictions = review_data
    duplicate = pd.concat([predictions, predictions.iloc[[0]]], ignore_index=True)
    with pytest.raises(ValueError, match="Duplicate prediction"):
        paired_evaluate(duplicate, config)
    nonfinite = predictions.copy()
    nonfinite.loc[0, "raw_prediction"] = np.inf
    with pytest.raises(ValueError, match="finite"):
        paired_evaluate(nonfinite, config)
    unfair = predictions.copy()
    index = unfair.index[unfair.model_id == "combined_ridge"][0]
    unfair.loc[index, "train_anchor_keys"] = "different-training-data"
    with pytest.raises(ValueError, match="training rows"):
        paired_evaluate(unfair, config)


def test_model_boundaries_reject_nonfinite_parameters_and_queries():
    with pytest.raises(ValueError, match="Finite nonnegative"):
        RidgeRegressor(np.nan)
    with pytest.raises(ValueError, match="Nonempty"):
        Standardizer().fit(np.empty((0, 2)))
    model = RidgeRegressor(.1).fit([[1.], [2.], [3.]], [.1, .2, .3])
    with pytest.raises(ValueError, match="Finite X"):
        model.predict([[np.inf]])
