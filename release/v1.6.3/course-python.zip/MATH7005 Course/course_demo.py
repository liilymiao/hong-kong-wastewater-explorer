"""Course demonstration entry: python -m streamlit run course_demo.py."""
from app import main

if __name__ == "__main__":
    main(course_default=True)
