"""Detect incomplete or mixed generations before displaying analytical outputs.

Hashes bind the source, analysis configuration, numerical code, cleaned data and
saved results. These checks establish consistency; model validity is tested
separately. The manifest is written only after a successful export.
"""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import importlib.metadata
import platform


class ArtifactError(ValueError):
    pass


def digest_file(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def digest_config(config):
    return hashlib.sha256(json.dumps(config, sort_keys=True, ensure_ascii=False).encode()).hexdigest()


def atomic_json(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + '.tmp')
    temporary.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    os.replace(temporary, path)


def write_run_state(root, config, stage, status, run_id, error=None):
    result = {'stage': stage, 'status': status, 'run_id': run_id,
              'updated_at_utc': datetime.now(timezone.utc).isoformat()}
    if error is not None:
        result['error'] = str(error)
    atomic_json(Path(root) / config['output']['directory'] / 'run_state.json', result)
    return result


REQUIRED_RESULTS = (
    'predictions.csv', 'metrics.csv', 'paired_errors.csv', 'bootstrap_sensitivity.csv',
    'stage_metrics.csv', 'raw_metrics.csv', 'raw_paired_errors.csv',
    'raw_bootstrap_sensitivity.csv', 'raw_stage_metrics.csv',
    'origins.csv', 'coverage.csv', 'frozen_config.json', 'patterns.csv',
    'pattern_config.json', 'pattern_centers.csv', 'pattern_neighbors.csv',
    'pattern_sensitivity.csv', 'pattern_sensitivity_summary.csv',
    'pattern_selection.csv', 'pattern_selection.json',
    'validation_candidates.csv', 'validation_predictions.csv', 'validation_scores.csv',
    'shared_lambda_metrics.csv', 'shared_lambda_predictions.csv', 'data_quality.json',
    'shared_lambda_paired_errors.csv', 'shared_lambda_bootstrap_sensitivity.csv',
    'shared_lambda_stage_metrics.csv',
    'delay_sensitivity.csv', 'config.json', 'runtime.json', '项目报告.md', '项目报告.html',
    'stage_validate.json', 'stage_test.json',
)
CODE_FILES = ('src/data.py', 'src/features.py', 'src/models.py', 'src/backtest.py',
              'src/patterns.py', 'src/pattern_pipeline.py', 'src/pipeline.py',
              'src/configuration.py', 'src/outputs.py', 'src/artifacts.py', 'src/course_trace.py',
              'requirements.lock.txt', 'data/audit_data.py')

STAGE_RESULTS = {
    'validate': ('validation_candidates.csv', 'validation_predictions.csv',
                 'validation_scores.csv', 'frozen_config.json', 'pattern_config.json'),
    'test': tuple(name for name in REQUIRED_RESULTS if name not in
                  ('config.json', 'runtime.json', '项目报告.md', '项目报告.html', 'stage_test.json')),
}


def _records(root, paths):
    result = {}
    for path in paths:
        path = Path(path)
        if not path.resolve().is_relative_to(root):
            raise ArtifactError('分析记录包含项目目录外的路径。')
        if not path.is_file():
            raise ArtifactError('缺少分析文件：' + str(path.relative_to(root)))
        result[str(path.relative_to(root))] = {
            'sha256': digest_file(path), 'bytes': path.stat().st_size}
    return result


def _check_records(root, records, expected):
    if not isinstance(records, dict) or not set(expected).issubset(records):
        raise ArtifactError('分析产物记录缺少必需文件。')
    changed = []
    for name, record in records.items():
        if not isinstance(name, str) or not isinstance(record, dict):
            raise ArtifactError('分析产物记录的文件格式不受支持。')
        path = (root / name).resolve()
        if not path.is_relative_to(root):
            raise ArtifactError('分析产物记录包含项目目录外的路径。')
        if (not path.is_file() or path.stat().st_size != record.get('bytes')
                or digest_file(path) != record.get('sha256')):
            changed.append(name)
    if changed:
        raise ArtifactError('部分文件与完整运行结果不一致：' + '、'.join(changed[:4]))


def _stage_paths(root, config, stage):
    out = root / config['output']['directory']
    return ([root / config['data']['csv'], root / config['data']['date_overrides'],
             root / 'data/source_catalog.json',
             root / 'data/processed/clean.csv', root / 'data/processed/features.csv']
            + [root / name for name in CODE_FILES]
            + [out / name for name in STAGE_RESULTS[stage]])


def write_stage_receipt(root, config, stage):
    """Bind stage outputs to their actual inputs before a later stage can use them."""
    root = Path(root).resolve()
    receipt = {'schema_version': 1, 'stage': stage,
               'config_sha256': digest_config(config),
               'runtime': {'python': platform.python_version(), 'platform': platform.platform(),
                           'dependencies': {name: importlib.metadata.version(name)
                                            for name in ('numpy', 'pandas', 'pyyaml', 'plotly', 'streamlit')}},
               'files': _records(root, _stage_paths(root, config, stage))}
    atomic_json(root / config['output']['directory'] / f'stage_{stage}.json', receipt)
    return receipt


def verify_stage_receipt(root, config, stage):
    root = Path(root).resolve()
    path = root / config['output']['directory'] / f'stage_{stage}.json'
    try:
        receipt = json.loads(path.read_text(encoding='utf-8'))
    except (OSError, ValueError) as exc:
        raise ArtifactError(f'缺少 {stage} 阶段的完整记录，请运行 --stage all。') from exc
    if not isinstance(receipt, dict) or receipt.get('schema_version') != 1 or receipt.get('stage') != stage:
        raise ArtifactError('阶段记录格式不受支持，请运行 --stage all。')
    if receipt.get('config_sha256') != digest_config(config):
        raise ArtifactError('阶段配置已变化，请使用新输出目录重新分析。')
    expected = [str(path.relative_to(root)) for path in _stage_paths(root, config, stage)]
    _check_records(root, receipt.get('files'), expected)
    return receipt


def seal_artifacts(root, config, run_id):
    root = Path(root).resolve()
    out = root / config['output']['directory']
    # Export must not turn stale or edited model results into a new valid bundle.
    verify_stage_receipt(root, config, 'test')
    paths = [root / config['data']['csv'], root / config['data']['date_overrides'],
             root / 'data/source_catalog.json',
             root / 'data/processed/clean.csv', root / 'data/processed/features.csv']
    paths += [out / name for name in REQUIRED_RESULTS]
    paths += [root / name for name in CODE_FILES]
    missing = [str(path.relative_to(root)) for path in paths if not path.is_file()]
    if missing:
        raise ArtifactError('分析产物不完整：' + '、'.join(missing))
    metadata = {'schema_version': 1, 'stage': 'complete', 'run_id': run_id,
                'generated_at_utc': datetime.now(timezone.utc).isoformat(),
                'config_sha256': digest_config(config),
                'source_sha256': digest_file(root / config['data']['csv']),
                'files': {str(path.relative_to(root)): {'sha256': digest_file(path),
                          'bytes': path.stat().st_size} for path in paths}}
    atomic_json(out / 'artifact_manifest.json', metadata)
    write_run_state(root, config, 'export', 'complete', run_id)
    return metadata


def verify_artifacts(root, config):
    root = Path(root).resolve()
    out = root / config['output']['directory']
    try:
        metadata = json.loads((out / 'artifact_manifest.json').read_text(encoding='utf-8'))
        state = json.loads((out / 'run_state.json').read_text(encoding='utf-8'))
    except (OSError, ValueError) as exc:
        raise ArtifactError('缺少完整的分析产物记录，请重新生成全部结果。') from exc
    if not isinstance(metadata, dict) or metadata.get('schema_version') != 1 or metadata.get('stage') != 'complete':
        raise ArtifactError('分析产物记录的格式不受支持。')
    if not isinstance(state, dict) or state.get('status') != 'complete' or state.get('run_id') != metadata.get('run_id'):
        raise ArtifactError('分析尚未完整完成，当前结果暂不可用。')
    if metadata.get('config_sha256') != digest_config(config):
        raise ArtifactError('当前配置与已生成结果不一致。')
    raw = root / config['data']['csv']
    if not raw.is_file() or digest_file(raw) != metadata.get('source_sha256'):
        raise ArtifactError('当前原始数据与已生成结果不一致。')
    expected = [config['data']['csv'], config['data']['date_overrides'], 'data/source_catalog.json',
                'data/processed/clean.csv', 'data/processed/features.csv']
    expected += [str(Path(config['output']['directory']) / name) for name in REQUIRED_RESULTS]
    expected += list(CODE_FILES)
    _check_records(root, metadata.get('files'), expected)
    return metadata
