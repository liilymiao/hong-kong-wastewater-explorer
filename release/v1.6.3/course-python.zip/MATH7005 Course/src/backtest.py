"""Expanding-window forecasting with mature labels and paired evaluation."""
import hashlib
import json
from pathlib import Path
import numpy as np
import pandas as pd
from .features import feature_columns,eligible_training_rows,split_indices,target_dates,_issue_timestamp,_availability_times
from .models import RidgeRegressor

MODEL_IDS=('persistence','clinical_ridge','combined_ridge')

def config_digest(config):
    return hashlib.sha256(json.dumps(config,sort_keys=True,ensure_ascii=False).encode()).hexdigest()

def _horizons(config):
    result=(config['forecast']['primary_horizon'],config['forecast']['secondary_horizon'])
    if any(isinstance(h,(bool,np.bool_)) or not isinstance(h,(int,np.integer)) or h<1 for h in result):
        raise ValueError('Configured horizons must be positive integers')
    if len(set(result))!=len(result):raise ValueError('Primary and secondary horizons must differ')
    return sorted(result)

def predict_origin(features,t,horizon,parameters,config,split='test',run_id='frozen-v1',issue_at_override=None):
    """Returns all three predictions plus their training states, without retuning."""
    a=features.iloc[t];h=horizon
    prediction_issue=_issue_timestamp(issue_at_override if issue_at_override is not None else (pd.Timestamp.now(tz='Asia/Hong_Kong') if split=='future' else a.issue_at))
    if not a.paired_complete or pd.isna(a.feature_available_at) or _issue_timestamp(a.feature_available_at)>prediction_issue:return []
    tr=eligible_training_rows(features,t,h,issue_at=prediction_issue)
    if len(tr)<config['forecast']['minimum_training_rows']:return []
    assert (tr+h<=t).all()
    c,cw=feature_columns(config['forecast']['lags'])
    y=features.iloc[tr+h].SARSCoV2_proportion.to_numpy()
    observed=float(features.iloc[t+h].SARSCoV2_proportion) if t+h<len(features) else np.nan
    rows=[]
    for model in MODEL_IDS:
        cols=c if model=='clinical_ridge' else cw
        state={};alpha=np.nan
        if model=='persistence':raw=float(a.SARSCoV2_proportion)
        else:
            alpha=float(parameters[model][str(h)])
            fitted=RidgeRegressor(alpha).fit(features.iloc[tr][cols].to_numpy(),y)
            raw=float(fitted.predict(features.iloc[[t]][cols].to_numpy())[0]);state=fitted.state()
        if not np.isfinite(raw):raise ValueError('Model produced a non-finite prediction')
        pred=float(np.clip(raw,*config['forecast']['output_clip']))
        err=100*abs(observed-pred) if np.isfinite(observed) else np.nan
        rows.append({'run_id':run_id,'backtest_mode':'frozen_snapshot_projection' if split=='future' else 'frozen_retrospective',
            'source_version':a.source_version,'evaluation_vintage':a.source_version,
            'issue_at':prediction_issue,
            'nominal_issue_at':a.issue_at,'anchor_year':int(a.Year),'anchor_week':int(a.Week),
            'anchor_from':a.From,'anchor_to':a.To_corrected,**target_dates(features,t,h),
            'horizon':h,'model_id':model,'feature_set':'last_clinical' if model=='persistence' else '|'.join(cols),
            'n_train':len(tr),'lambda':alpha,'raw_prediction':raw,'prediction':pred,'observed':observed,
            'abs_error_pp':err,'squared_error_pp2':err**2,'raw_abs_error_pp':100*abs(observed-raw) if np.isfinite(observed) else np.nan,
            'raw_squared_error_pp2':(100*(observed-raw))**2 if np.isfinite(observed) else np.nan,
            'was_clipped':raw!=pred,'status':'ok' if np.isfinite(observed) else 'awaiting_observation',
            'split':split,'stage_label':a.stage_label,
            'train_anchor_keys':'|'.join(features.iloc[tr].week_key),
            'train_last_target':features.iloc[tr[-1]+h].week_key,
            'train_last_target_available_at':features.iloc[tr[-1]+h].label_available_at,
            'model_state':json.dumps(state,ensure_ascii=False,sort_keys=True),
            'query_features':json.dumps(features.iloc[t][cols].tolist()),
            'interpretation':'开发/验证期回放，选参使用完整验证期' if split=='validation' else ('冻结快照末端未评分预测' if split=='future' else '测试前固定配置的冻结版本回顾性评估')})
    return rows

def rolling_validate(features,config):
    rows=[]
    for h in _horizons(config):
        for alpha in config['models']['ridge_lambdas']:
            pars={m:{str(h):alpha} for m in MODEL_IDS[1:]}
            for t in split_indices(features,config,'validation'):
                results=predict_origin(features,int(t),h,pars,config,'validation')
                # Store the persistence baseline once, while retaining all Ridge candidates.
                rows.extend(r for r in results if r['model_id']!='persistence' or alpha==config['models']['ridge_lambdas'][0])
    return pd.DataFrame(rows)

def choose_lambda(frame):
    if frame.empty or not np.isfinite(frame[['lambda','abs_error_pp']].to_numpy(dtype=float)).all():
        raise ValueError('Lambda selection requires finite scored validation rows')
    scores=frame.groupby('lambda').abs_error_pp.mean()
    best=scores.min()
    return float(scores.index[scores<=best+0.000001].max())

def _source_version(features):
    if features.source_version.isna().any() or features.source_version.nunique()!=1:
        raise ValueError('A single known source_version is required for the frozen analysis')
    return str(features.iloc[0].source_version)

def _canonical_value(value):
    if pd.isna(value):return None
    if isinstance(value,(pd.Timestamp,np.datetime64)):
        value=pd.Timestamp(value)
        return value.tz_convert('UTC').isoformat() if value.tzinfo is not None else value.isoformat()
    if isinstance(value,(bool,np.bool_)):return bool(value)
    if isinstance(value,(int,np.integer)):return int(value)
    if isinstance(value,(float,np.floating)):
        # Avoid platform-level last-bit differences in log1p invalidating a
        # portable freeze; source bytes remain protected by their exact SHA256.
        return format(float(value),'.15g')
    return str(value)

def _basis_digest(features,basis,config):
    _,joint=feature_columns(config['forecast']['lags'])
    feature_cols=['week_key','From','To_corrected','issue_at','feature_available_at','paired_complete']+joint
    label_cols=['week_key','From','label_available_at','SARSCoV2_proportion']
    evidence={}
    for kind,columns in [('feature_rows',feature_cols),('label_rows',label_cols)]:
        indices=basis[kind]
        if not indices or any(isinstance(i,bool) or not isinstance(i,int) or not 0<=i<len(features) for i in indices):
            raise ValueError('Invalid frozen development row indices')
        if indices!=sorted(set(indices)):raise ValueError('Frozen development rows must be unique and sorted')
        evidence[kind]=[[i]+[_canonical_value(v) for v in features.iloc[i][columns]] for i in indices]
    return config_digest(evidence)

def _latest_known_time(features,rows,column):
    times=_availability_times(features.iloc[rows][column])
    if times.isna().any():raise ValueError(f'Unknown {column} in validation development evidence')
    return times.max().tz_convert('Asia/Hong_Kong')

def _freeze_digest(frozen):
    return config_digest({k:v for k,v in frozen.items() if k!='freeze_sha256'})

def _validation_evidence(candidates,features,config):
    """Check candidate comparability and recover every input/label used to tune."""
    required=['split','horizon','model_id','lambda','anchor_from','target_from','issue_at',
              'source_version','train_anchor_keys','observed','prediction','abs_error_pp','status']
    if any(c not in candidates for c in required):raise ValueError('Incomplete validation candidate schema')
    if not candidates.split.eq('validation').all():raise ValueError('Only validation rows may select parameters')
    source=_source_version(features)
    if not candidates.source_version.eq(source).all():raise ValueError('Validation candidate source_version mismatch')
    scored=candidates[candidates.status.eq('ok') & candidates.model_id.isin(MODEL_IDS[1:])].copy()
    if scored.empty:raise ValueError('No scored validation candidates')
    if not np.isfinite(scored[['lambda','observed','prediction','abs_error_pp']].to_numpy(dtype=float)).all():
        raise ValueError('Non-finite validation score')
    calculated=100*np.abs(scored.observed.to_numpy()-scored.prediction.to_numpy())
    if not np.allclose(calculated,scored.abs_error_pp.to_numpy(),rtol=1e-12,atol=1e-12):
        raise ValueError('Validation errors disagree with observed and predicted values')
    scored['anchor_from']=pd.to_datetime(scored.anchor_from)
    scored['target_from']=pd.to_datetime(scored.target_from)
    scored['issue_at']=pd.to_datetime(scored.issue_at,utc=True)
    candidate_key=['horizon','model_id','lambda','anchor_from','target_from','issue_at']
    if scored.duplicated(candidate_key).any():raise ValueError('Duplicate validation candidate key')
    expected_h=_horizons(config)
    if set(scored.horizon)!=set(expected_h):raise ValueError('Validation horizon mismatch')
    expected_lambdas=set(map(float,config['models']['ridge_lambdas']))
    for h in expected_h:
        reference=None
        for model in MODEL_IDS[1:]:
            frame=scored[(scored.horizon==h)&(scored.model_id==model)]
            if set(frame['lambda'])!=expected_lambdas:raise ValueError('Unequal validation lambda budgets')
            for alpha in sorted(expected_lambdas):
                rows=frame[frame['lambda']==alpha].sort_values('anchor_from')
                keys=list(rows[['anchor_from','target_from','issue_at','train_anchor_keys']].itertuples(index=False,name=None))
                if reference is None:reference=keys
                elif keys!=reference:raise ValueError('Validation models must share origins and training rows')
    if features.From.duplicated().any() or features.week_key.duplicated().any():raise ValueError('Duplicate development week')
    from_to_index={pd.Timestamp(v):i for i,v in enumerate(features.From)}
    allowed=set(split_indices(features,config,'validation').tolist())
    feature_rows=set();label_rows=set()
    origins=scored[['anchor_from','target_from','horizon','issue_at','train_anchor_keys']].drop_duplicates()
    for row in origins.itertuples(index=False):
        t=from_to_index.get(row.anchor_from)
        if t is None or t not in allowed:raise ValueError('Candidate is outside configured validation origins')
        h=int(row.horizon)
        if t+h>=len(features) or pd.Timestamp(features.iloc[t+h].From)!=row.target_from:
            raise ValueError('Candidate target does not match its horizon')
        issue=_issue_timestamp(row.issue_at)
        if issue!=_issue_timestamp(features.iloc[t].issue_at):raise ValueError('Candidate issue time mismatch')
        query_time=features.iloc[t].feature_available_at
        if pd.isna(query_time) or _issue_timestamp(query_time)>issue:raise ValueError('Unavailable validation query features')
        tr=eligible_training_rows(features,t,h,issue_at=issue)
        if '|'.join(features.iloc[tr].week_key)!=row.train_anchor_keys:
            raise ValueError('Candidate training rows disagree with development evidence')
        feature_rows.update(tr.tolist());feature_rows.add(t)
        label_rows.update((tr+h).tolist());label_rows.add(t+h)
    basis={'feature_rows':sorted(feature_rows),'label_rows':sorted(label_rows),
           'numeric_canonicalization':'15 significant decimal digits'}
    basis['sha256']=_basis_digest(features,basis,config)
    return scored,basis

def freeze_config(candidates,features,config,path):
    path=Path(path)
    scored,basis=_validation_evidence(candidates,features,config)
    selected={m:{} for m in MODEL_IDS[1:]};shared={}
    for h in _horizons(config):
        for m in MODEL_IDS[1:]:
            f=scored[(scored.horizon==h)&(scored.model_id==m)]
            selected[m][str(h)]=choose_lambda(f)
        f=scored[scored.horizon==h]
        # Equality of candidate origin sets above makes pooled MAE equal to the
        # equally weighted mean of the two model MAEs for each lambda.
        shared[str(h)]=choose_lambda(f)
    label_cutoff=_latest_known_time(features,basis['label_rows'],'label_available_at')
    input_cutoff=_latest_known_time(features,basis['feature_rows'],'feature_available_at')
    cutoff=max(label_cutoff,input_cutoff)
    test=split_indices(features,config,'test')
    if not len(test):raise ValueError('No configured test origins')
    first_test=min(_issue_timestamp(v) for v in features.iloc[test].issue_at)
    if not cutoff<first_test:raise ValueError('Validation development evidence is not available before first test')
    frozen={'schema_version':2,'parameters':selected,'shared_parameters':{m:shared.copy() for m in MODEL_IDS[1:]},
        'selection_metric':'validation clipped MAE in percentage points',
        'tie_tolerance_pp':0.000001,'tie_rule':'larger lambda',
        'config_sha256':config_digest(config),'source_version':_source_version(features),
        'development_basis':basis,
        'validation_last_label_available_at':str(label_cutoff),
        'validation_last_input_available_at':str(input_cutoff),'first_test_issue_at':str(first_test),
        'frozen_available_at':str(cutoff),'stage_rule':'clinical p_t minus p_t-2; positive=上升, negative=下降, zero=持平',
        'time_claim':'Configuration is selected retrospectively. frozen_available_at is the latest nominal availability of all development evidence used for selection, not the actual execution or deployment date.'}
    frozen['freeze_sha256']=_freeze_digest(frozen)
    if path.exists():
        old=json.loads(path.read_text(encoding='utf-8'))
        if old!=frozen:raise ValueError('Existing frozen configuration differs. Use a new output folder for a changed analysis.')
    path.write_text(json.dumps(frozen,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    return frozen

def validate_frozen(features,config,frozen):
    """Read-only protocol/source/development check, safe to call before any writes."""
    required={'schema_version','config_sha256','source_version','freeze_sha256','development_basis',
              'frozen_available_at','first_test_issue_at','parameters','shared_parameters'}
    if not isinstance(frozen,dict) or not required.issubset(frozen):raise ValueError('Incomplete frozen configuration')
    if frozen.get('schema_version')!=2:raise ValueError('Unsupported frozen schema; regenerate validation in a new output folder')
    if frozen.get('config_sha256')!=config_digest(config):raise ValueError('Config has changed after freeze')
    if frozen.get('source_version')!=_source_version(features):raise ValueError('Source version has changed after freeze')
    if frozen.get('freeze_sha256')!=_freeze_digest(frozen):raise ValueError('Frozen decision contents have changed')
    basis=frozen.get('development_basis')
    if not isinstance(basis,dict) or not {'feature_rows','label_rows','sha256'}.issubset(basis):
        raise ValueError('Incomplete frozen development evidence')
    if basis.get('sha256')!=_basis_digest(features,basis,config):
        raise ValueError('Development evidence has changed after freeze')
    label_cutoff=_latest_known_time(features,basis['label_rows'],'label_available_at')
    input_cutoff=_latest_known_time(features,basis['feature_rows'],'feature_available_at')
    cutoff=max(label_cutoff,input_cutoff)
    if cutoff!=_issue_timestamp(frozen['frozen_available_at']):raise ValueError('Frozen evidence cutoff mismatch')
    test=split_indices(features,config,'test')
    if not len(test):raise ValueError('No configured test origins')
    first_test=min(_issue_timestamp(v) for v in features.iloc[test].issue_at)
    if first_test!=_issue_timestamp(frozen['first_test_issue_at']) or not cutoff<first_test:
        raise ValueError('Validation evidence is not mature before the configured test origins')
    for key in ('parameters','shared_parameters'):
        for model in MODEL_IDS[1:]:
            for h in _horizons(config):
                try:alpha=float(frozen[key][model][str(h)])
                except (KeyError,TypeError,ValueError) as exc:raise ValueError('Incomplete frozen parameters') from exc
                if not np.isfinite(alpha) or alpha not in config['models']['ridge_lambdas']:
                    raise ValueError('Frozen lambda is not in the prespecified candidate set')
    return None

def selected_validation(candidates,frozen):
    mask=candidates.model_id=='persistence'
    for m,hs in frozen['parameters'].items():
        for h,alpha in hs.items():mask|=(candidates.model_id==m)&(candidates.horizon==int(h))&(candidates['lambda']==alpha)
    return candidates[mask].copy()

def rolling_test(features,config,frozen,split='test',shared=False):
    validate_frozen(features,config,frozen)
    if split not in ('test','future'):raise ValueError('Unknown rolling test mode')
    pars=frozen['shared_parameters'] if shared else frozen['parameters']
    indices=split_indices(features,config,'test') if split=='test' else [len(features)-1]
    rows=[]
    future_issue=pd.Timestamp.now(tz='Asia/Hong_Kong') if split=='future' else None
    for t in indices:
        for h in _horizons(config):rows.extend(predict_origin(features,int(t),h,pars,config,split,issue_at_override=future_issue))
    return pd.DataFrame(rows)

def moving_block_interval(values,dates,block=4,repeats=2000,seed=42,confidence_level=.95):
    """Bootstrap complete weekly blocks only when every scored week is covered.

    A short isolated segment cannot silently disappear from resampling while
    remaining in the point estimate. In that case the interval is unavailable.
    """
    for name,value,minimum in [('block',block,1),('repeats',repeats,2)]:
        if isinstance(value,(bool,np.bool_)) or not isinstance(value,(int,np.integer)) or value<minimum:
            raise ValueError(f'{name} must be an integer >= {minimum}')
    if seed is not None and (isinstance(seed,(bool,np.bool_)) or not isinstance(seed,(int,np.integer)) or seed<0):
        raise ValueError('seed must be a nonnegative integer or None')
    if not isinstance(confidence_level,(int,float,np.number)) or not np.isfinite(confidence_level) or not 0<confidence_level<1:
        raise ValueError('confidence_level must be finite and between zero and one')
    v=np.asarray(values,dtype=float)
    d=pd.DatetimeIndex(pd.to_datetime(dates,errors='raise'))
    if v.ndim!=1 or len(v)!=len(d) or not np.isfinite(v).all():raise ValueError('Finite aligned one-dimensional errors required')
    if d.hasnans or d.has_duplicates:raise ValueError('Bootstrap dates must be known and unique')
    order=np.argsort(d);d=d[order];v=v[order]
    blocks=[];covered=np.zeros(len(v),dtype=bool)
    for i in range(len(v)-block+1):
        if all(d[j+1]-d[j]==pd.Timedelta(days=7) for j in range(i,i+block-1)):
            blocks.append(v[i:i+block]);covered[i:i+block]=True
    result={'low':np.nan,'high':np.nan,'n_blocks':len(blocks),'n_origins':len(v),
            'block_weeks':int(block),'confidence_level':float(confidence_level),
            'n_covered':int(covered.sum()),'n_uncovered':int((~covered).sum()),'status':'ok'}
    if not len(v):result['status']='no_observations';return result
    if not blocks:result['status']='no_complete_blocks';return result
    if not covered.all():result['status']='incomplete_block_coverage';return result
    blocks=np.asarray(blocks);rng=np.random.default_rng(seed)
    draws=rng.integers(len(blocks),size=(repeats,int(np.ceil(len(v)/block))))
    means=blocks[draws].reshape(repeats,-1)[:,:len(v)].mean(axis=1)
    tail=(1-float(confidence_level))/2
    lo,hi=np.quantile(means,[tail,1-tail])
    result.update(low=float(lo),high=float(hi))
    return result

def paired_evaluate(predictions,config,planned_counts=None,score_mode='clipped'):
    """Evaluate one score definition on a shared set of valid prediction keys.

    The default preserves the prespecified clipped score. The raw mode reuses
    the same rows, blocks and output schema so callers can save separate raw_*
    products without mixing the two estimands.
    """
    if score_mode not in ('clipped','raw'):raise ValueError('score_mode must be clipped or raw')
    metrics=[];errors=[];intervals=[];stages=[]
    keys=['run_id','anchor_from','target_from','horizon','evaluation_vintage','issue_at','source_version','backtest_mode']
    if predictions.empty:return pd.DataFrame(),pd.DataFrame(),pd.DataFrame(),pd.DataFrame()
    required=keys+['split','model_id','status','observed','prediction','raw_prediction','stage_label']
    if any(c not in predictions for c in required):raise ValueError('Incomplete prediction schema')
    valid=predictions[(predictions.status=='ok') & (predictions.split!='future')].copy()
    if valid[keys+['split','model_id']].isna().any().any():raise ValueError('Scored prediction keys must not be missing')
    if not np.isfinite(valid[['observed','prediction','raw_prediction']].to_numpy(dtype=float)).all():
        raise ValueError('Scored observations and predictions must be finite')
    # Normalize dates before duplicate checks and key intersection, so equivalent
    # timestamp spellings cannot create two apparent copies of the same origin.
    for column in ('anchor_from','target_from'):
        # Exported CSVs combine ISO dates from validation with ISO date-times
        # from test rows. Parse the documented ISO family on re-import.
        valid[column]=pd.to_datetime(valid[column],format='ISO8601',errors='raise')
    valid['issue_at']=pd.to_datetime(valid.issue_at,format='ISO8601',errors='raise',utc=True).dt.tz_convert('Asia/Hong_Kong')
    if valid[['anchor_from','target_from','issue_at']].isna().any().any():raise ValueError('Scored timestamps must be known')
    if valid.duplicated(['split','model_id']+keys).any():raise ValueError('Duplicate prediction key in paired evaluation')
    for (split,h),frame in valid.groupby(['split','horizon']):
        frames={m:frame[frame.model_id==m].set_index(keys) for m in MODEL_IDS}
        common=frames['persistence'].index
        for x in frames.values():common=common.intersection(x.index)
        common=common.sort_values()
        if not len(common):continue
        paired={m:f.loc[common] for m,f in frames.items()}
        truth=paired['clinical_ridge'].observed.to_numpy()
        for f in paired.values():
            if not np.array_equal(f.observed.to_numpy(),truth):raise ValueError('Paired models have inconsistent observed labels')
        for column in ('train_anchor_keys','n_train'):
            if column in frame and not np.array_equal(paired['clinical_ridge'][column].to_numpy(),paired['combined_ridge'][column].to_numpy()):
                raise ValueError('Paired Ridge models have inconsistent training rows')
        base=paired['clinical_ridge'].reset_index()
        for column in ('evaluation_vintage','backtest_mode','run_id'):
            if column in base and base[column].nunique(dropna=False)!=1:
                raise ValueError('Different evaluation contexts must be scored separately')
        encoded='\n'.join('|'.join(map(str,k)) for k in common)
        set_id=hashlib.sha256(encoded.encode()).hexdigest()[:20]
        clipped_err={m:100*(f.observed.to_numpy()-f.prediction.to_numpy()) for m,f in paired.items()}
        raw_err={m:100*(f.observed.to_numpy()-f.raw_prediction.to_numpy()) for m,f in paired.items()}
        signed=raw_err if score_mode=='raw' else clipped_err
        err={m:np.abs(e) for m,e in signed.items()}
        delta=err['clinical_ridge']-err['combined_ridge']
        dates=base.anchor_from
        confidence=config['evaluation'].get('bootstrap_confidence_level',.95)
        ci=moving_block_interval(delta,dates,config['evaluation']['bootstrap_block_weeks'],config['evaluation']['bootstrap_repeats'],config['evaluation']['seed'],confidence)
        for b in [config['evaluation']['bootstrap_block_weeks']]+config['evaluation']['bootstrap_block_sensitivity']:
            interval=moving_block_interval(delta,dates,b,config['evaluation']['bootstrap_repeats'],config['evaluation']['seed'],confidence)
            intervals.append({'split':split,'horizon':h,'score_mode':score_mode,'paired_set_id':set_id,'delta_mae_pp':float(delta.mean()),**interval})
        clinical_mae=float(err['clinical_ridge'].mean())
        planned=(planned_counts or {}).get(split,len(common))
        if isinstance(planned,(bool,np.bool_)) or not isinstance(planned,(int,np.integer)) or planned<len(common):
            raise ValueError('Planned origin count must be an integer at least as large as the paired set')
        for m,f in paired.items():
            metrics.append({'run_id':base.run_id.iloc[0] if 'run_id' in base else 'frozen-v1','backtest_mode':base.backtest_mode.iloc[0],'split':split,'score_mode':score_mode,
                'horizon':h,'model_id':m,'paired_set_id':set_id,'n_origins':len(common),
                'mae_pp':float(err[m].mean()),'rmse_pp':float(np.sqrt(np.mean(signed[m]**2))),
                'raw_mae_pp':float(np.mean(np.abs(raw_err[m]))),'raw_rmse_pp':float(np.sqrt(np.mean(raw_err[m]**2))),
                'delta_mae_pp':float(delta.mean()) if m=='combined_ridge' else np.nan,
                'relative_gain_pct':100*float(delta.mean())/clinical_mae if m=='combined_ridge' and clinical_mae else np.nan,
                'delta_ci_low_pp':ci['low'] if m=='combined_ridge' else np.nan,
                'delta_ci_high_pp':ci['high'] if m=='combined_ridge' else np.nan,
                'n_clipped':int(np.count_nonzero(f.raw_prediction.to_numpy()!=f.prediction.to_numpy())),'coverage':len(common)/planned,
                'bootstrap_blocks':ci['n_blocks'],'bootstrap_status':ci['status'],
                'bootstrap_n_covered':ci['n_covered'],'bootstrap_n_uncovered':ci['n_uncovered'],
                'bootstrap_confidence_level':ci['confidence_level']})
        for j,r in base.iterrows():
            errors.append({'split':split,'horizon':h,'score_mode':score_mode,'anchor_from':r.anchor_from,'target_from':r.target_from,
                'anchor_year':r.anchor_year,'anchor_week':r.anchor_week,'target_year':r.target_year,'target_week':r.target_week,
                'stage_label':r.stage_label,'paired_set_id':set_id,'clinical_abs_error_pp':err['clinical_ridge'][j],
                'combined_abs_error_pp':err['combined_ridge'][j],'delta_error_pp':delta[j]})
        for stage in sorted(base.stage_label.unique()):
            ix=(base.stage_label==stage).to_numpy()
            stages.append({'split':split,'horizon':h,'score_mode':score_mode,'stage_label':stage,'n_origins':int(ix.sum()),
                'clinical_mae_pp':float(err['clinical_ridge'][ix].mean()),
                'combined_mae_pp':float(err['combined_ridge'][ix].mean()),'delta_mae_pp':float(delta[ix].mean())})
    return pd.DataFrame(metrics),pd.DataFrame(errors),pd.DataFrame(intervals),pd.DataFrame(stages)
