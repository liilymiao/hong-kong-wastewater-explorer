"""NumPy implementations of K-means and fixed-k LOF novelty scoring.

All distances are Euclidean. Ties use the original reference-row order. The
caller must fit preprocessing on past reference data before passing arrays.
"""

from __future__ import annotations

import numpy as np


def _matrix(x: np.ndarray) -> np.ndarray:
    x = np.asarray(x, dtype=float)
    if x.ndim != 2 or not x.shape[0] or not x.shape[1]:
        raise ValueError("Expected a nonempty two-dimensional matrix")
    if not np.isfinite(x).all():
        raise ValueError("Input must contain only finite values")
    return x


def distances(a: np.ndarray, b: np.ndarray) -> np.ndarray:
    """Euclidean distances; direct subtraction avoids cancellation near zero."""
    return np.sqrt(np.sum((a[:, None, :] - b[None, :, :]) ** 2, axis=2))


class Standardizer:
    """Population standard deviation; constant columns use a scale of one."""

    def fit(self, x: np.ndarray) -> "Standardizer":
        x = _matrix(x)
        self.mean_ = x.mean(axis=0)
        scale = x.std(axis=0, ddof=0)
        self.constant_columns_ = scale == 0
        self.scale_ = np.where(self.constant_columns_, 1.0, scale)
        return self

    def transform(self, x: np.ndarray) -> np.ndarray:
        x = _matrix(x)
        if x.shape[1] != len(self.mean_):
            raise ValueError("Feature count differs from fitted reference")
        return (x - self.mean_) / self.scale_

    def fit_transform(self, x: np.ndarray) -> np.ndarray:
        return self.fit(x).transform(x)

    def inverse_transform(self, x: np.ndarray) -> np.ndarray:
        return np.asarray(x, dtype=float) * self.scale_ + self.mean_


class KMeans:
    """Lloyd iterations with k-means++ initialization and empty-cluster repair.

    An empty cluster receives the farthest point from its current center among
    clusters containing at least two rows. Stable row order resolves ties. This
    also handles duplicate rows when at least k distinct points are available.
    Cluster identifiers are sorted lexicographically by final center, so random
    initialization does not create arbitrary label swaps for the same solution.
    A final assignment makes ``labels_`` agree with ``predict(x)`` even at the
    iteration limit. ``converged_`` states whether that assignment also leaves
    the last center-update partition unchanged; ``effective_k_`` records the
    number of occupied final clusters.
    """

    def __init__(self, n_clusters=3, n_init=20, max_iter=300, random_state=42,
                 tol=1e-8):
        self.n_clusters = int(n_clusters)
        self.n_init = int(n_init)
        self.max_iter = int(max_iter)
        self.random_state = int(random_state)
        self.tol = float(tol)
        if min(self.n_clusters, self.n_init, self.max_iter) < 1 or self.tol < 0:
            raise ValueError("Invalid K-means parameters")

    def _initialize(self, x, rng):
        chosen = [int(rng.integers(len(x)))]
        nearest_squared = distances(x, x[chosen])[:, 0] ** 2
        while len(chosen) < self.n_clusters:
            total = nearest_squared.sum()
            if total <= 0:
                index = next(i for i in range(len(x)) if i not in chosen)
            else:
                index = int(rng.choice(len(x), p=nearest_squared / total))
            chosen.append(index)
            nearest_squared = np.minimum(
                nearest_squared, distances(x, x[[index]])[:, 0] ** 2)
        return x[chosen].copy()

    def _assign(self, x, centers):
        squared = distances(x, centers) ** 2
        labels = squared.argmin(axis=1)
        counts = np.bincount(labels, minlength=self.n_clusters)
        for empty in np.flatnonzero(counts == 0):
            candidates = np.flatnonzero(counts[labels] > 1)
            residuals = squared[candidates, labels[candidates]]
            index = candidates[int(np.argmax(residuals))]
            counts[labels[index]] -= 1
            labels[index] = empty
            counts[empty] += 1
        return labels

    def fit(self, x: np.ndarray) -> "KMeans":
        x = _matrix(x)
        if len(x) < self.n_clusters:
            raise ValueError("n_clusters exceeds the number of reference rows")
        n_distinct = len(np.unique(x, axis=0))
        if n_distinct < self.n_clusters:
            raise ValueError("n_clusters exceeds the number of distinct reference points")
        rng = np.random.default_rng(self.random_state)
        best = None
        for _ in range(self.n_init):
            centers = self._initialize(x, rng)
            previous_labels = None
            for iteration in range(1, self.max_iter + 1):
                labels = self._assign(x, centers)
                updated = np.array([x[labels == j].mean(axis=0)
                                    for j in range(self.n_clusters)])
                shift = np.max(np.linalg.norm(updated - centers, axis=1))
                unchanged = (previous_labels is not None
                             and np.array_equal(labels, previous_labels))
                centers = updated
                previous_labels = labels.copy()
                if unchanged or shift <= self.tol:
                    break
            order = np.array(sorted(range(self.n_clusters),
                                    key=lambda j: tuple(centers[j])))
            inverse = np.empty(self.n_clusters, dtype=int)
            inverse[order] = np.arange(self.n_clusters)
            centers, updated_partition = centers[order], inverse[labels]
            # Reassign after sorting as well as updating: a distance tie must
            # use the same center order as predict(). At max_iter these labels
            # may differ from the partition that produced the final means.
            labels = distances(x, centers).argmin(axis=1)
            converged = bool(np.array_equal(labels, updated_partition))
            effective_k = len(np.unique(labels))
            inertia = float(np.sum((x - centers[labels]) ** 2))
            key = (inertia, tuple(centers.ravel()))
            if best is None or key < best[0]:
                best = (key, centers.copy(), labels.copy(), iteration,
                        converged, effective_k)
        self.inertia_ = best[0][0]
        self.cluster_centers_ = best[1]
        self.labels_ = best[2]
        self.n_iter_ = best[3]
        self.converged_ = best[4]
        self.effective_k_ = best[5]
        self.n_distinct_points_ = n_distinct
        self.n_features_in_ = x.shape[1]
        return self

    def predict(self, x: np.ndarray) -> np.ndarray:
        x = _matrix(x)
        if x.shape[1] != self.n_features_in_:
            raise ValueError("Feature count differs from fitted reference")
        return distances(x, self.cluster_centers_).argmin(axis=1)

    def fit_predict(self, x: np.ndarray) -> np.ndarray:
        return self.fit(x).labels_.copy()


class LOFNovelty:
    """Fixed-k local outlier factor, with higher scores meaning more unusual.

    Reference neighbors exclude their own row. Distances tied at the kth
    position are truncated to exactly k using stable reference-row order.
    Query rows never enter the fitted neighbor graph or reference density.
    The mean reachability distance has a lower bound of ``epsilon`` to make
    duplicate reference points well-defined; duplicate counts remain visible.
    """

    def __init__(self, n_neighbors=10, epsilon=1e-12):
        self.n_neighbors = int(n_neighbors)
        self.epsilon = float(epsilon)
        if self.n_neighbors < 1 or self.epsilon <= 0:
            raise ValueError("Invalid LOF parameters")

    def fit(self, x: np.ndarray) -> "LOFNovelty":
        self.reference_ = _matrix(x).copy()
        if self.n_neighbors >= len(x):
            raise ValueError("LOF requires more reference rows than neighbors")
        d = distances(self.reference_, self.reference_)
        duplicate_matrix = d == 0
        np.fill_diagonal(duplicate_matrix, False)
        self.duplicate_rows_ = int(duplicate_matrix.any(axis=1).sum())
        self.duplicate_pairs_ = int(duplicate_matrix.sum() // 2)
        np.fill_diagonal(d, np.inf)
        self.neighbors_ = np.argsort(d, axis=1, kind="stable")[:, :self.n_neighbors]
        self.neighbor_distances_ = np.take_along_axis(d, self.neighbors_, axis=1)
        self.k_distances_ = self.neighbor_distances_[:, -1]
        reach = np.maximum(self.neighbor_distances_,
                           self.k_distances_[self.neighbors_])
        self.lrd_ = 1.0 / np.maximum(reach.mean(axis=1), self.epsilon)
        self.reference_scores_ = self.lrd_[self.neighbors_].mean(axis=1) / self.lrd_
        return self

    def query_details(self, x: np.ndarray) -> dict:
        x = _matrix(x)
        if x.shape[1] != self.reference_.shape[1]:
            raise ValueError("Feature count differs from fitted reference")
        d = distances(x, self.reference_)
        neighbors = np.argsort(d, axis=1, kind="stable")[:, :self.n_neighbors]
        neighbor_distances = np.take_along_axis(d, neighbors, axis=1)
        reach = np.maximum(neighbor_distances, self.k_distances_[neighbors])
        lrd = 1.0 / np.maximum(reach.mean(axis=1), self.epsilon)
        scores = self.lrd_[neighbors].mean(axis=1) / lrd
        return {"scores": scores, "neighbors": neighbors,
                "distances": neighbor_distances, "reachability_distances": reach,
                "lrd": lrd}

    def score_samples(self, x: np.ndarray) -> np.ndarray:
        return self.query_details(x)["scores"]


def silhouette_score(x: np.ndarray, labels: np.ndarray) -> float:
    """Mean silhouette; singleton cluster members contribute zero."""
    x = _matrix(x)
    labels = np.asarray(labels)
    unique = np.unique(labels)
    if len(unique) < 2 or len(unique) >= len(x):
        return float("nan")
    d = distances(x, x)
    values = np.zeros(len(x))
    for i in range(len(x)):
        same = labels == labels[i]
        same[i] = False
        if not same.any():
            continue
        a = float(d[i, same].mean())
        b = min(float(d[i, labels == label].mean())
                for label in unique if label != labels[i])
        values[i] = (b - a) / max(a, b) if max(a, b) else 0.0
    return float(values.mean())


def adjusted_rand_score(a: np.ndarray, b: np.ndarray) -> float:
    """Permutation-invariant partition agreement, adjusted for chance."""
    a, b = np.asarray(a), np.asarray(b)
    if a.shape != b.shape or a.ndim != 1 or len(a) < 2:
        raise ValueError("Expected equal one-dimensional label arrays")
    _, ai = np.unique(a, return_inverse=True)
    _, bi = np.unique(b, return_inverse=True)
    table = np.zeros((ai.max() + 1, bi.max() + 1), dtype=int)
    np.add.at(table, (ai, bi), 1)
    choose2 = lambda v: np.sum(v * (v - 1) / 2)
    nij = choose2(table)
    na, nb = choose2(table.sum(axis=1)), choose2(table.sum(axis=0))
    expected = na * nb / (len(a) * (len(a) - 1) / 2)
    maximum = (na + nb) / 2
    if maximum == expected:
        return 1.0
    return float((nij - expected) / (maximum - expected))
