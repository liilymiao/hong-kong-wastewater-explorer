"""Validate supported analysis settings before creating any derived outputs."""
from pathlib import PurePosixPath
import math


def validate_config(config):
    required = {
        ('project', 'timezone'): 'Asia/Hong_Kong',
        ('data', 'target'): 'SARSCoV2_proportion',
        ('data', 'sewage'): 'Sewage_viralload',
        ('data', 'date_format'): '%d/%m/%Y',
        ('data', 'official_week_start'): 'Sunday',
        ('data', 'target_scale'): 'proportion',
        ('data', 'display_scale'): 'percent',
        ('data', 'metric_scale'): 'percentage_points',
        ('forecast', 'primary_horizon'): 2,
        ('forecast', 'secondary_horizon'): 1,
        ('forecast', 'sewage_transform'): 'log1p',
        ('forecast', 'training_window'): 'expanding',
        ('forecast', 'missing_strategy'): 'paired_complete_case',
        ('timing', 'primary_mode'): 'frozen_retrospective',
        ('models', 'loss_normalized_by_n'): True,
        ('models', 'intercept_penalized'): False,
        ('models', 'core_implementation'): 'numpy',
        ('evaluation', 'main_metric'): 'mae_pp',
        ('evaluation', 'secondary_metric'): 'rmse_pp',
        ('evaluation', 'gain_direction'): 'clinical_error_minus_combined_error',
        ('evaluation', 'paired_training_rows'): True,
        ('evaluation', 'paired_test_origins'): True,
        ('patterns', 'reference_end_offset_weeks'): 1,
        ('patterns', 'score_queries_as_novelty'): True,
        ('split', 'require_validation_labels_available_before_test'): True,
        ('timing', 'archive_timestamp_is_publication_timestamp'): False,
        ('output', 'require_source_version'): True,
        ('output', 'require_evaluation_vintage'): True,
        ('output', 'no_placeholder_results'): True,
    }
    for (section, key), expected in required.items():
        if config.get(section, {}).get(key) != expected:
            raise ValueError(f'Unsupported setting {section}.{key}: this implementation requires {expected!r}')
    for key in ('csv', 'date_overrides'):
        path = PurePosixPath(config['data'][key])
        if path.is_absolute() or '..' in path.parts:
            raise ValueError(f'data.{key} must be a path within the project')
    path = PurePosixPath(config['output']['directory'])
    if path.is_absolute() or '..' in path.parts or str(path) in ('', '.'):
        raise ValueError('output.directory must be a subdirectory within the project')
    if path.parts[0] in ('data', 'src', 'tests', 'sources', 'scripts'):
        raise ValueError('output.directory must not overlap source or code directories')
    lags = config['forecast']['lags']
    if not lags or any(type(x) is not int or x < 0 for x in lags) or len(set(lags)) != len(lags):
        raise ValueError('forecast.lags must contain unique non-negative integers')
    if 0 not in lags:
        raise ValueError('forecast.lags must include the current observation (0)')
    if config['forecast']['output_clip'] != [0.0, 1.0]:
        raise ValueError('The predeclared proportion output range is [0, 1]')
    if not config['data'].get('preserve_raw') or not config['forecast'].get('keep_raw_prediction'):
        raise ValueError('Raw source and raw predictions must be retained')
    for prefix in ('validation', 'test'):
        span = config['split'][prefix + '_origin_week_range']
        if span.get('inclusive') is not True or not 1 <= span['start_week'] <= span['end_week'] <= 53:
            raise ValueError(f'Invalid inclusive {prefix} week range')
    lambdas = config['models']['ridge_lambdas']
    if not lambdas or len(set(lambdas)) != len(lambdas) or any(not math.isfinite(x) or x <= 0 for x in lambdas):
        raise ValueError('ridge_lambdas must contain unique finite positive values')
    if set(config['models']['required']) != {'persistence', 'clinical_ridge', 'combined_ridge', 'kmeans', 'lof'}:
        raise ValueError('models.required must match the five implemented models')
    for section, key, minimum in (('patterns', 'kmeans_candidates', 2),
                                  ('patterns', 'lof_neighbors', 1),
                                  ('evaluation', 'bootstrap_block_sensitivity', 1)):
        values = config[section][key]
        if (not isinstance(values, list) or not values or len(set(values)) != len(values)
                or any(type(value) is not int or value < minimum for value in values)):
            raise ValueError(f'{section}.{key} must contain unique integers >= {minimum}')
    neighbors = config['patterns']['lof_primary_neighbors']
    if type(neighbors) is not int or neighbors not in config['patterns']['lof_neighbors']:
        raise ValueError('lof_primary_neighbors must be an integer in lof_neighbors')
    seed = config['evaluation']['seed']
    if type(seed) is not int or seed < 0:
        raise ValueError('evaluation.seed must be a nonnegative integer')
    for section, key in (('forecast', 'minimum_training_rows'), ('split', 'warmup_weeks'),
                         ('patterns', 'reference_window_weeks'), ('patterns', 'minimum_reference_rows'),
                         ('patterns', 'kmeans_initializations'), ('patterns', 'kmeans_max_iterations'),
                         ('evaluation', 'bootstrap_block_weeks'), ('evaluation', 'bootstrap_repeats')):
        value = config[section][key]
        if type(value) is not int or value < 1:
            raise ValueError(f'{section}.{key} must be a positive integer')
    if config['evaluation']['bootstrap_repeats'] < 2:
        raise ValueError('bootstrap_repeats must be at least 2')
    if config['patterns']['minimum_reference_rows'] <= max(config['patterns']['lof_neighbors']):
        raise ValueError('minimum_reference_rows must exceed all LOF neighborhood sizes')
    if config['patterns']['minimum_reference_rows'] > config['patterns']['reference_window_weeks']:
        raise ValueError('minimum_reference_rows must fit inside the reference window')
    confidence = config['evaluation']['bootstrap_confidence_level']
    if not isinstance(confidence, (int, float)) or not 0 < confidence < 1:
        raise ValueError('bootstrap_confidence_level must be between 0 and 1')
    time = config['timing']['nominal_issue_time_hkt']
    try:
        hour, minute = map(int, time.split(':'))
    except (ValueError, AttributeError):
        raise ValueError('nominal_issue_time_hkt must be HH:MM') from None
    if not 0 <= hour <= 23 or not 0 <= minute <= 59:
        raise ValueError('Invalid nominal issue clock time')
    days = [config['timing']['nominal_issue_days_after_week_end'], *config['timing']['delay_sensitivity_days']]
    if any(type(day) is not int or day < 0 for day in days):
        raise ValueError('Publication delay days must be non-negative integers')
    return config
