"""Reproducible offline pipeline: audit -> validate/freeze -> test -> export."""
import argparse
import importlib.metadata
import json
from pathlib import Path
import platform
import subprocess
import sys
import uuid
from datetime import datetime,timezone
import pandas as pd
import yaml
from .data import load_snapshot,sha256
from .features import build_features,make_origin_manifest,delay_manifest,split_indices
from .backtest import rolling_validate,freeze_config,selected_validation,rolling_test,paired_evaluate,config_digest
from .configuration import validate_config
from .artifacts import write_run_state,seal_artifacts,write_stage_receipt,verify_stage_receipt,ArtifactError,digest_file

def load_config(path):return validate_config(yaml.safe_load(Path(path).read_text(encoding='utf-8')))

def write_csv(df,path):
    Path(path).parent.mkdir(parents=True,exist_ok=True)
    df.to_csv(path,index=False,encoding='utf-8-sig',float_format='%.17g')

def preflight(config,root,stage='all'):
    """Read-only checks before touching any existing analytical output."""
    validate_config(config)
    root=Path(root)
    out=root/config['output']['directory']
    frozen_path=out/'frozen_config.json'
    if frozen_path.exists():
        frozen=json.loads(frozen_path.read_text(encoding='utf-8'))
        if frozen.get('config_sha256')!=config_digest(config):
            raise ValueError('Config has changed after freeze. Use a new output directory for a new analysis.')
    else:
        frozen=None
        if stage in ('test','export'):
            raise ValueError('Run validate stage before test/export')
    clean=load_snapshot(root/config['data']['csv'],config,project_root=root)
    feat=build_features(clean,config['forecast']['lags'])
    pattern_path=out/'pattern_config.json'
    if pattern_path.exists():
        from .pattern_pipeline import validate_pattern_frozen
        pattern_frozen=json.loads(pattern_path.read_text(encoding='utf-8'))
        validate_pattern_frozen(clean,config,pattern_frozen)
        # A rebuild may legitimately replace numerical code or derived tables.
        # Its already-recorded frozen decision must still be intact before any
        # writes. Full stage verification remains required for test/export.
        receipt_path=out/'stage_validate.json'
        if receipt_path.exists():
            try:
                receipt=json.loads(receipt_path.read_text(encoding='utf-8'))
                record=receipt['files'][str(pattern_path.relative_to(root))]
                intact=(receipt['schema_version']==1 and receipt['stage']=='validate'
                        and record['sha256']==digest_file(pattern_path)
                        and record['bytes']==pattern_path.stat().st_size)
            except (OSError,ValueError,TypeError,KeyError) as exc:
                raise ArtifactError('模式冻结决定缺少有效的验证阶段记录，请保留旧结果并使用新输出目录。') from exc
            if not intact:
                raise ArtifactError('模式冻结决定与验证阶段记录不一致，请保留旧结果并使用新输出目录。')
    if frozen is not None:
        from .backtest import validate_frozen
        validate_frozen(feat,config,frozen)
    if stage == 'test':
        verify_stage_receipt(root,config,'validate')
    if stage == 'export':
        verify_stage_receipt(root,config,'test')
    return clean,feat,out

def prepare(config,root,prepared=None):
    clean,feat,out=prepared if prepared is not None else preflight(config,root)
    out=root/config['output']['directory'];out.mkdir(parents=True,exist_ok=True)
    write_csv(clean,root/'data/processed/clean.csv')
    write_csv(feat,root/'data/processed/features.csv')
    manifest=make_origin_manifest(feat,config)
    write_csv(manifest,out/'origins.csv')
    write_csv(delay_manifest(clean,config),out/'delay_sensitivity.csv')
    (out/'data_quality.json').write_text(json.dumps(clean.attrs['quality'],ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    coverage=[]
    for (split,h),f in manifest.groupby(['split','horizon']):
        for m,col in [('persistence','clinical_available'),('clinical_ridge_unpaired_availability','clinical_available'),('paired_comparison','paired_available')]:
            coverage.append({'split':split,'horizon':h,'system':m,'planned_origins':len(f),
                'features_available':int(f[col].sum()),'eligible_paired_origins':int((f.status=='ok').sum()),
                'feature_coverage':float(f[col].mean())})
    write_csv(pd.DataFrame(coverage),out/'coverage.csv')
    return clean,feat,out

def save_evaluation(pred,config,out,prefix='',score_mode='clipped'):
    counts={s:config['split'][s+'_origin_week_range']['end_week']-config['split'][s+'_origin_week_range']['start_week']+1 for s in ('validation','test')}
    metrics,paired,ci,stages=paired_evaluate(pred,config,counts,score_mode=score_mode)
    for name,df in [('metrics',metrics),('paired_errors',paired),('bootstrap_sensitivity',ci),('stage_metrics',stages)]:
        write_csv(df,out/f'{prefix}{name}.csv')

def execute_stage(root,config,stage,prepared):
    # Export consumes the verified generation without rewriting model inputs.
    clean,feat,out=prepared if stage == 'export' else prepare(config,root,prepared)
    if stage in ('audit','all'):
        subprocess.run([sys.executable,str(root/'data/audit_data.py')],check=True)
        audit=json.loads((root/'data/audit.json').read_text(encoding='utf-8'))
        if not all(x['sha256_matches_retrieval_record'] for x in audit['source_integrity_checks']):raise ValueError('Source integrity failure')
    if stage in ('validate','all'):
        # Only validation origins are forecast. No test model scores are read for selection.
        candidates=rolling_validate(feat,config)
        write_csv(candidates,out/'validation_candidates.csv')
        summary=candidates[candidates.model_id!='persistence'].groupby(['model_id','horizon','lambda'],as_index=False).agg(mae_pp=('abs_error_pp','mean'),n_origins=('abs_error_pp','size'))
        write_csv(summary,out/'validation_scores.csv')
        frozen=freeze_config(candidates,feat,config,out/'frozen_config.json')
        val=selected_validation(candidates,frozen)
        write_csv(val,out/'validation_predictions.csv')
        from .pattern_pipeline import freeze_pattern_config
        freeze_pattern_config(clean,config,out)
        write_stage_receipt(root,config,'validate')
        print(json.dumps({'stage':'validate','selected_parameters':frozen['parameters'],'frozen_available_at':frozen['frozen_available_at']},ensure_ascii=False))
    if stage in ('test','all'):
        path=out/'frozen_config.json'
        if not path.exists():raise ValueError('Run validate stage before test')
        frozen=json.loads(path.read_text(encoding='utf-8'))
        test=rolling_test(feat,config,frozen)
        future=rolling_test(feat,config,frozen,split='future')
        val=pd.read_csv(out/'validation_predictions.csv')
        pred=pd.concat([val,test,future],ignore_index=True)
        write_csv(pred,out/'predictions.csv')
        save_evaluation(pred,config,out)
        save_evaluation(pred,config,out,'raw_',score_mode='raw')
        shared=rolling_test(feat,config,frozen,shared=True)
        write_csv(shared,out/'shared_lambda_predictions.csv')
        save_evaluation(shared,config,out,'shared_lambda_')
        from .pattern_pipeline import run_patterns
        run_patterns(clean,config,out)
        write_stage_receipt(root,config,'test')
        print(json.dumps({'stage':'test','test_predictions':len(test),'future_predictions':len(future)},ensure_ascii=False))
    if stage in ('export','all'):
        if not (out/'predictions.csv').exists():raise ValueError('Run test stage before export')
        from .outputs import export_report
        export_report(root,config)
    versions={p:importlib.metadata.version(p) for p in ('numpy','pandas','pyyaml','pytest','plotly','streamlit')}
    runtime={'python':platform.python_version(),'platform':platform.platform(),'dependencies':versions,
        'config_sha256':config_digest(config),'source_sha256':sha256(root/config['data']['csv']),
        'stage':stage,'completed_utc':datetime.now(timezone.utc).isoformat()}
    (out/'runtime.json').write_text(json.dumps(runtime,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    (out/'config.json').write_text(json.dumps(config,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    with (out/'run_log.jsonl').open('a',encoding='utf-8') as f:f.write(json.dumps(runtime,ensure_ascii=False)+'\n')
    print(json.dumps({'completed':stage,'outputs':str(out),'quality':clean.attrs['quality']},ensure_ascii=False))
    return out


def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config',default='config.yaml')
    parser.add_argument('--stage',choices=['audit','validate','test','export','all'],default='all')
    args=parser.parse_args(argv)
    cfgpath=Path(args.config).resolve();root=cfgpath.parent;config=load_config(cfgpath)
    # A rejected configuration or source leaves all prior outputs untouched.
    prepared=preflight(config,root,args.stage)
    run_id=uuid.uuid4().hex
    write_run_state(root,config,args.stage,'running',run_id)
    try:
        out=execute_stage(root,config,args.stage,prepared)
        if args.stage in ('export','all'):
            seal_artifacts(root,config,run_id)
        else:
            write_run_state(root,config,args.stage,'awaiting_export',run_id)
    except Exception as exc:
        write_run_state(root,config,args.stage,'failed',run_id,exc)
        raise
    return out

if __name__=='__main__':main()
