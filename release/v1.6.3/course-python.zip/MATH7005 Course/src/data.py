"""Frozen source parsing; original bytes are never overwritten."""
from pathlib import Path
import csv
import hashlib
import json
import pandas as pd
import numpy as np

MISSING = {'', '/', '-'}

def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def validate_week_index(df):
    if df[['Year','Week']].duplicated().any() or df.From.duplicated().any():
        raise ValueError('Duplicate official week or date')
    if not (df.From.dt.dayofweek == 6).all():
        raise ValueError('Official From must be Sunday')
    if not (df.From.diff().dropna() == pd.Timedelta(days=7)).all():
        raise ValueError('Non-contiguous weekly index')
    if not ((df.To_corrected-df.From).dt.days == 6).all():
        raise ValueError('Unknown date error; supply verified override before modelling')

def apply_date_overrides(df, overrides_path):
    """Match all four source fields. An already repaired value needs no override."""
    df = df.copy()
    df['To_raw'] = df['To']
    df['To_corrected'] = pd.to_datetime(df['To'],format='%d/%m/%Y',errors='raise')
    df['correction_applied'] = False
    df['correction_source_url'] = ''
    rules = pd.read_csv(overrides_path, dtype=str, keep_default_na=False)
    for r in rules.to_dict('records'):
        mask = ((df.Year == int(r['Year'])) & (df.Week == int(r['Week']))
                & (df.From_raw == r['From']) & (df.To_raw == r['original_value']))
        if mask.sum() > 1:
            raise ValueError('Override matches more than one row')
        df.loc[mask,'To_corrected'] = pd.to_datetime(r['corrected_value'],format='%d/%m/%Y')
        df.loc[mask,'correction_applied'] = True
        df.loc[mask,'correction_source_url'] = r['source_url']
    return df

def load_snapshot(path, config=None, verify_hash=True, project_root=None):
    path = Path(path)
    config = config or {}
    dc = config.get('data', {})
    digest = sha256(path)
    expected = dc.get('sha256')
    if verify_hash and expected and digest != expected:
        raise ValueError(f'Source SHA256 mismatch: {digest}')
    with path.open(encoding='utf-8-sig',newline='') as f:
        reader=csv.DictReader(f)
        fields=reader.fieldnames
        records=[]; blank=[]
        for row_index,r in enumerate(reader,start=2):
            if all(str(v or '').strip()=='' for v in r.values()):
                blank.append(row_index); continue
            r['source_row_number']=row_index
            records.append(r)
    df=pd.DataFrame(records)
    if verify_hash and dc.get('expected_valid_rows') and len(df)!=dc['expected_valid_rows']:
        raise ValueError('Unexpected valid row count')
    if verify_hash and dc.get('expected_columns') and len(fields)!=dc['expected_columns']:
        raise ValueError('Unexpected column count')
    for col in fields:
        if col in ['From','To']: continue
        tokens=df[col].astype(str).str.strip()
        df[col]=pd.to_numeric(tokens.mask(tokens.isin(set(dc.get('missing_markers', MISSING)))),errors='raise')
    df[['Year','Week']]=df[['Year','Week']].astype(int)
    df['From_raw']=df.From
    df['From']=pd.to_datetime(df.From,format='%d/%m/%Y',errors='raise')
    if project_root is not None and dc.get('date_overrides'):
        overrides=Path(project_root)/dc['date_overrides']
    elif dc.get('date_overrides'):
        # Preserve convenient direct calls for the standard data/ layout.
        overrides=path.parent/Path(dc['date_overrides']).name
    else:
        overrides=path.parent/'date_overrides.csv'
    df=apply_date_overrides(df,overrides)
    df=df.sort_values('From').reset_index(drop=True)
    validate_week_index(df)
    if not df.SARSCoV2_proportion.dropna().between(0,1).all():
        raise ValueError('Clinical proportions must be within [0,1]')
    if (df.Sewage_viralload.dropna()<0).any():
        raise ValueError('Negative sewage measurement')
    numeric = df.select_dtypes(include=[np.number])
    if np.isinf(numeric.to_numpy(dtype=float)).any():
        raise ValueError('Infinite numerical measurements are invalid')
    df['week_key']=df.Year.astype(str)+'W'+df.Week.astype(str)
    df['week_index']=np.arange(len(df))
    df['source_version']=f'{path.name}:sha256:{digest}'
    df['source_row_key']=df.source_version+':'+df.week_key
    catalog=path.parent/'source_catalog.json'
    meta=json.loads(catalog.read_text(encoding='utf-8')) if catalog.exists() else {}
    df['retrieved_utc']=meta.get('raw',{}).get('retrieved_utc','')
    df['sentinel_public_clinic_rate']=df.get('COVID19_FMC',df.get('COVID19_GOPC'))
    df['sentinel_original_field']='COVID19_FMC' if 'COVID19_FMC' in df else 'COVID19_GOPC'
    timing=config.get('timing',{})
    day=timing.get('nominal_issue_days_after_week_end',5)
    time=timing.get('nominal_issue_time_hkt','23:59')
    hour,minute=map(int,time.split(':'))
    df['issue_at']=(df.To_corrected+pd.Timedelta(days=day,hours=hour,minutes=minute)).dt.tz_localize('Asia/Hong_Kong')
    df['feature_available_at']=df.issue_at
    df['label_available_at']=df.issue_at
    df.attrs['quality']={'valid_rows':len(df),'columns':len(fields),'blank_source_rows':blank,
        'sewage_valid_rows':int(df.Sewage_viralload.notna().sum()),'source_sha256':digest,
        'corrections':int(df.correction_applied.sum()),'sewage_missing':df.loc[df.Sewage_viralload.isna(),'week_key'].tolist()}
    return df

def load_vintages(directory):
    """Inventory only: existing immutable archive samples, not a completed as-of backtest."""
    return sorted(Path(directory).glob('covidx_archive_*.csv'))
