"""Causal lag features and explicit, inspectable origin eligibility."""
import numpy as np
import pandas as pd

def _checked_lags(lags):
    lags=tuple(lags)
    if not lags or any(isinstance(l,(bool,np.bool_)) or not isinstance(l,(int,np.integer)) or l<0 for l in lags):
        raise ValueError('Lags must be nonnegative integers; future lags are forbidden')
    if len(set(lags))!=len(lags):raise ValueError('Duplicate lags are not allowed')
    return lags

def _issue_timestamp(value):
    """An unknown or timezone-naive issue time cannot establish availability."""
    value=pd.Timestamp(value)
    if pd.isna(value) or value.tzinfo is None:
        raise ValueError('A known timezone-aware issue_at is required')
    return value

def _availability_times(values):
    """Normalize known arrival times; preserve unknown arrivals as NaT."""
    if isinstance(values.dtype,pd.DatetimeTZDtype):return values.dt.tz_convert('UTC')
    for value in values.dropna():
        if pd.Timestamp(value).tzinfo is None:
            raise ValueError('Availability timestamps must be timezone-aware')
    return pd.to_datetime(values,errors='raise',utc=True)

def feature_columns(lags=(0,1,2)):
    lags=_checked_lags(lags)
    clinical=[f'p_lag_{l}' for l in lags]
    return clinical,clinical+[f'w_log1p_lag_{l}' for l in lags]

def build_features(df,lags=(0,1,2)):
    lags=_checked_lags(lags)
    out=df.copy()
    if (out.Sewage_viralload.dropna()<0).any():raise ValueError('Negative sewage measurement')
    for l in lags:
        out[f'p_lag_{l}']=out.SARSCoV2_proportion.shift(l)
        out[f'w_log1p_lag_{l}']=np.log1p(out.Sewage_viralload).shift(l)
    # A lagged row is available only after every contributing observation is available.
    arrivals=pd.concat([_availability_times(df.feature_available_at).shift(l) for l in lags],axis=1)
    known_arrivals=arrivals.notna().all(axis=1)
    out['feature_available_at']=arrivals.max(axis=1).where(known_arrivals,pd.NaT)
    c,cw=feature_columns(lags)
    out['clinical_complete']=np.isfinite(out[c].to_numpy(dtype=float)).all(axis=1)
    out['paired_complete']=np.isfinite(out[cw].to_numpy(dtype=float)).all(axis=1)
    out['clinical_change_2w']=out.SARSCoV2_proportion-out.SARSCoV2_proportion.shift(2)
    out['stage_label']=np.select([out.clinical_change_2w>0,out.clinical_change_2w<0],['上升','下降'],default='持平')
    return out

def eligible_training_rows(features,t,horizon,minimum=52,*,issue_at=None):
    """s+h <= t, non-missing features AND already available target; one mask for both Ridge models."""
    if isinstance(t,(bool,np.bool_)) or not isinstance(t,(int,np.integer)) or not 0<=t<len(features):
        raise ValueError('Origin index is outside the data')
    if isinstance(horizon,(bool,np.bool_)) or not isinstance(horizon,(int,np.integer)) or horizon<1:
        raise ValueError('Horizon must be a positive integer')
    # minimum is retained for API compatibility; the caller decides whether to skip
    # a forecast after inspecting the eligible row count.
    effective_issue=_issue_timestamp(features.iloc[t].issue_at if issue_at is None else issue_at)
    idx=np.arange(len(features))
    target=features.SARSCoV2_proportion.shift(-horizon)
    maturity=(idx+horizon<=t)
    label_times=_availability_times(features.label_available_at).shift(-horizon)
    feature_times=_availability_times(features.feature_available_at)
    available=label_times.notna() & (label_times<=effective_issue)
    feature_available=feature_times.notna() & (feature_times<=effective_issue)
    mask=features.paired_complete.to_numpy() & maturity & available.to_numpy() & feature_available.to_numpy() & np.isfinite(target.to_numpy(dtype=float))
    rows=idx[mask]
    if len(rows):
        assert (rows+horizon<=t).all()
        assert (label_times.iloc[rows]<=effective_issue).all()
    return rows

def split_indices(df,config,split):
    if split not in ('validation','test'):raise ValueError('Unknown split')
    section=config['split'];prefix='validation' if split=='validation' else 'test'
    r=section[prefix+'_origin_week_range']
    if r.get('inclusive',True) is not True:raise ValueError('Only inclusive week ranges are supported')
    if r['start_week']>r['end_week']:raise ValueError('Reversed week range')
    return np.flatnonzero((df.Year==section[prefix+'_origin_year']) & df.Week.between(r['start_week'],r['end_week']))

def target_dates(df,t,horizon):
    start=df.iloc[t].From+pd.Timedelta(weeks=horizon)
    if t+horizon<len(df):
        row=df.iloc[t+horizon]
        year,week=int(row.Year),int(row.Week)
    else:
        # Official convention: week 1 is the Sunday-start week containing 1 January.
        # Never use ISO numbering; date-to-week only extrapolates beyond this snapshot.
        jan1=pd.Timestamp(start.year,1,1)
        first=jan1-pd.Timedelta(days=(jan1.dayofweek+1)%7)
        next_jan=pd.Timestamp(start.year+1,1,1)
        next_first=next_jan-pd.Timedelta(days=(next_jan.dayofweek+1)%7)
        year=start.year+1 if start>=next_first else start.year
        if year!=start.year:first=next_first
        week=int((start-first).days//7+1)
    return {'target_year':year,'target_week':week,'target_from':start,'target_to':start+pd.Timedelta(days=6)}

def make_origin_manifest(features,config):
    rows=[]
    for split in ('validation','test'):
        for t in split_indices(features,config,split):
            for h in (config['forecast']['primary_horizon'],config['forecast']['secondary_horizon']):
                tr=eligible_training_rows(features,t,h)
                reason='ok'
                if not features.iloc[t].paired_complete:reason='missing_joint_features'
                elif pd.isna(features.iloc[t].feature_available_at) or features.iloc[t].feature_available_at>features.iloc[t].issue_at:reason='features_not_yet_available'
                elif len(tr)<config['forecast']['minimum_training_rows']:reason='insufficient_training_rows'
                elif t+h>=len(features) or pd.isna(features.iloc[t+h].SARSCoV2_proportion):reason='awaiting_observation'
                a=features.iloc[t]
                rows.append({'split':split,'t':t,'anchor_year':a.Year,'anchor_week':a.Week,
                    'anchor_from':a.From,'anchor_to':a.To_corrected,'issue_at':a.issue_at,
                    'horizon':h,**target_dates(features,t,h),'n_train':len(tr),'status':reason,
                    'clinical_available':bool(a.clinical_complete),'paired_available':bool(a.paired_complete),
                    'train_last_target':features.iloc[tr[-1]+h].week_key if len(tr) else '',
                    'train_anchor_keys':'|'.join(features.iloc[tr].week_key)})
    return pd.DataFrame(rows)

def delay_manifest(df,config):
    rows=[]
    days=sorted(set([config['timing']['nominal_issue_days_after_week_end']]+config['timing']['delay_sensitivity_days']+[8]))
    for t,a in df.iterrows():
        for h in (1,2):
            dates=target_dates(df,t,h)
            for delay in days:
                issue=(a.To_corrected+pd.Timedelta(days=delay,hours=23,minutes=59)).tz_localize('Asia/Hong_Kong')
                next_start=a.From+pd.Timedelta(weeks=1)
                while next_start.tz_localize('Asia/Hong_Kong')<=issue: next_start+=pd.Timedelta(weeks=1)
                dynamic_h=int((next_start-a.From).days//7)
                rows.append({'anchor_year':a.Year,'anchor_week':a.Week,'anchor_from':a.From,'anchor_to':a.To_corrected,
                    'horizon':h,**dates,'delay_days':delay,'issue_at':issue,
                    'target_started':dates['target_from'].tz_localize('Asia/Hong_Kong')<=issue,
                    'next_future_from':next_start,'next_future_horizon':dynamic_h,
                    'dynamic_prediction_available':dynamic_h in (1,2),
                    'timing_only_same_information_set':True,'scenario':'extra_timing_example' if delay==8 else 'prespecified_sensitivity'})
    return pd.DataFrame(rows)
