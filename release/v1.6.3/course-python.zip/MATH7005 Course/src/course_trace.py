"""Read saved model evidence and reproduce one origin through the main pipeline.

This module does not select parameters, write outputs or implement another model.
The saved model state describes the original fit. A requested reproduction uses
the frozen parameters and the recorded issue time, including for unscored rows.
"""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd

from .backtest import MODEL_IDS, predict_origin, validate_frozen
from .data import load_snapshot
from .features import build_features


def checked_origin(rows: pd.DataFrame) -> pd.DataFrame:
    """Require one unambiguous origin with exactly the three compared models."""
    if rows.empty or set(rows.model_id) != set(MODEL_IDS) or rows.model_id.duplicated().any():
        raise ValueError("The origin must contain one record for each of the three models")
    for field in ("split", "horizon", "anchor_from", "target_from", "issue_at", "source_version"):
        if rows[field].isna().any() or rows[field].astype(str).nunique() != 1:
            raise ValueError(f"The origin has inconsistent {field}")
    return rows


def saved_feature_evidence(rows: pd.DataFrame, model_id: str) -> pd.DataFrame:
    """Expose the recorded query vector and training-only scaling parameters."""
    checked_origin(rows)
    if model_id not in MODEL_IDS[1:]:
        raise ValueError("Feature evidence is available for the two Ridge models")
    row = rows.loc[rows.model_id == model_id].iloc[0]
    columns = row.feature_set.split("|")
    query = np.asarray(json.loads(row.query_features), dtype=float)
    state = json.loads(row.model_state)
    mean, scale, coef = (np.asarray(state[k], dtype=float) for k in ("mean", "scale", "coef"))
    if any(x.shape != (len(columns),) for x in (query, mean, scale, coef)):
        raise ValueError("Recorded feature and model-state dimensions disagree")
    if not np.isfinite(np.r_[query, mean, scale, coef]).all() or (scale <= 0).any():
        raise ValueError("Recorded feature state must be finite with positive scales")
    return pd.DataFrame({"feature": columns, "query_value": query, "training_mean": mean,
                         "training_sd": scale, "standardized_query": (query - mean) / scale,
                         "coefficient": coef})


def lag_observations(clean: pd.DataFrame, rows: pd.DataFrame, lags) -> pd.DataFrame:
    """Select source observations by calendar dates, never by filtered row offsets."""
    checked_origin(rows)
    anchor = pd.Timestamp(rows.iloc[0].anchor_from)
    dates = pd.to_datetime(clean.From)
    if dates.duplicated().any():
        raise ValueError("Duplicate observation date")
    records = []
    for lag in lags:
        date = anchor - pd.Timedelta(weeks=lag)
        matched = clean.loc[dates == date]
        if len(matched) != 1:
            raise ValueError(f"Missing source week for lag {lag}")
        row = matched.iloc[0]
        records.append({"lag_weeks": lag, "week_key": row.week_key, "from": date,
                        "clinical_proportion": row.SARSCoV2_proportion,
                        "wastewater_copy_per_l": row.Sewage_viralload})
    return pd.DataFrame(records)


def reproduce_origin(root: Path, config: dict, rows: pd.DataFrame, frozen: dict) -> pd.DataFrame:
    """Run the existing predictor without tuning, clock changes or filesystem writes."""
    rows = checked_origin(rows)
    reference = rows.iloc[0]
    clean = load_snapshot(Path(root) / config["data"]["csv"], config, project_root=root)
    features = build_features(clean, config["forecast"]["lags"])
    validate_frozen(features, config, frozen)
    matches = np.flatnonzero(features.From == pd.Timestamp(reference.anchor_from))
    if len(matches) != 1:
        raise ValueError("The saved origin is absent from the frozen input")
    if reference.source_version != features.iloc[matches[0]].source_version:
        raise ValueError("The saved origin uses a different input version")
    rebuilt = pd.DataFrame(predict_origin(features, int(matches[0]), int(reference.horizon),
        frozen["parameters"], config, split=reference.split, run_id=reference.run_id,
        issue_at_override=reference.issue_at))
    checked_origin(rebuilt)
    output = []
    for model in MODEL_IDS:
        old = rows.loc[rows.model_id == model].iloc[0]
        new = rebuilt.loc[rebuilt.model_id == model].iloc[0]
        same = np.allclose([old.raw_prediction, old.prediction, old.observed],
                           [new.raw_prediction, new.prediction, new.observed],
                           rtol=1e-10, atol=1e-12, equal_nan=True)
        same = bool(same and old.train_anchor_keys == new.train_anchor_keys
                    and int(old.n_train) == int(new.n_train))
        output.append({"model_id": model, "saved_raw_prediction": old.raw_prediction,
                       "recomputed_raw_prediction": new.raw_prediction,
                       "saved_prediction": old.prediction, "recomputed_prediction": new.prediction,
                       "observed": new.observed, "absolute_difference": abs(old.raw_prediction - new.raw_prediction),
                       "n_train": int(new.n_train), "matches_saved": same})
    return pd.DataFrame(output)
