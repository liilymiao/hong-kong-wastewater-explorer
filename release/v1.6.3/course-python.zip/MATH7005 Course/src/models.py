"""Small, explainable NumPy implementations. No estimator-library model calls."""
import numpy as np

class Standardizer:
    def fit(self,X):
        X=np.asarray(X,dtype=float)
        if X.ndim!=2 or not X.shape[0] or not X.shape[1] or not np.isfinite(X).all():raise ValueError('Nonempty finite two-dimensional X required')
        self.mean_=X.mean(axis=0)
        self.scale_=X.std(axis=0,ddof=0)
        self.zero_variance_=self.scale_==0
        self.scale_=np.where(self.zero_variance_,1.,self.scale_)
        return self
    def transform(self,X):
        X=np.asarray(X,dtype=float)
        if not hasattr(self,'mean_'):raise ValueError('Standardizer has not been fitted')
        if X.ndim!=2 or X.shape[1]!=len(self.mean_) or not np.isfinite(X).all():raise ValueError('Finite X with the fitted feature count required')
        return (X-self.mean_)/self.scale_
    def fit_transform(self,X):return self.fit(X).transform(X)

class RidgeRegressor:
    def __init__(self,alpha=0.01):
        if not np.isfinite(alpha) or alpha<0:raise ValueError('Finite nonnegative lambda required')
        self.alpha=float(alpha)
    def fit(self,X,y):
        X=np.asarray(X,dtype=float);y=np.asarray(y,dtype=float)
        if X.ndim!=2 or y.ndim!=1 or len(X)!=len(y) or not len(y) or not np.isfinite(y).all():raise ValueError('Invalid target or feature shape')
        self.standardizer_=Standardizer()
        Z=self.standardizer_.fit_transform(X)
        self.intercept_=float(y.mean());self.n_train_=len(y)
        # Z is n by d. The objective is mean squared loss + lambda * ||beta||².
        # The normal equations therefore use n*lambda, with no penalty on the intercept.
        self.coef_=np.linalg.solve(Z.T@Z+len(y)*self.alpha*np.eye(Z.shape[1]),Z.T@(y-self.intercept_))
        residual=y-self.predict(X)
        self.loss_=float(np.mean(residual**2)+self.alpha*np.dot(self.coef_,self.coef_))
        return self
    def predict(self,X):return self.standardizer_.transform(X)@self.coef_+self.intercept_
    def state(self):
        return {'mean':self.standardizer_.mean_.tolist(),'scale':self.standardizer_.scale_.tolist(),
                'coef':self.coef_.tolist(),'intercept':self.intercept_,'lambda':self.alpha,
                'zero_variance_columns':np.flatnonzero(self.standardizer_.zero_variance_).tolist(),
                'loss':self.loss_,'n_train':self.n_train_}

class Persistence:
    def predict(self,last_observed,horizon=1):return float(last_observed)
