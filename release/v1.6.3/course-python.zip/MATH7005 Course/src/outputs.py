"""Generate the English course report from the sealed analysis tables.

This module only presents saved results. Model fitting and scoring remain in
backtest.py; report diagnostics are explicitly labelled post hoc.
"""
from pathlib import Path
from html import escape
import json
import numpy as np
import pandas as pd
import plotly.graph_objects as go

NAMES = {'persistence': 'Persistence', 'clinical_ridge': 'Clinical Ridge',
         'combined_ridge': 'Clinical + wastewater Ridge'}
SOFTWARE_VERSION = '1.5.3'


def table_md(df):
    def fmt(value):
        return '' if pd.isna(value) else (f'{value:.4f}' if isinstance(value, float) else str(value))
    headers = list(df.columns)
    return '\n'.join(['| ' + ' | '.join(headers) + ' |', '|' + '|'.join(['---'] * len(headers)) + '|']
                     + ['| ' + ' | '.join(fmt(v) for v in row) + ' |' for row in df.itertuples(index=False, name=None)])


def table_html(df):
    return df.to_html(index=False, border=0, classes='result-table',
                      float_format=lambda x: f'{x:.4f}', na_rep='')


def interval_text(low, high):
    if not np.isfinite([low, high]).all():
        return 'unavailable (see the interval status)'
    relation = 'includes zero' if low <= 0 <= high else ('above zero' if low > 0 else 'below zero')
    return f'[{low:.4f}, {high:.4f}] pp ({relation})'


def week_range(config, split):
    spec = config['split'][split + '_origin_week_range']
    return f"{config['split'][split + '_origin_year']}W{spec['start_week']}-W{spec['end_week']}"


def course_evidence():
    """Exact callable and test names; tests are evidence only when executed."""
    return pd.DataFrame([
        ['Python and configuration', 'src/configuration.py: validate_config; src/pipeline.py: preflight', 'test_pipeline_review.py: test_unsupported_settings_fail_before_analysis'],
        ['NumPy and Ridge', 'src/models.py: Standardizer.fit, RidgeRegressor.fit/predict/state', 'test_acceptance.py: test_ridge_matches_independent_augmented_least_squares_and_nlambda'],
        ['Pandas and calendar', 'src/data.py: load_snapshot, validate_week_index; src/features.py: build_features', 'test_acceptance.py: test_zero_sewage_is_preserved_and_missing_spreads_to_three_anchors'],
        ['Time and model evaluation', 'src/features.py: eligible_training_rows; src/backtest.py: predict_origin, paired_evaluate', 'test_acceptance.py: test_future_perturbation_leaves_all_past_prediction_inputs_and_states_exact'],
        ['Clustering', 'src/patterns.py: KMeans._initialize/_assign/fit; silhouette_score, adjusted_rand_score', 'test_patterns.py: test_kmeans_assignments_centers_and_reproducibility'],
        ['Anomaly extension', 'src/patterns.py: LOFNovelty.fit/query_details/score_samples', 'test_patterns.py: test_lof_manual_distance_density_and_novelty_score'],
    ], columns=['Course skill', 'Implementation', 'Executable evidence (tests/)'])


def export_report(root, config):
    root = Path(root); out = root / config['output']['directory']
    read = lambda name: pd.read_csv(out / name)
    pred, metrics, raw_metrics = read('predictions.csv'), read('metrics.csv'), read('raw_metrics.csv')
    ci, raw_ci = read('bootstrap_sensitivity.csv'), read('raw_bootstrap_sensitivity.csv')
    patterns = read('patterns.csv')
    pconfig = json.loads((out / 'pattern_config.json').read_text(encoding='utf-8'))
    frozen = json.loads((out / 'frozen_config.json').read_text(encoding='utf-8'))
    quality = json.loads((out / 'data_quality.json').read_text(encoding='utf-8'))
    clean = pd.read_csv(root / 'data/processed/clean.csv')
    hmain = config['forecast']['primary_horizon']
    evaluation = config['evaluation']; confidence = evaluation['bootstrap_confidence_level'] * 100
    block = evaluation['bootstrap_block_weeks']; snapshot = config['project']['snapshot_date_hkt']
    test, raw_test = metrics[metrics.split == 'test'], raw_metrics[raw_metrics.split == 'test']
    def score(frame, model):
        rows = frame[(frame.horizon == hmain) & (frame.model_id == model)]
        if len(rows) != 1: raise ValueError(f'Missing or duplicated metric: h={hmain}, {model}')
        return rows.iloc[0]
    clinical, combined = score(test, 'clinical_ridge'), score(test, 'combined_ridge')
    raw_c, raw_j = score(raw_test, 'clinical_ridge'), score(raw_test, 'combined_ridge')
    selected = pred[(pred.split == 'test') & (pred.horizon == hmain)]
    joined = selected[selected.model_id == 'combined_ridge']
    below, above = int((joined.raw_prediction < 0).sum()), int((joined.raw_prediction > 1).sum())
    results = []
    for mode, frame in [('Limited to 0-100%', test), ('Original', raw_test)]:
        part = frame[['horizon', 'model_id', 'n_origins', 'mae_pp', 'rmse_pp']].copy()
        part.insert(0, 'Prediction values', mode); part.model_id = part.model_id.map(NAMES); results.append(part)
    results = pd.concat(results).rename(columns={'horizon':'h','model_id':'Model','n_origins':'Weeks','mae_pp':'MAE (pp)','rmse_pp':'RMSE (pp)'})
    blocks = pd.concat([ci[ci.split == 'test'], raw_ci[raw_ci.split == 'test']])[
        ['score_mode','horizon','block_weeks','n_origins','delta_mae_pp','low','high','status']].rename(columns={
        'score_mode':'Values','horizon':'h','block_weeks':'Block (weeks)','n_origins':'Weeks',
        'delta_mae_pp':'Gain (pp)','low':'Lower (pp)','high':'Upper (pp)','status':'Status'})
    halves = []
    for mode, name in [('clipped','paired_errors.csv'),('raw','raw_paired_errors.csv')]:
        rows = read(name); rows = rows[(rows.split == 'test') & (rows.horizon == hmain)].sort_values('anchor_from')
        middle = len(rows)//2
        for label, part in [('First half', rows.iloc[:middle]), ('Second half', rows.iloc[middle:])]:
            halves.append([mode,label,len(part),part.clinical_abs_error_pp.mean(),part.combined_abs_error_pp.mean(),part.delta_error_pp.mean()])
    halves = pd.DataFrame(halves, columns=['Values','Post-hoc period','Weeks','Clinical MAE (pp)','Combined MAE (pp)','Gain (pp)'])
    valid = patterns[patterns.status == 'ok']
    top = valid[valid.period == 'final_test_replay'].sort_values('lof_score',ascending=False).head(5)[
        ['week_key','lof_score','SARSCoV2_proportion','Sewage_viralload','reference_end']].copy()
    top.SARSCoV2_proportion *= 100
    top.columns = ['Query week','LOF','Clinical (%)','Wastewater (copy/L)','Reference ends']
    parameters = ', '.join(f'{NAMES[m]}, h{h}, lambda={a:g}' for m, hs in frozen['parameters'].items() for h,a in sorted(hs.items()))
    sections = [
        ('1. Research question and users', [
            'Can wastewater improve forecasts of clinical specimen positivity once recent clinical history is already known? This product supports Hong Kong wastewater epidemiology researchers and public-health surveillance analysts. They can examine aligned signals, trace a historical forecast, compare three models on common weeks, inspect unusual combinations and export the underlying records.',
            f'The analysis uses the {snapshot} frozen COVID-19 Express snapshot. In {week_range(config,"test")}, the h{hmain} clinical and combined models have MAE {clinical.mae_pp:.4f} and {combined.mae_pp:.4f} percentage points (pp) over {int(combined.n_origins)} common origins with predictions limited to 0-100%. The paired gain is {combined.delta_mae_pp:.4f} pp. In this frozen evaluation, wastewater reduces some prediction errors; the size and stability of the improvement depend on output constraints and evaluation period.'
        ]),
        ('2. Data, target and time', [
            f'The main dataset is the Department of Health COVID-19 Express weekly CSV listed on DATA.GOV.HK. It contains {quality["valid_rows"]} valid weeks and {quality["columns"]} original fields, from {clean.week_key.iloc[0]} to {clean.week_key.iloc[-1]}. Each row represents one Hong Kong monitoring week. There are {quality["sewage_valid_rows"]} wastewater observations; {", ".join(quality["sewage_missing"])} remain missing. The parser removes {len(quality["blank_source_rows"])} entirely blank trailing rows.',
            'The target SARSCoV2_proportion is the SARS-CoV-2 positive proportion among respiratory specimens received by PHLSB. It is stored on a 0-1 scale and displayed as %. It is not population infection prevalence. The wastewater field retains the official label Per capita viral load (7-day geometric mean) and reported unit copy/L; the analysis does not divide it by population again. Counts from another surveillance series are not used to reconstruct the missing specimen denominator.',
            'Raw bytes, acquisition metadata and hashes remain in data/source_catalog.json. The exact 2026W6 To-date error is corrected from 07/01/2026 to 07/02/2026 only when year, week, start date and original value all match the recorded rule. The original date and the official weekly-report reference are retained. Weekly continuity and unique keys are validated before lag features are created.',
            f'The latest complete observation week is t; h2 targets monitoring week t+2 and h1 targets t+1. The nominal issue time is {config["timing"]["nominal_issue_days_after_week_end"]} days after the observation-week end at {config["timing"]["nominal_issue_time_hkt"]} Hong Kong time. Actual target dates and the interval from assumed issue time to target start are displayed together. Delay scenarios change this timing calculation while retaining the same frozen inputs. Historical first-publication times have not been reconstructed.'
        ]),
        ('3. Features and NumPy implementation', [
            'The clinical vector is [p(t), p(t-1), p(t-2)]. The combined vector appends log(1+w) at the same lags. Zero wastewater is valid; missing wastewater remains missing and propagates to the dependent lag vectors. Both Ridge models use the same complete training rows. A missing week cannot be deleted and treated as if its two neighbours were consecutive.',
            'For n eligible training rows and d features, X has shape (n,d), y has shape (n,), and the query has shape (1,d). Standardizer.fit learns each column mean and population standard deviation from those training rows only. A constant column receives scale 1. The standardized matrix Z and centred response yc=y-mean(y) define J(beta)=mean((yc-Z beta)^2)+lambda*sum(beta^2).',
            'RidgeRegressor.fit solves (Z^T Z+n*lambda*I) beta=Z^T yc using numpy.linalg.solve. The n multiplier follows from the mean-squared-loss objective. The target mean restores an unpenalized intercept; it is not a penalized feature. Prediction is ((x-mean)/scale) beta+mean(y). The saved model_state contains means, scales, coefficients, intercept, lambda, loss, zero-variance columns and training count. NumPy provides the linear-system primitive; feature construction, standardization, model formulation and evaluation are implemented in this project.',
            'Persistence predicts the most recent clinical proportion p(t). It provides a low-complexity benchmark for whether either fitted model adds value. Raw predictions and predictions limited to [0,1] are both stored; switching the scoring view changes which stored prediction is scored, without fitting a new model.',
            course_evidence()
        ]),
        ('4. Validation and evaluation design', [
            f'The first {config["split"]["warmup_weeks"]} calendar weeks provide development warm-up. Validation origins are {week_range(config,"validation")}; test origins are {week_range(config,"test")}. At each origin an expanding window supplies at least {config["forecast"]["minimum_training_rows"]} complete paired training rows. A training anchor s must satisfy s+h<=t, with both its features and target available no later than the forecast issue time. Unknown availability is treated as unavailable.',
            f'The fixed candidate grid is {config["models"]["ridge_lambdas"]}. Each model and horizon selects its validation MAE minimum, choosing the larger lambda within {frozen["tie_tolerance_pp"]:g} pp of a tie. Selected parameters: {parameters}. Their latest development-evidence availability is {frozen["frozen_available_at"]}, before the first test issue time {frozen["first_test_issue_at"]}. The 2026 outcomes did not select new parameters in this revision.',
            'Evaluation matches origin, target, horizon, issue time, source version, evaluation vintage and mode across all three models. Inconsistent labels and duplicate keys are rejected by the Python evaluator. MAE is 100*mean(abs(observed-predicted)); RMSE is 100*sqrt(mean((observed-predicted)^2)). Gain is clinical MAE minus combined MAE, so positive gain favours the combined model. Missing observations do not enter evaluation; paired_set_id identifies the matched weeks.',
            'The temporal tests perturb future data with parameters held fixed, delay training labels and features, retain missing calendar weeks, check training-only standardization, and compare common evaluation sets. Pattern tests similarly exclude the query from its reference fit. Executable names are provided in the implementation table; current execution results and exclusions are recorded separately in STATUS.md.'
        ]),
        ('5. Results and uncertainty', [results,
            f'At h{hmain}, original clinical and combined MAE are {raw_c.mae_pp:.4f} and {raw_j.mae_pp:.4f} pp, giving {raw_j.delta_mae_pp:.4f} pp gain. The combined model has {below}/{len(joined)} original predictions below zero and {above}/{len(joined)} above one. Limiting predictions changes the loss on these records and therefore changes the estimated gain.',
            f'The primary {block}-week block interval is {interval_text(combined.delta_ci_low_pp,combined.delta_ci_high_pp)}. Moving-block bootstrap resamples paired weekly error differences with seed {evaluation["seed"]}, {evaluation["bootstrap_repeats"]} repetitions and {confidence:g}% central empirical intervals. Blocks are built only within continuous calendar segments. If a participating week is not covered by a complete block, the interval is unavailable while the all-week point estimate is retained. The interval describes mean paired gain, not an individual forecast range.',blocks,
            'The following half-period comparison is a post-hoc description of the same test records. It shows where gains occurred and does not provide an independent confirmation period or a new model-selection criterion.',halves
        ]),
        ('6. Patterns and anomalies', [
            f'States contain clinical level, two-week clinical change, log1p wastewater level and its two-week change. Development selection considered k={config["patterns"]["kmeans_candidates"]} on {pconfig["selection_complete_states"]} complete states from the first {pconfig["selection_calendar_weeks"]} calendar weeks and selected k={pconfig["cluster_k"]}. The score equally weights silhouette and adjusted-Rand agreement after omitting consecutive blocks of state-vector anchor rows. Retained vectors keep their original lag inputs, so this stability calculation is descriptive.',
            f'KMeans uses k-means++ initialization, Euclidean nearest-centre assignment, cluster-mean updates and {pconfig["kmeans_initializations"]} restarts. Empty clusters receive a farthest eligible point from a cluster containing at least two rows. Fewer distinct points than clusters are rejected. The best inertia is retained; final labels are reassigned and convergence and effective cluster counts are recorded. A query uses up to {pconfig["reference_window_weeks"]} preceding calendar weeks with at least {pconfig["minimum_reference_rows"]} complete states. Reference-only standardization prevents the query or future rows changing that fit.',
            f'LOF uses {pconfig["lof_primary_neighbors"]} neighbours, with {pconfig["lof_neighbors"]} compared for sensitivity. For reference neighbour o, reachability distance is max(k-distance(o),distance(query,o)); local reachability density is the inverse mean reachability distance. The novelty score averages reference-neighbour density divided by query density. Reference points exclude themselves, ties use stable row order and fixed k, and a 1e-12 floor stabilizes zero distances. Query points do not refit reference densities.',
            'A high LOF score identifies a signal combination uncommon relative to the historical reference. It can occur at low signal levels and is not an outbreak probability. Centre names describe that window, while the query values show its actual direction. The table is a retrospective ranking of test queries; each score still uses only its preceding reference window.',top
        ]),
        ('7. Product, reproduction and scope', [
            'The Python Course demo connects the research question, monitoring data, a real historical origin, model comparison, patterns and exports. Reproduce this origin calls predict_origin with the saved fixed parameters and reports the difference from frozen predictions. Input lags, model state, eligible training rows, target dates and observed outcomes can be inspected in the running product.',
            'Install Python 3.12 dependencies from requirements.lock.txt, then run python -m src.pipeline --config config.yaml --stage all in an independent directory. The pipeline writes phase receipts and an artifact manifest; a changed input, configuration or numerical code file is rejected before old results can be reused. Reference CSVs are in saved_results/. README.md and Start.md distinguish installing dependencies from offline operation. The course package contains Python source and locally generated results; the separate JavaScript website retains the broader research-data tools.',
            'The frozen full table may include later revisions. Nominal availability constraints make this a frozen retrospective evaluation, not a reconstruction of all historical information releases. The short test period, output constraints and concentration of gains affect generalization. Site-level catchments, clinical weekly denominators, flow and a full archive of first releases are unavailable in the modelling table. New-period confirmation, true as-of validation and researcher task testing remain future work. AMR and ARG queries are separate data-discovery capabilities, with no new wastewater-to-AMR prediction model in this course analysis.'
        ]),
        ('8. AI assistance and contribution record', [
            'OpenAI Codex assisted with Python and NumPy implementation, debugging, tests, report generation, bilingual interface work and this reproducibility revision. The user supplied the research plan, data handovers and review priorities. Synthetic inputs are used only for software tests. The main tables are generated from the packaged government snapshot. Test execution is recorded as agent-executed work; independent student review, derivations, narration and user testing are not asserted. The dated declaration and the remaining personal-confirmation items are in AI使用声明.md and Course.md.'
        ])
    ]
    title = 'The Incremental Predictive Value of Hong Kong Wastewater Surveillance'
    subtitle = f'Frozen snapshot {snapshot}; scientific configuration {config["project"]["version"]}; Python {SOFTWARE_VERSION}'
    md = [f'# {title}', subtitle]
    html = [f'<header><p>MATH7005</p><h1>{escape(title)}</h1><p>{escape(subtitle)}</p></header>']
    for heading, items in sections:
        md.extend(['', f'## {heading}', '']); html.append(f'<section><h2>{escape(heading)}</h2>')
        for item in items:
            if isinstance(item, pd.DataFrame): md.extend([table_md(item),'']); html.append(table_html(item))
            else: md.extend([item,'']); html.append(f'<p>{escape(item)}</p>')
        html.append('</section>')
    sources = [
        ('DATA.GOV.HK COVID-19 Express','https://data.gov.hk/en-data/dataset/hk-dh-chpsebcddr-covid-express'),
        ('Official data dictionary','https://www.chp.gov.hk/files/pdf/covidx_spec_en.pdf'),
        ('2026W42 report','https://www.chp.gov.hk/files/pdf/covid_flux_week42_22_10_2026_eng.pdf'),
        ('2026W6 date reference','https://www.chp.gov.hk/files/pdf/covid_flux_week6_12_2_2026_eng.pdf'),
        ('NumPy linear-system solve','https://numpy.org/doc/stable/reference/generated/numpy.linalg.solve.html'),
        ('Rolling-origin evaluation','https://otexts.com/fpp3/toolbox.html#time-series-cross-validation'),
        ('Preprocessing and leakage','https://scikit-learn.org/stable/common_pitfalls.html'),
        ('Predictions','predictions.csv'),('Limited scores','metrics.csv'),('Original scores','raw_metrics.csv'),
        ('Block sensitivity','bootstrap_sensitivity.csv'),('Original block sensitivity','raw_bootstrap_sensitivity.csv'),
        ('Source records','../data/source_catalog.json'),('Course and demonstration','../Course.md'),('Run record','../STATUS.md'),
        ('AI declaration','../AI使用声明.md')]
    scope = 'Course requirements follow the supplied handoff and saved notices. Original course documents remain in the internal evidence archive; Course.md identifies the supplied dates and outstanding personal confirmations.'
    md.extend(['## References and result files','']+[f'- [{name}]({url})' for name,url in sources]+['',scope])
    html.append('<section><h2>References and result files</h2><ul>'+''.join(f'<li><a href="{escape(url)}">{escape(name)}</a></li>' for name,url in sources)+'</ul><p>'+escape(scope)+'</p></section>')
    base=selected[selected.model_id=='clinical_ridge'].sort_values('target_from')
    if not base.empty:
        timeline=pd.date_range(pd.to_datetime(base.target_from).min(),pd.to_datetime(base.target_from).max(),freq='7D')
        fig=go.Figure()
        def add_line(frame,column,name,color):
            indexed=frame.assign(target_from=pd.to_datetime(frame.target_from)).set_index('target_from').reindex(timeline)
            fig.add_trace(go.Scatter(x=timeline,y=indexed[column]*100,name=name,connectgaps=False,line=dict(color=color)))
        add_line(base,'observed','Observed','#142c43')
        for model,color in [('clinical_ridge','#bf7b39'),('combined_ridge','#1b8077')]:add_line(selected[selected.model_id==model],'prediction',NAMES[model],color)
        fig.update_layout(title=f'h{hmain} test forecasts (limited to 0-100%)',template='plotly_white',height=430,
            yaxis_title='Clinical specimen positivity (%)',xaxis_title='Target week starts',legend=dict(orientation='h'))
        html.insert(2,fig.to_html(full_html=False,include_plotlyjs=True,div_id='test-predictions',config={'displaylogo':False,'responsive':True}))
    css='body{font-family:Arial,sans-serif;color:#203243;line-height:1.65;margin:0;background:#f4f8fa}main{max-width:1080px;margin:auto;padding:48px;background:white}h1{font-size:30px;line-height:1.25}h2{margin-top:32px}table{border-collapse:collapse;width:100%;font-size:13px}td,th{border:1px solid #dce3e8;padding:8px;text-align:left;overflow-wrap:anywhere}th{background:#eef5f8}a{color:#266178}@media print{main{padding:0}tr{break-inside:avoid}h2{break-after:avoid}.modebar{display:none}}'
    (out/'项目报告.md').write_text('\n'.join(md)+'\n',encoding='utf-8')
    (out/'项目报告.html').write_text('<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>'+escape(title)+'</title><style>'+css+'</style></head><body><main>'+''.join(html)+'</main></body></html>',encoding='utf-8')
    print(json.dumps({'report_html':str(out/'项目报告.html'),'report_markdown':str(out/'项目报告.md')},ensure_ascii=False))
