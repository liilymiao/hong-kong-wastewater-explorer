"""Leakage-aware rolling joint-state clustering and LOF outputs.

The actual run occurs on the frozen snapshot. ``selection_available_at`` is
the nominal availability of the last development input, not a claim that this
configuration or the full snapshot existed at that historical instant.
"""

from __future__ import annotations

import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd

from .patterns import (KMeans, LOFNovelty, Standardizer, adjusted_rand_score,
                       silhouette_score)


STATE_FEATURES = ["p", "p_change_2w", "log1p_w", "log1p_w_change_2w"]

# These descriptions clarify the existing computation; they do not change
# which state rows are removed, how candidates are scored, or the selected k.
_SELECTION_RULE = ("0.5*silhouette + 0.5*mean_contiguous_state_vector_block_leave_out_ARI; "
                   "ties within 1e-12 select smaller k")
_STABILITY_RULE = ("five contiguous blocks of development state-vector anchor rows; "
                   "omit each block, retain lag inputs of remaining state vectors, "
                   "refit scaler and kmeans; compare partitions on all development "
                   "state vectors using adjusted Rand index; not independent "
                   "temporal validation")
_LEGACY_RULE_DESCRIPTIONS = {
    "selection_rule": ("0.5*silhouette + 0.5*mean_contiguous_block_leave_out_ARI; "
                       "ties within 1e-12 select smaller k"),
    "stability_rule": ("five contiguous calendar blocks; omit each block, "
                       "refit scaler and kmeans; compare partitions on all "
                       "development rows using adjusted Rand index"),
}


def _json_write(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2,
                                    allow_nan=False), encoding="utf-8")


def _issue_at(row, config):
    if "issue_at" in row and pd.notna(row["issue_at"]):
        value = pd.Timestamp(row["issue_at"])
        if value.tzinfo is None:
            value = value.tz_localize(config["project"]["timezone"])
        return value
    timing = config["timing"]
    hours, minutes = map(int, timing["nominal_issue_time_hkt"].split(":"))
    value = pd.Timestamp(row["To_corrected"]).normalize()
    value += pd.Timedelta(days=timing["nominal_issue_days_after_week_end"],
                          hours=hours, minutes=minutes)
    return value.tz_localize(config["project"]["timezone"])


def build_state_features(clean_df, config):
    """Use exact calendar t-2 matches; a missing week cannot shorten the lag."""
    frame = clean_df.copy().reset_index(drop=True)
    frame["From"] = pd.to_datetime(frame["From"])
    if not frame["From"].is_unique or not frame["From"].is_monotonic_increasing:
        raise ValueError("State rows must have unique, increasing From dates")
    p = pd.to_numeric(frame[config["data"]["target"]], errors="coerce")
    w = pd.to_numeric(frame[config["data"]["sewage"]], errors="coerce")
    p = p.where((p >= 0) & (p <= 1))
    w = w.where(w >= 0)
    frame["p"] = p
    frame["log1p_w"] = np.log1p(w)
    earlier = frame["From"] - pd.Timedelta(weeks=2)
    for raw, change in [("p", "p_change_2w"),
                        ("log1p_w", "log1p_w_change_2w")]:
        lookup = pd.Series(frame[raw].to_numpy(), index=frame["From"])
        frame[change] = frame[raw] - earlier.map(lookup).to_numpy()
    frame["state_valid"] = np.isfinite(frame[STATE_FEATURES]).all(axis=1)
    return frame


def _parameters(config):
    p = config["patterns"]
    if p.get("reference_end_offset_weeks", 1) != 1:
        raise ValueError("Only a reference window ending at t-1 is supported")
    if not p.get("score_queries_as_novelty", True):
        raise ValueError("Rolling state outputs require novelty scoring")
    return {"seed": int(config["evaluation"]["seed"]),
            "n_init": int(p["kmeans_initializations"]),
            "max_iter": int(p["kmeans_max_iterations"])}


def _config_signature(config):
    """Only inputs affecting pattern selection, timing, or replay semantics."""
    payload = {"patterns": config["patterns"],
               "warmup_weeks": config["split"]["warmup_weeks"],
               "validation_origin_year": config["split"]["validation_origin_year"],
               "test_origin_year": config["split"]["test_origin_year"],
               "test_origin_week_range": config["split"]["test_origin_week_range"],
               "timezone": config["project"]["timezone"],
               "nominal_issue_time_hkt": config["timing"]["nominal_issue_time_hkt"],
               "nominal_issue_days_after_week_end": config["timing"]["nominal_issue_days_after_week_end"],
               "target": config["data"]["target"], "sewage": config["data"]["sewage"],
               "seed": config["evaluation"]["seed"], "state_features": STATE_FEATURES}
    digest = hashlib.sha256(json.dumps(payload, sort_keys=True, separators=(",", ":"),
                                      ensure_ascii=False).encode("utf-8")).hexdigest()
    return payload, digest


def _kmeans(k, params):
    return KMeans(n_clusters=k, n_init=params["n_init"],
                  max_iter=params["max_iter"], random_state=params["seed"])


def _selection_states_hash(development):
    """Fingerprint the exact state values and week keys used for selection."""
    return hashlib.sha256(
        "|".join(development["week_key"].astype(str)).encode("utf-8")
        + development[STATE_FEATURES].to_numpy(dtype="<f8").tobytes()).hexdigest()


def _selected_cluster_k(candidates):
    """Apply the existing frozen score/tie rule without fitting any model."""
    top = max(row["selection_score"] for row in candidates)
    return min(row["cluster_k"] for row in candidates
               if top - row["selection_score"] <= 1e-12)


def validate_pattern_frozen(clean_df, config, frozen):
    """Read-only check of configuration, development evidence and saved decision.

    Candidate scores are retained evidence, not recomputed or optimized here.
    The pipeline additionally checks the existing stage receipt when available
    to detect edits to this evidence. Return the checked state frame for replay.
    """
    if not isinstance(frozen, dict) or frozen.get("schema_version") != 1:
        raise ValueError("Unsupported frozen pattern configuration")
    protected, signature = _config_signature(config)
    if (frozen.get("configuration_sha256") != signature
            or frozen.get("protected_configuration") != protected):
        raise ValueError("Pattern configuration changed after freezing; revalidate "
                         "in a new output directory")
    frame = build_state_features(clean_df, config)
    count = config["split"]["warmup_weeks"]
    if (frozen.get("selection_calendar_weeks") != count or len(frame) < count
            or _selection_states_hash(frame.iloc[:count])
            != frozen.get("selection_states_sha256")):
        raise ValueError("Pattern development states changed after freezing; "
                         "revalidate in a new output directory")
    development = frame.iloc[:count]
    first, last = development.iloc[0], development.iloc[-1]
    complete = int(development["state_valid"].sum())
    expected = {
        "backtest_mode": "frozen_retrospective",
        "configuration_provenance": "retrospectively_created_from_development_only",
        "selection_data_start": str(first["week_key"]),
        "selection_data_end": str(last["week_key"]),
        "selection_data_end_from": pd.Timestamp(last["From"]).isoformat(),
        "selection_available_at": _issue_at(last, config).isoformat(),
        "selection_complete_states": complete,
        "selection_excluded_states": count - complete,
        "source_version": str(last.get("source_version", "")),
        "state_features": STATE_FEATURES,
        "seed": int(config["evaluation"]["seed"]),
        "lof_epsilon": 1e-12,
    }
    for key in ("lof_primary_neighbors", "lof_neighbors", "reference_window_weeks",
                "minimum_reference_rows", "kmeans_initializations", "kmeans_max_iterations"):
        expected[key] = config["patterns"][key]
    for key, value in expected.items():
        if frozen.get(key) != value:
            raise ValueError(f"Frozen pattern decision field changed: {key}; use a new output directory")
    for key, current in (("selection_rule", _SELECTION_RULE), ("stability_rule", _STABILITY_RULE)):
        if frozen.get(key) not in (current, _LEGACY_RULE_DESCRIPTIONS[key]):
            raise ValueError(f"Frozen pattern rule changed: {key}; use a new output directory")
    candidates = frozen.get("candidates")
    if not isinstance(candidates, list) or not candidates:
        raise ValueError("Incomplete frozen pattern candidate evidence")
    try:
        if [row["cluster_k"] for row in candidates] != config["patterns"]["kmeans_candidates"]:
            raise ValueError("Frozen pattern candidates differ from the configured candidates")
        for row in candidates:
            values = [row[name] for name in
                      ("silhouette", "block_stability_ari", "selection_score", "inertia")]
            if (not np.isfinite(values).all() or row["n_development"] != complete
                    or not np.isclose(row["selection_score"],
                                      (row["silhouette"] + row["block_stability_ari"]) / 2,
                                      rtol=1e-12, atol=1e-15)):
                raise ValueError("Inconsistent frozen pattern candidate scores")
        selected = _selected_cluster_k(candidates)
        if frozen.get("cluster_k") != selected or any(
                row["selected"] != (row["cluster_k"] == selected) for row in candidates):
            raise ValueError("Frozen pattern cluster decision changed; use a new output directory")
    except (KeyError, TypeError) as exc:
        raise ValueError("Incomplete frozen pattern candidate evidence") from exc
    return frame


def freeze_pattern_config(clean_df, config, out_dir):
    """Choose k only on the first 100 calendar weeks, then save the decision.

    For each k, silhouette uses the complete development reference. Stability
    is the mean adjusted Rand agreement against five refits, each omitting one
    contiguous block of state-vector anchor rows. Lag inputs for the retained
    vectors remain available, including those inside an omitted raw-data
    period. This is state-vector removal sensitivity, not independent temporal
    validation. Each refit learns its own scaler and predicts all development
    rows. The selection score is the unweighted mean of silhouette and
    stability; ties within 1e-12 choose smaller k. No 2025 or 2026 input is used
    with the supplied 100-week warm-up configuration.
    """
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    frame = build_state_features(clean_df, config)
    params = _parameters(config)
    count = int(config["split"]["warmup_weeks"])
    if len(frame) < count or count < 2:
        raise ValueError("Insufficient rows for the predefined pattern warm-up")
    dev = frame.iloc[:count].copy()
    # A changed warm-up setting must never silently extend into final testing.
    test_year = int(config["split"]["test_origin_year"])
    if (dev["From"].dt.year >= test_year).any():
        raise ValueError("Pattern selection cannot read final-test calendar data")
    valid = dev.loc[dev["state_valid"]]
    if len(valid) < int(config["patterns"]["minimum_reference_rows"]):
        raise ValueError("Insufficient complete development states")
    x = valid[STATE_FEATURES].to_numpy(float)
    scaler = Standardizer().fit(x)
    z = scaler.transform(x)
    blocks = np.array_split(np.arange(count), 5)
    rows = []
    for k in config["patterns"]["kmeans_candidates"]:
        model = _kmeans(int(k), params).fit(z)
        silhouette = silhouette_score(z, model.labels_)
        agreements = []
        fold_info = []
        for block_id, indices in enumerate(blocks):
            train = dev.loc[dev["state_valid"] & ~dev.index.isin(indices)]
            if len(train) < max(int(k) + 1, 2):
                continue
            fold_scaler = Standardizer().fit(train[STATE_FEATURES].to_numpy(float))
            fold_model = _kmeans(int(k), params).fit(
                fold_scaler.transform(train[STATE_FEATURES].to_numpy(float)))
            labels = fold_model.predict(fold_scaler.transform(x))
            agreement = adjusted_rand_score(model.labels_, labels)
            agreements.append(agreement)
            fold_info.append({"block": block_id + 1,
                              "omitted_start": str(dev.iloc[indices[0]]["week_key"]),
                              "omitted_end": str(dev.iloc[indices[-1]]["week_key"]),
                              "n_fit": len(train), "adjusted_rand": agreement})
        if not agreements or not np.isfinite(silhouette):
            raise ValueError("Pattern candidate cannot be evaluated")
        stability = float(np.mean(agreements))
        rows.append({"cluster_k": int(k), "n_development": len(valid),
                     "silhouette": silhouette, "block_stability_ari": stability,
                     "selection_score": (silhouette + stability) / 2,
                     "inertia": model.inertia_,
                     "block_scores": json.dumps(fold_info, ensure_ascii=False)})
    selected = _selected_cluster_k(rows)
    for row in rows:
        row["selected"] = row["cluster_k"] == selected
    first = dev.iloc[0]
    last = dev.iloc[-1]
    protected_inputs, signature = _config_signature(config)
    development_hash = _selection_states_hash(dev)
    frozen = {
        "schema_version": 1,
        "backtest_mode": "frozen_retrospective",
        "configuration_created_at_utc": pd.Timestamp.now(tz="UTC").isoformat(),
        "configuration_provenance": "retrospectively_created_from_development_only",
        "selection_data_start": str(first["week_key"]),
        "selection_data_end": str(last["week_key"]),
        "selection_data_end_from": pd.Timestamp(last["From"]).isoformat(),
        "selection_available_at": _issue_at(last, config).isoformat(),
        "selection_calendar_weeks": count,
        "selection_complete_states": len(valid),
        "selection_excluded_states": count - len(valid),
        "state_features": STATE_FEATURES,
        "cluster_k": selected,
        "lof_primary_neighbors": int(config["patterns"]["lof_primary_neighbors"]),
        "lof_neighbors": [int(k) for k in config["patterns"]["lof_neighbors"]],
        "reference_window_weeks": int(config["patterns"]["reference_window_weeks"]),
        "minimum_reference_rows": int(config["patterns"]["minimum_reference_rows"]),
        "seed": params["seed"], "kmeans_initializations": params["n_init"],
        "kmeans_max_iterations": params["max_iter"], "lof_epsilon": 1e-12,
        "selection_rule": _SELECTION_RULE,
        "stability_rule": _STABILITY_RULE,
        "neighbor_tie_rule": "fixed_k_stable_reference_row_order_exclude_self",
        "label_rule": "clinical/sewage levels relative to reference means; "
                      "change signs use the raw two-week center differences",
        "ranking_rule": "descending score; tied scores share rank; "
                        "top-N boundary ties use week_key order; "
                        "rankings are descriptive across completed queries",
        "historical_interpretation": "2025 is development/validation replay; "
                                     "configuration was created retrospectively, "
                                     "not demonstrated to be frozen in 2025",
        "source_version": str(last.get("source_version", "")),
        "protected_configuration": protected_inputs,
        "configuration_sha256": signature,
        "selection_states_sha256": development_hash,
        "candidates": rows,
    }
    paths = {"config_json": out_dir / "pattern_config.json",
             "selection_csv": out_dir / "pattern_selection.csv",
             "selection_json": out_dir / "pattern_selection.json"}
    validate_pattern_frozen(clean_df, config, frozen)
    if paths["config_json"].exists():
        existing = json.loads(paths["config_json"].read_text(encoding="utf-8"))
        # A provenance-only upgrade supports files created before protection was
        # added. All preexisting rules, selected values and scores must match.
        protection_keys = {"protected_configuration", "configuration_sha256",
                           "selection_states_sha256"}
        ignored = {"configuration_created_at_utc"}
        if not (protection_keys & existing.keys()):
            ignored |= protection_keys
        old_compare = {k: v for k, v in existing.items() if k not in ignored}
        new_compare = {k: v for k, v in frozen.items() if k not in ignored}
        # Permit only the known wording correction for an unchanged method.
        # All parameters, candidate scores, selection data and timestamps keep
        # the same freeze protection; arbitrary rule changes still fail.
        for key, legacy in _LEGACY_RULE_DESCRIPTIONS.items():
            if old_compare.get(key) == legacy:
                old_compare[key] = new_compare[key]
        if old_compare != new_compare:
            raise ValueError("Frozen pattern configuration differs from this run; "
                             "use a new output directory for changed inputs or rules")
        frozen["configuration_created_at_utc"] = existing["configuration_created_at_utc"]
    pd.DataFrame(rows).to_csv(paths["selection_csv"], index=False)
    _json_write(paths["config_json"], frozen)
    _json_write(paths["selection_json"], frozen)
    return {**{key: str(path) for key, path in paths.items()},
            "frozen_config": frozen}


def _label(center, center_z):
    p = "临床较高" if center_z[0] >= 0 else "临床较低"
    w = "污水较高" if center_z[2] >= 0 else "污水较低"
    dp = "临床上升" if center[1] > 0 else "临床下降" if center[1] < 0 else "临床持平"
    dw = "污水上升" if center[3] > 0 else "污水下降" if center[3] < 0 else "污水持平"
    return f"{p}·{w}（{dp}、{dw}）"


def _period(row, index, config):
    if index < int(config["split"]["warmup_weeks"]):
        return "development_warmup"
    year = int(row["Year"]) if "Year" in row else int(str(row["week_key"]).split("W")[0])
    week = int(row["Week"]) if "Week" in row else int(str(row["week_key"]).split("W")[1])
    if year == config["split"]["validation_origin_year"]:
        return "development_validation_replay"
    if year == config["split"]["test_origin_year"]:
        limits = config["split"]["test_origin_week_range"]
        if limits["start_week"] <= week <= limits["end_week"]:
            return "final_test_replay"
    return "post_test_monitoring"


def _rank_novelty_queries(sensitivity):
    """Separate past-only cumulative ranks from retrospective full-set ranks.

    Higher LOF scores rank first and tied scores share the minimum rank. The
    underlying novelty scores retain their own historical reference windows;
    ranking does not refit or calibrate those models.
    """
    ranked = sensitivity.sort_values(["query_from", "week_key", "lof_k"]).copy()
    if ranked.empty:
        for name in ["rank_as_of", "n_scored_as_of"]:
            ranked[name] = pd.Series(dtype=int)
        for name in ["rank_all", "rank_period"]:
            ranked[name] = pd.Series(dtype=float)
        for name in ["rank_all_cutoff_week", "rank_period_cutoff_week"]:
            ranked[name] = pd.Series(dtype=str)
        return ranked
    ranked["rank_as_of"] = 0
    ranked["n_scored_as_of"] = 0
    for _, group in ranked.groupby("lof_k", sort=False):
        observed_scores = []
        for row_index, row in group.iterrows():
            observed_scores.append(row["lof_score"])
            ranked.loc[row_index, "rank_as_of"] = (
                1 + int(np.count_nonzero(np.asarray(observed_scores) > row["lof_score"])))
            ranked.loc[row_index, "n_scored_as_of"] = len(observed_scores)
    ranked["rank_all"] = ranked.groupby("lof_k")["lof_score"].rank(
        ascending=False, method="min")
    ranked["rank_period"] = ranked.groupby(["period", "lof_k"])["lof_score"].rank(
        ascending=False, method="min")
    ranked["rank_all_cutoff_week"] = ranked.groupby("lof_k")["week_key"].transform("last")
    ranked["rank_period_cutoff_week"] = ranked.groupby(["period", "lof_k"])["week_key"].transform("last")
    return ranked


def run_patterns(clean_df, config, out_dir):
    """Apply a previously frozen configuration to past-only rolling references."""
    out_dir = Path(out_dir)
    config_path = out_dir / "pattern_config.json"
    if not config_path.exists():
        raise FileNotFoundError("Run freeze_pattern_config before run_patterns")
    frozen = json.loads(config_path.read_text(encoding="utf-8"))
    frame = validate_pattern_frozen(clean_df, config, frozen)
    available_at = pd.Timestamp(frozen["selection_available_at"])
    params = {"seed": frozen["seed"], "n_init": frozen["kmeans_initializations"],
              "max_iter": frozen["kmeans_max_iterations"]}
    cluster_k = int(frozen["cluster_k"])
    primary_k = int(frozen["lof_primary_neighbors"])
    neighbor_counts = list(dict.fromkeys([primary_k] + frozen["lof_neighbors"]))
    pattern_rows, center_rows, neighbor_rows, sensitivity_rows = [], [], [], []
    for index, query in frame.iterrows():
        start = query["From"] - pd.Timedelta(weeks=frozen["reference_window_weeks"])
        calendar = frame.loc[(frame["From"] >= start) &
                             (frame["From"] < query["From"])]
        reference = calendar.loc[calendar["state_valid"]]
        issue_at = _issue_at(query, config)
        record = {"source_version": query.get("source_version", ""),
                  "issue_at": issue_at.isoformat(), "week_key": query["week_key"],
                  "source_row_key": query.get("source_row_key", query["week_key"]),
                  "backtest_mode": "frozen_retrospective",
                  "period": _period(query, index, config), "status": "ok",
                  "cluster_id": np.nan, "cluster_label": "", "cluster_k": cluster_k,
                  "lof_score": np.nan, "lof_k": primary_k,
                  "reference_start": str(reference.iloc[0]["week_key"]) if len(reference) else "",
                  "reference_end": str(reference.iloc[-1]["week_key"]) if len(reference) else "",
                  "reference_start_from": reference.iloc[0]["From"].isoformat() if len(reference) else "",
                  "reference_end_from": reference.iloc[-1]["From"].isoformat() if len(reference) else "",
                  "reference_calendar_start": start.isoformat(),
                  "reference_calendar_end": (query["From"] - pd.Timedelta(weeks=1)).isoformat(),
                  "query_features_available": bool(query["state_valid"]),
                  "n_reference": len(reference), "n_reference_calendar": len(calendar),
                  "n_reference_excluded": len(calendar) - len(reference),
                  "reference_hash": "", "reference_duplicate_rows": np.nan,
                  "reference_duplicate_pairs": np.nan,
                  "kmeans_converged": pd.NA, "kmeans_effective_k": np.nan,
                  "kmeans_n_iter": np.nan, "kmeans_inertia": np.nan,
                  "configuration_selection_end": frozen["selection_data_end"],
                  "configuration_available_at": available_at.isoformat(),
                  "configuration_provenance": frozen["configuration_provenance"],
                  "SARSCoV2_proportion": query[config["data"]["target"]],
                  "Sewage_viralload": query[config["data"]["sewage"]]}
        for feature in STATE_FEATURES:
            record[feature] = query[feature]
            record[feature + "_z"] = np.nan
            record[feature + "_reference_mean"] = np.nan
            record[feature + "_reference_scale"] = np.nan
        if not query["state_valid"]:
            record["status"] = "missing_query_features"
        elif issue_at <= available_at:
            record["status"] = "config_not_yet_available"
        elif len(reference) < max(frozen["minimum_reference_rows"], max(neighbor_counts) + 1):
            record["status"] = "insufficient_reference"
        if record["status"] != "ok":
            pattern_rows.append(record)
            continue
        x = reference[STATE_FEATURES].to_numpy(float)
        scaler = Standardizer().fit(x)
        z = scaler.transform(x)
        query_z = scaler.transform(query[STATE_FEATURES].to_numpy(float)[None, :])
        fingerprint = "|".join(reference["week_key"].astype(str))
        record["reference_hash"] = hashlib.sha256(
            fingerprint.encode() + x.astype("<f8").tobytes()).hexdigest()
        for i, feature in enumerate(STATE_FEATURES):
            record[feature + "_z"] = query_z[0, i]
            record[feature + "_reference_mean"] = scaler.mean_[i]
            record[feature + "_reference_scale"] = scaler.scale_[i]
        kmeans = _kmeans(cluster_k, params).fit(z)
        record["kmeans_converged"] = kmeans.converged_
        record["kmeans_effective_k"] = kmeans.effective_k_
        record["kmeans_n_iter"] = kmeans.n_iter_
        record["kmeans_inertia"] = kmeans.inertia_
        cluster = int(kmeans.predict(query_z)[0])
        raw_centers = scaler.inverse_transform(kmeans.cluster_centers_)
        record["cluster_id"] = cluster
        record["cluster_label"] = _label(raw_centers[cluster], kmeans.cluster_centers_[cluster])
        for c in range(cluster_k):
            members = reference.loc[kmeans.labels_ == c, "week_key"].astype(str).tolist()
            center_record = {"query_week_key": query["week_key"],
                             "issue_at": issue_at.isoformat(), "cluster_id": c,
                             "cluster_k": cluster_k,
                             "cluster_label": _label(raw_centers[c], kmeans.cluster_centers_[c]),
                             "n_members": len(members),
                             "member_week_keys": json.dumps(members, ensure_ascii=False),
                             "w_center": np.expm1(raw_centers[c, 2]),
                             "reference_start": record["reference_start"],
                             "reference_end": record["reference_end"],
                             "source_version": record["source_version"]}
            for i, feature in enumerate(STATE_FEATURES):
                center_record[feature + "_center"] = raw_centers[c, i]
                center_record[feature + "_center_z"] = kmeans.cluster_centers_[c, i]
            center_rows.append(center_record)
        for neighbors in neighbor_counts:
            lof = LOFNovelty(neighbors, epsilon=frozen["lof_epsilon"]).fit(z)
            detail = lof.query_details(query_z)
            score = float(detail["scores"][0])
            sensitivity_rows.append({"week_key": query["week_key"],
                                     "period": record["period"],
                                     "issue_at": record["issue_at"],
                                     "query_from": query["From"].isoformat(),
                                     "lof_k": neighbors, "lof_score": score,
                                     "n_reference": len(reference)})
            if neighbors == primary_k:
                record["lof_score"] = score
                record["reference_duplicate_rows"] = lof.duplicate_rows_
                record["reference_duplicate_pairs"] = lof.duplicate_pairs_
            for rank, ref_index in enumerate(detail["neighbors"][0], start=1):
                neighbor = reference.iloc[ref_index]
                neighbor_record = {
                    "query_week_key": query["week_key"],
                    "neighbor_week_key": neighbor["week_key"],
                    "lof_k": neighbors, "neighbor_rank": rank,
                    "distance": detail["distances"][0, rank - 1],
                    "reachability_distance": detail["reachability_distances"][0, rank - 1],
                    "reference_k_distance": lof.k_distances_[ref_index],
                    "reference_lrd": lof.lrd_[ref_index],
                    "query_lrd": detail["lrd"][0],
                    "source_row_key": neighbor.get("source_row_key", neighbor["week_key"]),
                    "source_version": neighbor.get("source_version", ""),
                    "SARSCoV2_proportion": neighbor[config["data"]["target"]],
                    "Sewage_viralload": neighbor[config["data"]["sewage"]]}
                for i, feature in enumerate(STATE_FEATURES):
                    neighbor_record[feature] = x[ref_index, i]
                    neighbor_record[feature + "_z"] = z[ref_index, i]
                neighbor_rows.append(neighbor_record)
        pattern_rows.append(record)
    patterns = pd.DataFrame(pattern_rows)
    sensitivity = pd.DataFrame(sensitivity_rows,
                               columns=["week_key", "period", "issue_at", "query_from",
                                        "lof_k", "lof_score", "n_reference"])
    sensitivity = _rank_novelty_queries(sensitivity)
    summary_rows = []
    if len(sensitivity):
        for period in ["all"] + sorted(sensitivity["period"].unique().tolist()):
            part = sensitivity if period == "all" else sensitivity.loc[sensitivity["period"] == period]
            scores = part.pivot(index="week_key", columns="lof_k", values="lof_score")
            ranks = scores.rank(ascending=False, method="average")
            for neighbors in neighbor_counts:
                a, b = ranks[primary_k], ranks[neighbors]
                rho = float(a.corr(b)) if len(a) > 1 and a.nunique() > 1 and b.nunique() > 1 else np.nan
                count = min(10, len(scores))
                main_top = set(scores[primary_k].sort_values(ascending=False, kind="stable").index[:count])
                other_top = set(scores[neighbors].sort_values(ascending=False, kind="stable").index[:count])
                summary_rows.append({"period": period, "lof_primary_k": primary_k,
                                     "lof_k": neighbors, "n_queries": len(scores),
                                     "spearman_rank_correlation": rho,
                                     "top_n": count, "top_n_overlap": len(main_top & other_top),
                                     "ranking_cutoff_week": part.iloc[-1]["week_key"],
                                     "ranking_interpretation": "retrospective_descriptive_ranking"})
    outputs = {"patterns_csv": out_dir / "patterns.csv",
               "centers_csv": out_dir / "pattern_centers.csv",
               "neighbors_csv": out_dir / "pattern_neighbors.csv",
               "sensitivity_csv": out_dir / "pattern_sensitivity.csv",
               "sensitivity_summary_csv": out_dir / "pattern_sensitivity_summary.csv",
               "config_json": config_path,
               "selection_csv": out_dir / "pattern_selection.csv",
               "selection_json": out_dir / "pattern_selection.json"}
    patterns.to_csv(outputs["patterns_csv"], index=False)
    center_columns = ["query_week_key", "issue_at", "cluster_id", "cluster_k", "cluster_label",
                      "n_members", "member_week_keys", "w_center", "reference_start", "reference_end",
                      "source_version"] + [c for f in STATE_FEATURES for c in (f + "_center", f + "_center_z")]
    neighbor_columns = ["query_week_key", "neighbor_week_key", "lof_k", "neighbor_rank", "distance",
                        "reachability_distance", "reference_k_distance", "reference_lrd", "query_lrd",
                        "source_row_key", "source_version", "SARSCoV2_proportion", "Sewage_viralload"]
    neighbor_columns += [c for f in STATE_FEATURES for c in (f, f + "_z")]
    pd.DataFrame(center_rows, columns=center_columns).to_csv(outputs["centers_csv"], index=False)
    pd.DataFrame(neighbor_rows, columns=neighbor_columns).to_csv(outputs["neighbors_csv"], index=False)
    sensitivity.to_csv(outputs["sensitivity_csv"], index=False)
    pd.DataFrame(summary_rows, columns=["period", "lof_primary_k", "lof_k", "n_queries",
                                       "spearman_rank_correlation", "top_n", "top_n_overlap",
                                       "ranking_cutoff_week",
                                       "ranking_interpretation"]).to_csv(outputs["sensitivity_summary_csv"], index=False)
    return {key: str(path) for key, path in outputs.items()}
