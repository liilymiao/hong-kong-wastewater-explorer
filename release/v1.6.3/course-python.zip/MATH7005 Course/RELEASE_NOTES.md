# Python 1.5.3 course candidate

Prepared locally on 11 November 2026. Public website baseline remains v1.6.2 at c370c01; the separate website boundary-fix candidate is v1.6.3. No remote publication is part of this revision.

- Adds an explicit Python Course demo and a real historical-origin computation trace using the existing prediction module.
- Generates an English report with course-to-function-to-test evidence and original/limited predictions, block intervals and post-hoc period diagnostics.
- Adds portable reproduction and output-contract tests while retaining the existing time, missingness, pairing and NumPy checks.
- Updates launch, AI disclosure, demonstration and closed-book preparation notes.

Scientific configuration 1.1, original data, frozen reference CSVs and model-selection protocol remain unchanged. STATUS.md records this revision's actual execution and row comparisons.
